-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 07, 2015 at 05:11 AM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ims`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `bankbook`(IN `pbid` INT, IN `fromdate` DATE, IN `todate` DATE)
    NO SQL
BEGIN
 
SELECT bankbook.created_at,voucher.id as vid,voucher.vnno,voucher.type as type,voucher.amount,bankbook.id,suppliers.name as sname,customers.name as cname ,suppliers.id as sid,customers.id as cid,voucher.status,bankbook.dc 
from bankbook
LEFT OUTER JOIN suppliers  ON bankbook.sid=suppliers.id
LEFT OUTER JOIN customers  ON bankbook.cid=customers.id
LEFT OUTER JOIN voucher  ON bankbook.vid=voucher.id

where 
bankbook.baccid=pbid
AND voucher.vstatus
AND bankbook.created_at BETWEEN fromdate AND todate
ORDER BY bankbook.id ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `cashanalyst`(IN `cid` INT)
    NO SQL
BEGIN
SELECT SUM(voucher.amount) as amount FROM voucher
WHERE voucher.cid=cid;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `challanitem`(IN `sid` INT)
    NO SQL
BEGIN
SElECT DISTINCT items.id,items.name  
FROM factioyitems,items
WHERE factioyitems.itemsid=items.id
AND factioyitems.salesid=sid
ORDER BY factioyitems.itemsid;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `contravoucher`(IN `pid` INT, IN `ptype` INT, IN `pstatus` INT)
    NO SQL
BEGIN
IF pstatus = 1 THEN 
SELECT * FROM
voucher 
WHERE id=pid;
END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `currentdate`()
    NO SQL
BEGIN
SELECT CURDATE() as curdate;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `customerbalance`(IN `pcid` INT, IN `pdate` DATE)
    NO SQL
BEGIN

DECLARE openb decimal(10,2);
DECLARE debit decimal(10,2);
DECLARE credit decimal(10,2);

SET openb = (select openbalance from customers where id=pcid);

SET debit = (select sum(amount) from customersledger where sv<>0 and cid=pcid and created_at<=pdate);

SET credit = (select sum(amount) from customersledger where rv<>0 and cid=pcid and created_at<=pdate);

select ((openb+debit)-credit) as openbalance ;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `customersledger`(IN `pcid` INT, IN `fromdate` DATE, IN `todate` DATE)
    NO SQL
BEGIN

SELECT customersledger.cid,customersledger.amount,customersledger.created_at,customersledger.rv,voucher.vnno as rvoucher, 
customersledger.sv,sales.name as svoucher,customers.name as cname,voucher.id as vid,sales.id as sid,voucher.type as vtype,customers.code as ccode,voucher.vstatus,sales.status as sstatus
FROM customersledger
LEFT OUTER JOIN customers  ON customersledger.cid=customers.id
LEFT OUTER JOIN voucher  ON customersledger.rv=voucher.id
LEFT OUTER JOIN sales  ON customersledger.sv=sales.id
WHERE 
customersledger.created_at BETWEEN fromdate AND todate
AND customersledger.cid=pcid
ORDER BY customersledger.cid ASC;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `customersledgerall`(IN `pcid` INT, IN `fromdate` DATE, IN `todate` DATE)
    NO SQL
BEGIN
If pcid=0 THEN
SELECT customersledger.cid,customersledger.amount,customersledger.created_at,customersledger.rv,voucher.vnno as rvoucher, 
customersledger.sv,sales.name as svoucher,customers.name as cname,voucher.id as vid,sales.id as sid,voucher.type as vtype,customers.code as ccode,voucher.vstatus,sales.status as sstatus
FROM customersledger
LEFT OUTER JOIN customers  ON customersledger.cid=customers.id
LEFT OUTER JOIN voucher  ON customersledger.rv=voucher.id
LEFT OUTER JOIN sales  ON customersledger.sv=sales.id
WHERE 
customersledger.created_at BETWEEN fromdate AND todate

ORDER BY customersledger.cid ASC;

END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fromtodaybankcollection`(IN `fromdate` DATE, IN `todate` DATE)
    NO SQL
BEGIN
SELECT SUM(amount) as cash
FROM voucher
WHERE  created_at BETWEEN fromdate AND todate
AND vstatus=1
AND type=3;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fromtodaybkashcollection`(IN `fromdate` DATE, IN `todate` DATE)
    NO SQL
BEGIN
SELECT SUM(amount) as cash
FROM voucher
WHERE  created_at BETWEEN fromdate AND todate
AND vstatus=1
AND type=6;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fromtodaycash`(IN `fromdate` DATE, IN `todate` DATE)
    NO SQL
BEGIN
SELECT SUM(amount) as cash
FROM voucher
WHERE  created_at BETWEEN fromdate AND todate

AND
type IN (3,4,6,7,8,9)
AND vstatus=1;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fromtodaycashcollection`(IN `fromdate` DATE, IN `todate` DATE)
    NO SQL
BEGIN
SELECT SUM(amount) as cash
FROM voucher
WHERE  created_at BETWEEN fromdate AND todate
AND vstatus=1
AND type=4;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fromtodaycollection`(IN `fromdate` DATE, IN `todate` DATE)
    NO SQL
BEGIN
SELECT voucher.id,customers.name,customers.preaddress,voucher.amount,voucher.vnno,voucher.type,voucher.vstatus
FROM voucher,customers
WHERE
voucher.type<>1
and voucher.type<>2
and voucher.type<>5
and voucher.vstatus=1
and voucher.cid=customers.id

AND voucher.created_at BETWEEN fromdate AND todate
order by voucher.cid;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fromtodaykcscollection`(IN `fromdate` DATE, IN `todate` DATE)
    NO SQL
BEGIN
SELECT SUM(amount) as cash
FROM voucher
WHERE  created_at BETWEEN fromdate AND todate 
AND vstatus=1
AND type=8;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fromtodaymbankcollection`(IN `fromdate` DATE, IN `todate` DATE)
    NO SQL
BEGIN
SELECT SUM(amount) as cash
FROM voucher
WHERE  created_at BETWEEN fromdate AND todate
AND vstatus=1
AND type=9;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fromtodaysapcollection`(IN `fromdate` DATE, IN `todate` DATE)
    NO SQL
BEGIN
SELECT SUM(amount) as cash
FROM voucher
WHERE  created_at BETWEEN fromdate AND todate
AND vstatus=1
AND type=7;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `generalledger`(IN `pid` INT, IN `fromdate` DATE, IN `todate` DATE)
    NO SQL
BEGIN

select pettycash.id,pettycash.created_at,pettycash.amount,pettycash.description,coa.name,increasetype.name as dc,coa.openbalance
from pettycash,coa,increasetype
WHERE 
pettycash.created_at BETWEEN fromdate AND todate
AND increasetype.id=coa.increasetypeid
AND coa.id=pettycash.particular
AND pettycash.particular=pid
ORDER BY pettycash.id ASC;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `itempurchase`()
    NO SQL
BEGIN

Select items.id,items.name 
from items,itemsgroup,itemssubgroup
where items.itemssubgroupid=itemssubgroup.id
and itemssubgroup.itemgroupid=itemsgroup.id
and itemsgroup.id=2;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ledgerentry`(IN `pid` INT)
    NO SQL
BEGIN
SELECT pettycash.id,pettycash.particular,pettycash.amount,pettycash.description,coa.name,coa.code,pettycash.created_at
FROM pettycash,coa
WHERE 
coa.id=pettycash.particular
AND
pettycash.id=pid;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `purchasedetailsview`(IN `pid` INT)
    NO SQL
BEGIN
SELECT  items.name as iname,purchasedetails.quantity,purchasedetails.old_quantity,  purchasedetails.id, measurementunit.name as   mname,purchasedetails.rate,purchasedetails.old_rate,purchasedetails.amount,purchasedetails.old_amount
FROM items,purchasedetails,measurementunit,purchase
WHERE purchasedetails.purchaseid=purchase.id
AND purchasedetails.itemid=items.id
ANd purchasedetails.mesid=measurementunit.id
AND purchasedetails.purchaseid=pid;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `rptcash`(IN `fromdate` DATE, IN `todate` DATE)
    NO SQL
BEGIN
SELECT voucher.created_at,voucher.vnno,voucher.id ,voucher.amount,voucher.type
FROM voucher
WHERE  
(voucher.type<>1 AND voucher.type<>3)

AND voucher.vstatus=1

AND voucher.created_at BETWEEN fromdate AND todate
UNION ALL
SELECT pettycash.created_at,pettycash.id as vnno ,pettycash.id,pettycash.amount,coa.increasetypeid as type
FROM pettycash,coa
WHERE
pettycash.particular=coa.id
AND
pettycash.created_at BETWEEN fromdate AND todate;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `rptfactioyitems`(IN `fromdate` DATE, IN `todate` DATE)
    NO SQL
BEGIN

select items.name as name,SUM(factioyitems.quantity) as cnt,measurementunit.name as mnane 
from factioyitems,items,measurementunit
where 
factioyitems.itemsid=items.id
AND
factioyitems.mesid=measurementunit.id
AND
factioyitems.created_at BETWEEN fromdate AND todate
GROUP BY factioyitems.itemsid;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `rptfactorypurchase`(IN `fromdate` DATE, IN `todate` DATE)
    NO SQL
BEGIN

select items.name as name,SUM(purchasedetails.quantity) as fcnt,measurementunit.name as mname
from purchasedetails,items,measurementunit
where 
purchasedetails.itemid=items.id
AND
measurementunit.id=purchasedetails.mesid
AND
purchasedetails.created_at BETWEEN fromdate AND todate
GROUP BY purchasedetails.itemid;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `rptpurchase`(IN `fromdate` DATE, IN `todate` DATE)
    NO SQL
BEGIN

select purchase.id,purchase.name,purchase.purchasedate,suppliers.name as suppliersname,purchase.suppliersbillno,purchase.suppliersbilldate,purchase.gross_total as amount
from purchase,suppliers
where
status=1
AND
purchase.suppliersid=suppliers.id
AND
purchase.created_at BETWEEN fromdate AND todate;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `rptsales`(IN `fromdate` DATE, IN `todate` DATE)
    NO SQL
BEGIN

select sales.id as id,sales.name as name,sales.salesdate as salesdate,customers.name as cname,customers.preaddress as address,customers.id as cid,sales.gamount,sales.previousdue,sales.presentbalance 
from 
sales,customers
where 
sales.customerid=customers.id
and
sales.status=1
and
sales.created_at BETWEEN fromdate AND todate
ORDER BY sales.id ASC
;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `rptstockinout`(IN `fromdate` DATE, IN `todate` DATE)
    NO SQL
BEGIN

select items.name as name,SUM(factioyitems.quantity) as fcnt
from purchasedetails,items,factioyitems
where 
purchasedetails.itemid=items.id
AND
factioyitems.itemsid=items.id
AND
purchasedetails.created_at BETWEEN fromdate AND todate
GROUP BY items.id;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `salesanalyst`(IN `sid` INT)
    NO SQL
BEGIN
SELECT SUM(salesdetails.amount) as amount FROM salesdetails
WHERE salesdetails.salesid=sid;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `salesdetailsview`(IN `pid` INT)
    NO SQL
BEGIN
SELECT  sales.id as sid,items.code as icode,items.name as iname,salesdetails.quantity,  measurementunit.name as   mname,salesdetails.rate,salesdetails.amount
FROM items,salesdetails,measurementunit,sales
WHERE salesdetails.salesid=sales.id
AND salesdetails.itemid=items.id
ANd salesdetails.mesid=measurementunit.id
AND salesdetails.salesid=pid;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `salesreport`(IN `pvalue` INT)
    NO SQL
BEGIN
select created_at,sum(gamount) as total 
from sales
where status=1
and MONTH(created_at)=pvalue
group by created_at;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `salesreportp`(IN `pvalue` INT)
    NO SQL
BEGIN
select created_at,sum(gamount) as total 
from sales
where status=1
and MONTH(created_at)=pvalue
group by created_at;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `searchreturn`(IN `pslno` TEXT)
    NO SQL
BEGIN
SElECT factioyitems.slno, factioyitems.salesid, customers.name as cname
FROM factioyitems,sales,customers
WHERE factioyitems.salesid=sales.id
AND sales.customerid=customers.id
AND factioyitems.slno=pslno;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sub_ledger_voucher`(IN `pid` INT, IN `fromdate` DATE, IN `todate` DATE)
    NO SQL
BEGIN

IF pid=2 THEN
SELECT voucher.id,voucher.type,voucher.vnno,voucher.vdate,voucher.amount,customers.name,voucher.created_at,increasetype.name as dc,coa.openbalance
FROM voucher,customers,coa,increasetype
WHERE  voucher.created_at BETWEEN fromdate AND todate
AND voucher.vstatus=1
AND voucher.type=4
AND voucher.cid=customers.id
AND coa.id=2
AND increasetype.id=coa.increasetypeid
ORDER BY voucher.id ASC;

ELSEIF pid=3 THEN
SELECT voucher.id,voucher.type,voucher.vnno,voucher.vdate,voucher.amount,suppliers.name,voucher.created_at,increasetype.name as dc,coa.openbalance
FROM voucher,suppliers,coa,increasetype
WHERE  voucher.created_at BETWEEN fromdate AND todate
AND voucher.vstatus=1
AND voucher.type=2
AND voucher.sid=suppliers.id
AND coa.id=3
AND increasetype.id=coa.increasetypeid;

ELSEIF pid=4 THEN
SELECT voucher.id,voucher.type,voucher.vnno,voucher.vdate,voucher.amount,customers.name,voucher.created_at,increasetype.name as dc,coa.openbalance
FROM voucher,customers,coa,increasetype
WHERE  voucher.created_at BETWEEN fromdate AND todate
AND voucher.vstatus=1
AND voucher.type=6
AND voucher.cid=customers.id
AND coa.id=4
AND increasetype.id=coa.increasetypeid;

ELSEIF pid=5 THEN
SELECT voucher.id,voucher.type,voucher.vnno,voucher.vdate,voucher.amount,customers.name,voucher.created_at,increasetype.name as dc,coa.openbalance
FROM voucher,customers,coa,increasetype
WHERE  voucher.created_at BETWEEN fromdate AND todate
AND voucher.vstatus=1
AND voucher.type=7
AND voucher.cid=customers.id
AND coa.id=5
AND increasetype.id=coa.increasetypeid;

ELSEIF pid=6 THEN
SELECT voucher.id,voucher.type,voucher.vnno,voucher.vdate,voucher.amount,customers.name,voucher.created_at,increasetype.name as dc,coa.openbalance
FROM voucher,customers,coa,increasetype
WHERE  voucher.created_at BETWEEN fromdate AND todate
AND voucher.vstatus=1
AND voucher.type=8
AND voucher.cid=customers.id
AND coa.id=6
AND increasetype.id=coa.increasetypeid;

ELSEIF pid=7 THEN
SELECT voucher.id,voucher.type,voucher.vnno,voucher.vdate,voucher.amount,customers.name,voucher.created_at,increasetype.name as dc,coa.openbalance
FROM voucher,customers,coa,increasetype
WHERE  voucher.created_at BETWEEN fromdate AND todate
AND voucher.vstatus=1
AND voucher.type=9
AND voucher.cid=customers.id
AND coa.id=7
AND increasetype.id=coa.increasetypeid;

ELSEIF pid=8 THEN
SELECT voucher.id,voucher.type,voucher.vnno,voucher.vdate,voucher.amount,customers.name,voucher.created_at,increasetype.name as dc,coa.openbalance
FROM voucher,customers,coa,increasetype
WHERE  voucher.created_at BETWEEN fromdate AND todate
AND voucher.vstatus=1
AND voucher.type=3
AND voucher.cid=customers.id
AND coa.id=8
AND increasetype.id=coa.increasetypeid;

ELSEIF pid=9 THEN
SELECT voucher.id,voucher.type,voucher.vnno,voucher.vdate,voucher.amount,suppliers.name,voucher.created_at,increasetype.name as dc,coa.openbalance
FROM voucher,suppliers,coa,increasetype
WHERE  voucher.created_at BETWEEN fromdate AND todate
AND voucher.vstatus=1
AND voucher.type=1
AND voucher.sid=suppliers.id
AND coa.id=9
AND increasetype.id=coa.increasetypeid;

ELSEIF pid=11 THEN
SELECT sales.id,sales.name as salesname,sales.salesdate,sales.gamount,customers.name as cname,increasetype.name as dc,coa.openbalance
FROM sales,customers,coa,increasetype
WHERE  sales.created_at BETWEEN fromdate AND todate
AND sales.status=1
AND sales.customerid=customers.id
AND coa.id=11
AND increasetype.id=coa.increasetypeid;

ELSEIF pid=12 THEN
SELECT purchase.id,purchase.name as purchasename, purchase.purchasedate, purchase.gross_total,suppliers.name as sname,increasetype.name as dc,coa.openbalance
FROM purchase,suppliers,coa,increasetype
WHERE  purchase.created_at BETWEEN fromdate AND todate
AND purchase.status=1
AND purchase.suppliersid=suppliers.id
AND coa.id=12
AND increasetype.id=coa.increasetypeid;

ELSEIF pid=13 THEN
SELECT employeeinfo.name as employeename, employeesal.amount,  employeesal.vdate, employeesal.description,increasetype.name as dc,coa.openbalance
FROM employeesal,employeeinfo,coa,increasetype
WHERE  employeesal.created_at BETWEEN fromdate AND todate
AND employeesal.eid=employeeinfo.id
AND coa.id=13
AND increasetype.id=coa.increasetypeid;
END IF;


END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `suppliersledger`(IN `psid` INT, IN `fromdate` DATE, IN `todate` DATE)
    NO SQL
BEGIN
SELECT suppliersledger.sid,suppliersledger.amount,suppliersledger.created_at,suppliersledger.pav,suppliersledger.puv,voucher.vnno as pavoucher,purchase.name as puvoucher,suppliers.name as sname,voucher.id as vid,purchase.id as puid, voucher.type as vtype, suppliers.code as scode,voucher.vstatus, purchase.status as pustatus
FROM suppliersledger
LEFT OUTER JOIN suppliers  ON suppliersledger.sid=suppliers.id
LEFT OUTER JOIN voucher  ON suppliersledger.pav=voucher.id
LEFT OUTER JOIN purchase  ON suppliersledger.puv=purchase.id
WHERE suppliersledger.created_at BETWEEN fromdate AND todate
AND suppliersledger.sid=psid;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `suppliersledgerall`(IN `psid` INT, IN `fromdate` DATE, IN `todate` DATE)
    NO SQL
BEGIN
If psid=0 THEN
SELECT suppliersledger.sid,suppliersledger.amount,suppliersledger.created_at,suppliersledger.pav,suppliersledger.puv,voucher.vnno as pavoucher,purchase.name as puvoucher,suppliers.name as sname,voucher.id as vid,purchase.id as puid, voucher.type as vtype, suppliers.code as scode,voucher.vstatus, purchase.status as pustatus
FROM suppliersledger
LEFT OUTER JOIN suppliers  ON suppliersledger.sid=suppliers.id
LEFT OUTER JOIN voucher  ON suppliersledger.pav=voucher.id
LEFT OUTER JOIN purchase  ON suppliersledger.puv=purchase.id
WHERE suppliersledger.created_at BETWEEN fromdate AND todate;
END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `todaybankcollection`()
    NO SQL
BEGIN
SELECT SUM(amount) as cash
FROM voucher
WHERE  created_at=CURDATE()
AND vstatus=1
AND type=3;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `todaybkashcollection`()
    NO SQL
BEGIN
SELECT SUM(amount) as cash
FROM voucher
WHERE  created_at=CURDATE()
AND vstatus=1
AND type=6;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `todaycash`()
    NO SQL
BEGIN
SELECT SUM(amount) as cash
FROM voucher
WHERE  created_at=CURDATE()
AND
type IN (3,4,6,7,8,9)
AND vstatus=1;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `todaycashcollection`()
    NO SQL
BEGIN
SELECT SUM(amount) as cash
FROM voucher
WHERE  created_at=CURDATE()
AND vstatus=1
AND type=4;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `todaycollection`()
    NO SQL
BEGIN
SELECT voucher.id,customers.name,customers.preaddress,voucher.amount,voucher.vnno,voucher.type,voucher.vstatus
FROM voucher,customers
WHERE
voucher.type<>1
and voucher.type<>2
and voucher.type<>5
and voucher.vstatus=1
and voucher.cid=customers.id
and voucher.created_at=CURDATE()
order by voucher.cid;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `todaycontracollection`()
    NO SQL
BEGIN
SELECT SUM(amount) as cash
FROM voucher
WHERE  created_at=CURDATE()
AND type=5
AND vstatus=1;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `todaykcscollection`()
    NO SQL
BEGIN
SELECT SUM(amount) as cash
FROM voucher
WHERE  created_at=CURDATE()
AND vstatus=1
AND type=8;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `todaymbankcollection`()
    NO SQL
BEGIN
SELECT SUM(amount) as cash
FROM voucher
WHERE  created_at=CURDATE()
AND vstatus=1
AND type=9;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `todaypettycash`(IN `pid` INT, IN `fromdate` DATE, IN `todate` DATE)
    NO SQL
BEGIN

IF pid=2 THEN
SELECT SUM(amount) as cash
FROM voucher
WHERE  created_at BETWEEN fromdate AND todate
AND vstatus=1
AND type=4;

ELSEIF pid=3 THEN
SELECT SUM(amount) as cash
FROM voucher
WHERE  created_at BETWEEN fromdate AND todate
AND vstatus=1
AND type=2;

ELSEIF pid=4 THEN
SELECT SUM(amount) as cash
FROM voucher
WHERE  created_at BETWEEN fromdate AND todate
AND vstatus=1
AND type=6;

ELSEIF pid=5 THEN
SELECT SUM(amount) as cash
FROM voucher
WHERE  created_at BETWEEN fromdate AND todate
AND vstatus=1
AND type=7;

ELSEIF pid=6 THEN
SELECT SUM(amount) as cash
FROM voucher
WHERE  created_at BETWEEN fromdate AND todate
AND vstatus=1
AND type=8;

ELSEIF pid=7 THEN
SELECT SUM(amount) as cash
FROM voucher
WHERE  created_at BETWEEN fromdate AND todate
AND vstatus=1
AND type=9;

ELSEIF pid=8 THEN
SELECT SUM(amount) as cash
FROM voucher
WHERE  created_at BETWEEN fromdate AND todate
AND vstatus=1
AND type=3;

ELSEIF pid=9 THEN
SELECT SUM(amount) as cash
FROM voucher
WHERE  created_at BETWEEN fromdate AND todate
AND vstatus=1
AND type=1;

ELSEIF pid=11 THEN
SELECT SUM(gamount) as cash
FROM sales
WHERE  created_at BETWEEN fromdate AND todate
AND status=1;

ELSEIF pid=12 THEN
SELECT SUM(gross_total) as cash
FROM purchase
WHERE  created_at BETWEEN fromdate AND todate
AND status=1;

ELSEIF pid=13 THEN
SELECT SUM(amount) as cash
FROM employeesal
WHERE  created_at BETWEEN fromdate AND todate;

ELSEIF pid=14 THEN
SELECT SUM(amount) as cash
FROM voucher
WHERE  vstatus=1
AND created_at <= fromdate ;

ELSEIF pid=15 THEN
SELECT SUM(amount) as cash
FROM voucher
WHERE  vstatus=1
AND created_at < todate ;

ELSE
SELECT SUM(pettycash.amount) as cash
FROM pettycash,coa
WHERE  
pettycash.created_at BETWEEN fromdate AND todate
AND pettycash.particular=coa.id
AND pettycash.particular=pid;
END IF;


END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `todaysales`()
    NO SQL
BEGIN
SELECT SUM(gamount) as sales
FROM sales
WHERE
status=1
and created_at=CURDATE();

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `todaysapcollection`()
    NO SQL
BEGIN
SELECT SUM(amount) as cash
FROM voucher
WHERE  created_at=CURDATE()
AND vstatus=1
AND type=7;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `totalcash`(IN `fromdate` DATE, IN `todate` DATE)
    NO SQL
BEGIN
SELECT SUM(amount) as cash
FROM voucher
WHERE  created_at BETWEEN fromdate AND todate
AND vstatus=1
AND (type<>1 AND type<>2);

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `totalcashcollection`(IN `todate` DATE)
    NO SQL
BEGIN
DECLARE vcash decimal(10,2);
DECLARE vpayment decimal(10,2);
DECLARE pcash decimal(10,2);
DECLARE ppayment decimal(10,2);
DECLARE ccash decimal(10,2);
DECLARE cpayment decimal(10,2);

SET vcash=(SELECT SUM(amount) as cash
FROM voucher
WHERE  created_at<todate
AND
type IN (4,6,7,8,9)
AND vstatus=1);

SET vpayment=(SELECT SUM(amount) as cash
FROM voucher
WHERE  created_at<todate
AND
type IN (2)
AND vstatus=1);




SET ccash=(SELECT SUM(amount) as cash
FROM voucher
WHERE  created_at<todate
AND
type=5
AND status=2              
AND vstatus=1);




SET cpayment=(SELECT SUM(amount) as cash
FROM voucher
WHERE  created_at<todate
AND
type=5
AND status=1              
AND vstatus=1);



SET pcash=(SELECT SUM(pettycash.amount) as cash
FROM pettycash,coa
WHERE pettycash.created_at<todate
AND coa.increasetypeid=1
AND coa.id=pettycash.particular
);



SET ppayment=(SELECT SUM(pettycash.amount) as cash
FROM pettycash,coa
WHERE pettycash.created_at<todate
AND coa.increasetypeid=2
AND coa.id=pettycash.particular
);

IF(vcash IS NULL) THEN
	SET vcash = 0.00;
END IF;
If(vpayment IS NULL) THEN
	SET vpayment=0.00;
END IF;
If(ccash IS NULL) THEN
	SET ccash=0.00;
END IF;
If(cpayment IS NULL) THEN
	SET cpayment=0.00;
END IF;
If(pcash IS NULL) THEN
	SET pcash=0.00;
END IF;
If(ppayment IS NULL) THEN
	SET ppayment=0.00;
END IF;

select vcash-vpayment+ccash-cpayment+pcash-ppayment as cash;
#select vcash-vpayment+ccash;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `totalcashview`(IN `fromdate` DATE, IN `todate` DATE)
    NO SQL
BEGIN
SELECT voucher.id,voucher.type,voucher.vnno, voucher.vdate, voucher.amount,customers.name
FROM voucher,customers
WHERE voucher.cid=customers.id
AND voucher.created_at BETWEEN fromdate AND todate;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `totalcredit`(IN `fromdate` DATE, IN `todate` DATE)
    NO SQL
BEGIN
SELECT SUM(pettycash.amount) as cash
FROM pettycash,coa,coatype
WHERE  
pettycash.created_at BETWEEN fromdate AND todate
AND pettycash.particular=coa.id
AND coa.coatypeid=coatype.id
AND coa.increasetypeid=2;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `totaldebit`(IN `fromdate` DATE, IN `todate` DATE)
    NO SQL
BEGIN
SELECT SUM(pettycash.amount) as cash
FROM pettycash,coa,coatype
WHERE  
pettycash.created_at BETWEEN fromdate AND todate
AND pettycash.particular=coa.id
AND coa.coatypeid=coatype.id
AND coa.increasetypeid=1;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `totalpettycash`(IN `id` INT, IN `fromdate` DATE, IN `todate` DATE)
    NO SQL
BEGIN
SELECT SUM(pettycash.amount) as cash
FROM pettycash,coa,coatype
WHERE  
pettycash.created_at BETWEEN fromdate AND todate
AND pettycash.particular=coa.id
AND coa.coatypeid=coatype.id
AND coatype.id=id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `totalsales`(IN `fromdate` DATE, IN `todate` DATE)
    NO SQL
BEGIN
SELECT SUM(gamount) as sales
FROM sales
WHERE created_at BETWEEN fromdate AND todate
AND status=1;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `totalsalesview`(IN `fromdate` DATE, IN `todate` DATE)
    NO SQL
BEGIN
SELECT  sales.id,sales.name, sales.salesdate, sales.created_at, customers.name as cname
FROM sales, customers
WHERE sales.customerid=customers.id
AND sales.created_at BETWEEN fromdate AND todate;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `viewpurchase`(IN `pid` INT)
    NO SQL
BEGIN
SELECT  purchase.id, purchase.challanno as challanno,purchase.name as pname,purchase.purchasedate,  suppliers.name as   sname,suppliers.preaddress as   address,purchase.suppliersbillno,purchase.suppliersbilldate,
purchase.sub_total,purchase.discount,purchase.gross_total,
purchase.others_exp,purchase.status,
purchase.old_sub_total,purchase.old_discount,purchase.old_gross_total,
purchase.old_others_exp
FROM purchase,suppliers
WHERE purchase.suppliersid=suppliers.id AND
purchase.id=pid;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `viewsales`(IN `pid` INT)
    NO SQL
BEGIN
SELECT  sales.id,sales.name as sname,sales.salesdate,sales.discount,sales.status,customers.name as   cname,customers.phone,customers.preaddress,customers.openbalance,sales.previousdue,sales.presentbalance,sales.gamount
FROM sales,customers
WHERE sales.customerid=customers.id AND
sales.id=pid;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `voucher`(IN `pid` INT(10), IN `ptype` INT(10))
    NO SQL
BEGIN
IF ptype = 1 THEN 
SELECT voucher.vnno as vrno,voucher.type as mvno,voucher.amount,bankinfo.name as bname,bankaccount.branchname as branchname,
bankaccount.name as accno,voucherbankpayment.checkno,
voucher.vdate,bankaccount.id as baid,suppliers.id as sid,bankaccount.code as bacode,suppliers.code as scode
FROM 
voucher,voucherbankpayment,bankaccount,bankinfo,suppliers
where voucher.id=voucherbankpayment.vid 
and   bankaccount.id=voucherbankpayment.baccid
and   bankinfo.id=bankaccount.bankid
and   suppliers.id=voucher.sid 
and voucher.id=pid;
ELSEIF ptype = 2 THEN 
SELECT voucher.vnno as vrno,voucher.type as mvno,voucher.amount,suppliers.id as sid,suppliers.code as scode,voucher.vdate 
FROM voucher,voucherpayment,suppliers
where voucher.id=voucherpayment.vid 
and suppliers.id=voucher.sid
and   voucher.id=pid;
ELSEIF ptype = 3 THEN 
SELECT voucher.vnno as vrno,voucher.type as mvno,voucher.amount,bankinfo.name as bname,bankaccount.branchname as branchname,
bankaccount.name as accno,voucherbankreceive.checkno,
voucher.vdate,bankaccount.id as baid,customers.id as cid,bankaccount.code as bacode,customers.code as ccode 
FROM voucher,voucherbankreceive,bankaccount,bankinfo,customers
where voucher.id=voucherbankreceive.vid 
and   bankaccount.id=voucherbankreceive.baccid
and   bankinfo.id=bankaccount.bankid
and   customers.id=voucher.cid 
and voucher.id=pid;
ELSEIF ptype = 4 THEN 
SELECT voucher.vnno as vrno,voucher.type as mvno,voucher.amount,customers.id as cid,customers.code as ccode,voucher.vdate  
FROM voucher,voucherreceive,customers where 
voucher.id=voucherreceive.vid 
and  customers.id=voucher.cid
and voucher.id=pid;
ELSEIF ptype = 5 THEN 
SELECT voucher.vnno as vrno,voucher.type as mvno,voucher.amount,voucher.vdate,bankaccount.id as baid,bankaccount.code as bacode,
bankinfo.name as bname,bankaccount.name as baname,bankaccount.branchname as branchname,vouchercontra.checkno
FROM voucher,vouchercontra,bankaccount,bankinfo
where  bankaccount.id=vouchercontra.baccid
and   bankinfo.id=bankaccount.bankid
and voucher.id=vouchercontra.vid and voucher.id=pid;
ELSEIF ptype = 6 THEN 
SELECT voucher.vnno as vrno,voucher.type as mvno,voucher.amount,customers.id as cid,customers.code as ccode,voucher.vdate  
FROM voucher,voucherbkash,customers where 
voucher.id=voucherbkash.vid 
and  customers.id=voucher.cid
and voucher.id=pid;

ELSEIF ptype = 7 THEN 
SELECT voucher.vnno as vrno,voucher.type as mvno,voucher.amount,customers.id as cid,customers.code as ccode,voucher.vdate  
FROM voucher,vouchersap,customers where 
voucher.id=vouchersap.vid 
and  customers.id=voucher.cid
and voucher.id=pid;

ELSEIF ptype = 8 THEN 
SELECT voucher.vnno as vrno,voucher.type as mvno,voucher.amount,customers.id as cid,customers.code as ccode,voucher.vdate  
FROM voucher,voucherkcs,customers where 
voucher.id=voucherkcs.vid 
and  customers.id=voucher.cid
and voucher.id=pid;

ELSEIF ptype = 9 THEN 
SELECT voucher.vnno as vrno,voucher.type as mvno,voucher.amount,customers.id as cid,customers.code as ccode,voucher.vdate  
FROM voucher,vouchermbank,customers where 
voucher.id=vouchermbank.vid 
and  customers.id=voucher.cid
and voucher.id=pid;


END IF;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `bankaccount`
--

CREATE TABLE IF NOT EXISTS `bankaccount` (
`id` int(11) NOT NULL,
  `code` text COLLATE utf32_bin NOT NULL,
  `name` text COLLATE utf32_bin NOT NULL,
  `opendate` date NOT NULL,
  `exdate` date NOT NULL,
  `rate` decimal(10,2) NOT NULL,
  `openbalance` decimal(10,2) NOT NULL,
  `bankid` int(11) NOT NULL,
  `branchname` text COLLATE utf32_bin NOT NULL,
  `accotitle` text COLLATE utf32_bin NOT NULL,
  `coastatus` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Dumping data for table `bankaccount`
--

INSERT INTO `bankaccount` (`id`, `code`, `name`, `opendate`, `exdate`, `rate`, `openbalance`, `bankid`, `branchname`, `accotitle`, `coastatus`, `userid`, `created_at`, `updated_at`) VALUES
(1, 'B-21611', '118.110.17272', '2015-11-09', '2015-11-09', '6000.00', '0.00', 9, 'Islampur', 'j. Co. Battery Engineering Works', 1, 1, '2015-11-09 07:59:37', '2015-11-09 01:59:37'),
(2, 'B-25719', '103.117.47.009', '2015-11-09', '2015-11-09', '78.00', '45000.00', 3, 'English Road', 'Bimal Chandra Mondol', 0, 1, '2015-11-09 01:54:56', '2015-11-09 01:54:56'),
(3, 'B-19527', '6578030900', '2015-11-09', '2015-11-09', '7800.00', '56000.00', 3, 'Bangshal', 'Agrani Traders', 0, 1, '2015-11-09 01:55:31', '2015-11-09 01:55:31'),
(4, 'B-19572', '20986789000', '2015-11-09', '2015-11-09', '7800.00', '564000.00', 14, 'Nayabazar', 'Bimal Chandra Mondol', 0, 1, '2015-11-09 01:56:11', '2015-11-09 01:56:11'),
(5, 'B-7307', '5468000.678999', '2015-11-09', '2015-11-09', '76000.00', '629000.00', 5, 'Sadarghat', 'Bimal Chandra Mondol', 0, 1, '2015-11-09 01:56:48', '2015-11-09 01:56:48'),
(6, 'B-4346', '659000069', '2015-11-09', '2015-11-09', '8000.00', '0.00', 12, 'English Road', 'Agrani Traders', 0, 1, '2015-11-09 01:57:32', '2015-11-09 01:57:32'),
(7, 'B-32063', '768000', '2015-11-09', '2015-11-09', '7800.00', '0.00', 15, 'Islampur', 'Bimal Chandra Mondol', 0, 1, '2015-11-09 01:58:13', '2015-11-09 01:58:13'),
(8, 'B-13836', '439000', '2015-11-09', '2015-11-09', '600.00', '0.00', 4, 'Islampur', 'j. Co. Battery Engineering Works', 0, 1, '2015-11-09 02:00:36', '2015-11-09 02:00:36'),
(9, 'B-10134', '76589000', '2015-11-09', '2015-11-09', '500.00', '0.00', 13, 'Nayabazar', 'j. Co. Battery Engineering Works', 0, 1, '2015-11-09 02:01:03', '2015-11-09 02:01:03'),
(10, 'B-16151', '45900', '2015-11-09', '2015-11-09', '300.00', '0.00', 4, 'Islampur', 'j. Co. Battery Engineering Works', 0, 1, '2015-11-09 02:01:27', '2015-11-09 02:01:27');

-- --------------------------------------------------------

--
-- Table structure for table `bankbook`
--

CREATE TABLE IF NOT EXISTS `bankbook` (
`id` int(11) NOT NULL,
  `vid` int(11) NOT NULL,
  `baccid` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `checkno` text COLLATE utf32_bin NOT NULL,
  `dc` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `userid` int(11) NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Dumping data for table `bankbook`
--

INSERT INTO `bankbook` (`id`, `vid`, `baccid`, `sid`, `cid`, `checkno`, `dc`, `amount`, `userid`, `created_at`, `updated_at`) VALUES
(1, 6, 1, 38, 0, '', 0, '200000.00', 1, '2015-11-11', '2015-11-11'),
(2, 8, 1, 6, 0, '111', 0, '30000.00', 1, '2015-11-11', '2015-11-11'),
(3, 12, 3, 0, 0, '111', 0, '20000.00', 1, '2015-11-11', '2015-11-11'),
(4, 13, 1, 0, 0, '111', 0, '13000.00', 1, '2015-11-11', '2015-11-11'),
(5, 14, 1, 0, 0, '111', 0, '3000.00', 1, '2015-11-11', '2015-11-11'),
(6, 15, 1, 0, 0, '444', 1, '444.00', 1, '2015-11-11', '2015-11-11'),
(7, 15, 2, 0, 0, '444', 0, '444.00', 1, '2015-11-11', '2015-11-11'),
(8, 16, 2, 0, 0, '11', 1, '111.00', 1, '2015-11-11', '2015-11-11'),
(9, 22, 1, 0, 0, '', 0, '5000.00', 1, '2015-11-18', '2015-11-18'),
(10, 1, 1, 0, 2, '15400', 1, '5000.00', 1, '2015-11-19', '2015-11-19'),
(11, 3, 1, 0, 0, '444', 0, '3000.00', 1, '2015-11-24', '2015-11-24'),
(12, 4, 1, 0, 0, '1500', 1, '4500.00', 1, '2015-11-24', '2015-11-24'),
(13, 7, 1, 6, 0, '111', 0, '6000.00', 1, '2015-11-24', '2015-11-24'),
(14, 9, 1, 0, 2, '25444', 1, '3200.00', 1, '2015-11-24', '2015-11-24'),
(15, 10, 1, 7, 0, '1444', 0, '7777.00', 1, '2015-11-24', '2015-11-24'),
(16, 11, 1, 0, 0, '', 1, '12000.00', 1, '2015-11-24', '2015-11-24'),
(17, 11, 3, 0, 0, '', 0, '12000.00', 1, '2015-11-24', '2015-11-24'),
(18, 18, 1, 0, 3, '154014', 1, '10000.00', 1, '2015-12-01', '2015-12-01'),
(19, 1, 1, 7, 0, '6666', 0, '349000.00', 1, '2015-12-01', '2015-12-01'),
(20, 10, 2, 0, 0, '15474', 0, '9000.00', 1, '2015-12-01', '2015-12-01'),
(21, 11, 2, 0, 0, '157141', 1, '6000.00', 1, '2015-12-01', '2015-12-01'),
(22, 12, 1, 0, 2, '111', 1, '5000.00', 1, '2015-12-01', '2015-12-01'),
(23, 16, 2, 0, 0, '6666', 1, '12000.00', 1, '2015-12-04', '2015-12-04'),
(24, 16, 3, 0, 0, '6666', 0, '12000.00', 1, '2015-12-04', '2015-12-04'),
(25, 22, 1, 0, 50, '', 1, '20000.00', 1, '2015-12-06', '2015-12-06'),
(26, 27, 1, 40, 0, '123456', 0, '200000.00', 1, '2015-12-06', '2015-12-06'),
(27, 28, 1, 0, 0, '234567', 0, '20000.00', 1, '2015-12-06', '2015-12-06'),
(28, 29, 1, 0, 0, '123459', 0, '15000.00', 1, '2015-12-06', '2015-12-06');

-- --------------------------------------------------------

--
-- Table structure for table `bankinfo`
--

CREATE TABLE IF NOT EXISTS `bankinfo` (
`id` int(11) NOT NULL,
  `name` text NOT NULL,
  `userid` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bankinfo`
--

INSERT INTO `bankinfo` (`id`, `name`, `userid`, `created_at`, `updated_at`) VALUES
(1, 'NBL', 1, '2015-08-30 09:37:43', '2015-08-30 03:37:43'),
(3, 'IBBL', 1, '2015-08-16 04:49:03', '2015-08-15 22:49:03'),
(4, 'Rupali Bank', 1, '2015-08-11 04:30:49', '2015-08-11 04:30:49'),
(5, 'Dhaka Bank', 1, '2015-08-19 23:32:53', '2015-08-19 23:32:53'),
(6, 'Dhaka Bank', 1, '2015-08-26 23:08:47', '2015-08-26 23:08:47'),
(9, 'Sonali Bank', 1, '2015-08-30 02:45:25', '2015-08-30 02:45:25'),
(11, 'NBL1', 1, '2015-08-30 03:36:50', '2015-08-30 03:36:50'),
(12, 'Prime Bank', 1, '2015-09-20 03:30:03', '2015-09-20 03:30:03'),
(13, 'City Bank', 1, '2015-09-21 00:32:15', '2015-09-21 00:32:15'),
(14, 'Jamuna Bank ', 1, '2015-10-27 00:11:58', '2015-10-27 00:11:58'),
(15, 'Eastern Bank Limited', 1, '2015-10-27 01:23:38', '2015-10-27 01:23:38'),
(16, 'BRAC Bank ', 1, '2015-10-27 03:58:13', '2015-10-27 03:58:13'),
(17, 'Bangladesh Bank', 1, '2015-11-08 23:13:21', '2015-11-08 23:13:21'),
(18, '11111', 1, '2015-11-25 00:50:42', '2015-11-25 00:50:42');

-- --------------------------------------------------------

--
-- Table structure for table `banktitle`
--

CREATE TABLE IF NOT EXISTS `banktitle` (
`id` int(10) NOT NULL,
  `name` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `banktitle`
--

INSERT INTO `banktitle` (`id`, `name`) VALUES
(1, 'j. Co. Battery Engineering Works'),
(2, 'Agrani Traders'),
(3, 'Bimal Chandra Mondol'),
(4, 'J. Co. Distribution');

-- --------------------------------------------------------

--
-- Table structure for table `billspay`
--

CREATE TABLE IF NOT EXISTS `billspay` (
`id` int(11) NOT NULL,
  `purchaseid` int(11) NOT NULL,
  `purchasedate` datetime DEFAULT NULL,
  `amount` int(11) NOT NULL,
  `file` text COLLATE utf32_bin NOT NULL,
  `userid` int(11) NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Dumping data for table `billspay`
--

INSERT INTO `billspay` (`id`, `purchaseid`, `purchasedate`, `amount`, `file`, `userid`, `created_at`, `updated_at`) VALUES
(19, 9, '2015-08-04 00:00:00', 10000, '64957.jpg', 1, '2015-08-04', '2015-08-04'),
(20, 10, '2015-08-04 00:00:00', 50000, '18524.jpg', 1, '2015-08-04', '2015-08-04'),
(21, 16, '2015-08-06 00:00:00', 5101, '85649.jpg', 1, '2015-08-06', '2015-08-06'),
(22, 18, '2015-08-06 00:00:00', 5000, '77701.jpg', 1, '2015-08-06', '2015-08-06'),
(27, 33, '0000-00-00 00:00:00', 99999999, '32438.jpg', 1, '2015-08-13', '2015-08-16'),
(28, 34, '0000-00-00 00:00:00', 888, '20787.jpg', 1, '2015-08-13', '2015-08-13');

-- --------------------------------------------------------

--
-- Table structure for table `coa`
--

CREATE TABLE IF NOT EXISTS `coa` (
`id` int(11) NOT NULL,
  `coacode` text COLLATE utf32_bin NOT NULL,
  `code` text COLLATE utf32_bin NOT NULL,
  `name` text COLLATE utf32_bin NOT NULL,
  `openbalance` decimal(10,2) NOT NULL,
  `description` text COLLATE utf32_bin NOT NULL,
  `coatypeid` int(11) NOT NULL,
  `increasetypeid` int(11) NOT NULL,
  `taxrateid` int(11) NOT NULL,
  `fixedstatus` int(11) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Dumping data for table `coa`
--

INSERT INTO `coa` (`id`, `coacode`, `code`, `name`, `openbalance`, `description`, `coatypeid`, `increasetypeid`, `taxrateid`, `fixedstatus`, `userid`, `created_at`, `updated_at`) VALUES
(1, '0', 'A-1483858223', 'Cash A/C', '0.00', 'Cash A/C', 4, 3, 1, 1, 1, '2015-12-05 07:18:10', '2015-12-05 01:18:10'),
(2, '0', 'A-1187056164', 'Cash Collection A/C', '410000.00', 'Cash Collection', 19, 1, 1, 1, 1, '2015-12-06 11:27:09', '2015-12-06 05:27:09'),
(3, '0', 'A-1295454592', 'Cash Payment A/C', '6949419.00', 'Cash Payment A/C', 11, 2, 1, 1, 1, '2015-11-24 07:00:42', '2015-10-05 18:44:11'),
(4, '0', 'A-1778186978', 'Bkash A/C', '15035500.00', 'Bkash A/C', 11, 1, 1, 1, 1, '2015-09-27 22:22:46', '2015-09-27 16:22:46'),
(5, '0', 'A-1547883103', 'SAP A/C', '0.00', 'SAP A/C', 19, 1, 1, 1, 1, '2015-12-06 11:11:17', '2015-12-06 05:11:17'),
(6, '0', 'A-363575874', 'KCS A/C', '209800.00', 'KCS A/C', 11, 1, 2, 1, 1, '2015-09-27 22:23:25', '2015-09-27 16:23:25'),
(7, '0', 'A-1888579212', 'MBank A/C', '30513169.00', 'MBank A/C', 19, 1, 3, 1, 1, '2015-12-06 10:25:22', '2015-12-06 04:25:22'),
(8, '0', 'A-1834208617', 'Bank Collection A/C', '81982904.00', 'Bank Collection A/C', 11, 1, 3, 1, 1, '2015-09-27 22:24:28', '2015-09-27 16:24:28'),
(9, '0', 'A-1250471858', 'Bank Payment A/C', '37305.00', 'Bank Payment A/C', 11, 2, 2, 1, 1, '2015-11-24 07:01:18', '2015-10-05 18:44:58'),
(10, '0', 'A-1033391409', 'Bank A/C', '3073432.00', 'Bank A/C', 4, 1, 3, 1, 1, '2015-12-05 07:24:40', '2015-12-05 01:24:40'),
(11, '0', 'A-1869829128', 'SALES A/C', '82942463.00', 'SALES A/C', 5, 2, 1, 1, 1, '2015-09-17 02:40:49', '2015-09-16 23:05:22'),
(12, '0', 'A-1679066394', 'Purchase A/C', '290200.00', 'Purchase A/C', 6, 1, 3, 1, 1, '2015-09-17 02:41:04', '2015-09-16 23:06:51'),
(13, '0', 'A-109329080', 'Salary A/C', '212725.00', 'Salary A/C', 11, 2, 2, 1, 1, '2015-12-06 13:34:51', '2015-12-06 07:34:51'),
(14, '0', 'C-128', 'CLOSING STOCK', '0.00', 'CLOSING STOCK', 17, 1, 1, 1, 1, '2015-10-02 22:22:32', '0000-00-00 00:00:00'),
(15, '0', 'C-130', 'CLOSING STOCK', '0.00', 'CLOSING STOCK', 18, 2, 1, 1, 0, '2015-10-02 22:25:22', '0000-00-00 00:00:00'),
(16, '', 'CUS:10', 'Capital  A/C', '0.00', 'Capital  A/C', 20, 1, 1, 0, 1, '2015-12-05 05:45:24', '2015-12-04 23:45:24'),
(17, '', 'A-15469', 'Bank OD A/C', '0.00', 'Payment ', 1, 1, 1, 0, 1, '2015-12-05 05:48:20', '2015-12-04 23:48:20'),
(18, '', 'A-8910', 'Sundry Creditors', '0.00', 'www', 2, 2, 2, 0, 1, '2015-12-05 06:26:14', '2015-12-05 00:26:14'),
(19, '', 'A-26693', 'TEST A/C', '0.00', 'na', 11, 2, 1, 0, 1, '2015-12-01 04:41:05', '2015-12-01 04:41:05'),
(20, '', 'A-6638', 'Opening Balance', '0.00', 'NA', 12, 1, 1, 0, 1, '2015-12-05 00:40:42', '2015-12-05 00:40:42'),
(21, '', 'A-16015', 'Current Period', '0.00', 'na', 12, 1, 1, 0, 1, '2015-12-05 00:41:36', '2015-12-05 00:41:36'),
(22, '', 'A-21773', 'Furniture A/C', '0.00', 'Furniture A/C', 3, 1, 1, 0, 1, '2015-12-06 08:43:46', '2015-12-06 02:43:46'),
(23, '', 'A-9085', 'Land A/C', '0.00', 'Land A/C', 3, 1, 2, 0, 1, '2015-12-05 00:46:24', '2015-12-05 00:46:24'),
(24, '', 'A-21185', 'Sundry Deditors', '0.00', 'na', 4, 1, 1, 0, 1, '2015-12-05 01:26:29', '2015-12-05 01:26:29');

-- --------------------------------------------------------

--
-- Table structure for table `coatype`
--

CREATE TABLE IF NOT EXISTS `coatype` (
`id` int(11) NOT NULL,
  `name` text COLLATE utf32_bin NOT NULL,
  `userid` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Dumping data for table `coatype`
--

INSERT INTO `coatype` (`id`, `name`, `userid`, `created_at`, `updated_at`) VALUES
(1, 'Loan(Liability)', 1, '2015-09-15 04:18:39', '0000-00-00 00:00:00'),
(2, 'Current Liabilities', 1, '2015-09-15 04:19:00', '0000-00-00 00:00:00'),
(3, 'Fixed Assets', 1, '2015-09-15 04:19:25', '0000-00-00 00:00:00'),
(4, 'Current Assets', 1, '2015-09-15 04:19:58', '0000-00-00 00:00:00'),
(5, 'Sales Accounts', 1, '2015-09-15 04:20:23', '0000-00-00 00:00:00'),
(6, 'Purchase Acccounts', 1, '2015-09-15 04:20:55', '0000-00-00 00:00:00'),
(7, 'Bank Accounts', 1, '2015-09-15 04:21:38', '0000-00-00 00:00:00'),
(8, 'Customer Accounts', 1, '2015-09-15 04:22:07', '0000-00-00 00:00:00'),
(9, 'Supplier Accounts', 1, '2015-09-15 04:22:26', '0000-00-00 00:00:00'),
(10, 'Direct Expenses', 1, '2015-09-15 04:23:15', '2015-09-14 01:01:32'),
(11, 'Indirect Expenses', 1, '2015-09-15 04:23:38', '2015-09-14 01:07:39'),
(12, 'Profit & Loss Acccount', 1, '2015-09-15 04:24:51', '2015-09-14 01:10:33'),
(13, 'Equity', 1, '2015-09-15 04:27:16', '2015-09-14 01:11:24'),
(14, 'Cost Of goods', 1, '2015-09-15 04:28:04', '2015-09-14 01:18:10'),
(15, 'Salary Accounts', 1, '2015-09-15 04:28:32', '2015-09-14 05:56:22'),
(16, 'Accounts Payble', 1, '2015-09-15 05:53:35', '2015-09-14 23:52:04'),
(17, 'Opening Stock', 1, '2015-10-03 04:18:05', '0000-00-00 00:00:00'),
(18, 'Closing Stock', 1, '2015-10-03 04:18:05', '0000-00-00 00:00:00'),
(19, 'Cash-in-hand(Current Assets)', 1, '2015-12-05 04:32:41', '2015-10-12 02:23:12'),
(20, 'Capital Account', 1, '2015-12-05 08:45:38', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `companyprofile`
--

CREATE TABLE IF NOT EXISTS `companyprofile` (
`id` int(11) NOT NULL,
  `name` text COLLATE utf32_bin NOT NULL,
  `file` text COLLATE utf32_bin NOT NULL,
  `address` text COLLATE utf32_bin NOT NULL,
  `telephone` text COLLATE utf32_bin NOT NULL,
  `mobile` text COLLATE utf32_bin NOT NULL,
  `email` text COLLATE utf32_bin NOT NULL,
  `url` text COLLATE utf32_bin NOT NULL,
  `userid` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Dumping data for table `companyprofile`
--

INSERT INTO `companyprofile` (`id`, `name`, `file`, `address`, `telephone`, `mobile`, `email`, `url`, `userid`, `created_at`, `updated_at`) VALUES
(5, 'J. Co. Battery Engineering Works', '88902.jpg', '44,Tanti Bazar ,Dhaka-1100 , Bangladesd', '+88 02-5739539', '+880 1977991099', 'jcobattery1@gmail.com , info@jcobattery.com', 'http://www.jcobattery.com', 1, '2015-08-17 23:46:58', '2015-08-17 23:46:58'),
(6, 'J. Co. Battery Engineering Works', '54559.jpg', '44,Tanti Bazar ,Dhaka-1100 , Bangladesd', '+88 02-5739539', '+880 1977991099', 'jcobattery1@gmail.com , info@jcobattery.com', 'http://www.jcobattery.com', 1, '2015-08-17 23:49:07', '2015-08-17 23:49:07'),
(7, 'J. Co. Battery Engineering Works', '83577.jpg', '44,Tanti Bazar ,Dhaka-1100 , Bangladesh', '+88 02-5739539', '+880 1977991099', 'jcobattery1@gmail.com , info@jcobattery.com , info1@jcobattery.com', 'http://www.jcobattery.com', 1, '2015-08-18 06:41:43', '2015-08-17 23:49:53'),
(8, 'J. Co. Battery Engineering Works', '72930.jpg', '44,Tanti Bazar ,Dhaka-1100 , Bangladesh', '+88 02-5739539', '+880 1977991099', 'jcobattery1@gmail.com , info@jcobattery.com , info1@jcobattery.com', 'http://www.jcobattery.com', 1, '2015-08-18 22:07:24', '2015-08-18 22:07:24'),
(9, 'J. Co. Battery Engineering Works', '98071.jpg', '44,Tanti Bazar ,Dhaka-1100 , Bangladesh', '+88 02-5739539', '+880 1977991099', 'jcobattery1@gmail.com , info@jcobattery.com , info1@jcobattery.com', 'http://www.jcobattery.com', 1, '2015-08-23 03:46:54', '2015-08-23 03:46:54'),
(10, 'J. Co. Battery Engineering Works', '20258.png', '44,Tanti Bazar ,Dhaka-1100 , Bangladesh', '+88 02-5739539', '+880 1977991099', 'jcobattery1@gmail.com , info@jcobattery.com , info1@jcobattery.com', 'http://www.jcobattery.com', 1, '2015-08-23 03:47:27', '2015-08-23 03:47:27'),
(11, 'P. Co. Battery Engineering Works', '22707.png', '44,Tanti Bazar ,Dhaka-1100 , Bangladesh', '+88 02-5739539', '+880 1977991099', 'jcobattery1@gmail.com , info@jcobattery.com , info1@jcobattery.com', 'http://www.jcobattery.com', 1, '2015-08-23 21:54:11', '2015-08-23 21:54:11'),
(12, 'J Co. Battery Engineering Works', '68627.png', '44,Tanti Bazar ,Dhaka-1100 , Bangladesh', '+88 02-5739539', '+880 1977991099', 'jcobattery1@gmail.com , info@jcobattery.com , info1@jcobattery.com', 'http://www.jcobattery.com', 1, '2015-08-23 21:54:46', '2015-08-23 21:54:46'),
(13, 'J Co. Battery Engineering Works', '80506.jpg', '44,Tanti Bazar ,Dhaka-1100 , Bangladesh', '+88 02-5739539', '+880 1977991099', 'jcobattery1@gmail.com , info@jcobattery.com , info1@jcobattery.com', 'http://www.jcobattery.com', 1, '2015-08-24 05:34:54', '2015-08-24 05:34:54'),
(14, 'J Co. Battery Engineering Works', '37315.png', '44,Tanti Bazar ,Dhaka-1100 , Bangladesh', '+88 02-5739539', '+880 1977991099', 'jcobattery1@gmail.com , info@jcobattery.com , info1@jcobattery.com', 'http://www.jcobattery.com', 1, '2015-08-24 05:35:43', '2015-08-24 05:35:43'),
(15, 'J Co. Battery Engineering Works', '12920.png', '44,Tanti Bazar ,Dhaka-1100 , Bangladesh', '+88 02-5739539', '+880 1977991099', 'jcobattery1@gmail.com , info@jcobattery.com , info1@jcobattery.com', 'http://www.jcobattery.com', 1, '2015-09-07 01:04:23', '2015-09-07 01:04:23'),
(16, 'J Co. Battery Engineering Works', '38549.png', '44,Tanti Bazar ,Dhaka-1100 , Bangladesh', '+88 02-5739539', '+880 1977991099', 'jcobattery1@gmail.com , info@jcobattery.com , info1@jcobattery.com', 'http://www.jcobattery.com', 1, '2015-09-07 01:06:24', '2015-09-07 01:06:24'),
(17, 'J Co. Battery Engineering Works', '86805.gif', '44,Tanti Bazar ,Dhaka-1100 , Bangladesh', '+88 02-5739539', '+880 1977991099', 'jcobattery1@gmail.com , info@jcobattery.com , info1@jcobattery.com', 'http://www.jcobattery.com', 1, '2015-09-07 01:06:52', '2015-09-07 01:06:52'),
(18, 'J Co. Battery Engineering Works', '95581.png', '44,Tanti Bazar ,Dhaka-1100 , Bangladesh', '+88 02-5739539', '+880 1977991099', 'jcobattery1@gmail.com , info@jcobattery.com , info1@jcobattery.com', 'http://www.jcobattery.com', 1, '2015-09-07 01:08:43', '2015-09-07 01:08:43'),
(19, 'J Co. Battery Engineering Works', '76421.bmp', '44,Tanti Bazar ,Dhaka-1100 , Bangladesh', '+88 02-5739539', '+880 1977991099', 'jcobattery1@gmail.com , info@jcobattery.com , info1@jcobattery.com', 'http://www.jcobattery.com', 1, '2015-11-19 03:56:10', '2015-11-19 03:56:10'),
(20, 'J Co. Battery Engineering Works', '24145.bmp', '44,Tanti Bazar ,Dhaka-1100 , Bangladesh', '+88 02-5739539', '+880 1977991099', 'jcobattery1@gmail.com , info@jcobattery.com , info1@jcobattery.com', 'http://www.jcobattery.com', 1, '2015-11-19 04:54:43', '2015-11-19 04:54:43'),
(21, 'J Co. Battery Engineering Works', '46584.bmp', '44,Tanti Bazar ,Dhaka-1100 , Bangladesh', '+88 02-5739539', '+880 1977991099', 'jcobattery1@gmail.com , info@jcobattery.com , info1@jcobattery.com', 'http://www.jcobattery.com', 1, '2015-11-22 23:47:46', '2015-11-22 23:47:46'),
(22, 'J Co. Battery Engineering Works', '99099.jpg', '44,Tanti Bazar ,Dhaka-1100 , Bangladesh', '+88 02-5739539', '+880 1977991099', 'jcobattery1@gmail.com , info@jcobattery.com , info1@jcobattery.com', 'http://www.jcobattery.com', 1, '2015-12-01 04:13:58', '2015-12-01 04:13:58'),
(23, 'J Co. Battery Engineering Works', '15011.jpg', '44,Tanti Bazar ,Dhaka-1100 , Bangladesh', '+88 02-5739539', '+880 1977991099', 'jcobattery1@gmail.com , info@jcobattery.com , info1@jcobattery.com', 'http://www.jcobattery.com', 1, '2015-12-01 04:24:40', '2015-12-01 04:24:40');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE IF NOT EXISTS `customers` (
`id` int(11) NOT NULL,
  `code` text COLLATE utf32_bin NOT NULL,
  `name` text COLLATE utf32_bin NOT NULL,
  `preaddress` text COLLATE utf32_bin NOT NULL,
  `peraddress` text COLLATE utf32_bin NOT NULL,
  `phone` text COLLATE utf32_bin NOT NULL,
  `email` text COLLATE utf32_bin NOT NULL,
  `fax` text COLLATE utf32_bin NOT NULL,
  `url` text COLLATE utf32_bin NOT NULL,
  `openbalance` decimal(10,2) NOT NULL,
  `creditlimit` decimal(10,2) NOT NULL,
  `lastdue` decimal(10,2) NOT NULL DEFAULT '0.00',
  `bstatus` int(11) NOT NULL,
  `coastatus` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `updated_at` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `code`, `name`, `preaddress`, `peraddress`, `phone`, `email`, `fax`, `url`, `openbalance`, `creditlimit`, `lastdue`, `bstatus`, `coastatus`, `userid`, `created_at`, `updated_at`) VALUES
(1, 'CUS:10', 'Munlight Battery', 'Dhaka', 'Cox''s Bazar', '12345', 'mohsin@gmail.com', '98765', 'http://mohsin', '0.00', '50000.00', '527500.00', 1, 1, 1, '2015-08-02', '2015-12-06'),
(2, 'CUS:102 ', 'MBI International', 'Dhaka', 'Shutrapur', '98765', 'subrata@gmail.com', '12345', 'http://subrata', '2518.00', '250000.00', '-251432.72', 1, 0, 1, '2015-08-02', '2015-12-06'),
(3, 'S-103', 'Emon Battery', 'Gulshan 1,Dhaka-1212', 'Gulshan 1,Dhaka-1212', '019144462111', 'palash.ahmed@gmail.com', '+1 760 284 3360', '', '100000.00', '80000.00', '263441.00', 1, 0, 1, '2015-08-14', '2015-12-01'),
(4, 'C-32740', 'Beu Battery', 'gulshan', 'gulshan1', '0178886344', 'jco@gmail.com', '', '', '10500.00', '500000.00', '85501.00', 1, 0, 1, '2015-08-18', '2015-12-01'),
(5, 'C-10046', 'Mitu Battery Store', 'Dhaka ', 'Dhaka', '34563467', '', '', '', '20000.00', '0.00', '99999999.99', 1, 0, 1, '2015-08-20', '2015-11-23'),
(6, 'C-13500', 'SB battery', 'Gulsan, dhaka, bangladesh', 'Gulsan, dhaka, bangladesh', '1234567890', 'sb@gmail.com', '12345', '', '100000.00', '50000.00', '302446.00', 1, 0, 1, '2015-08-23', '2015-12-01'),
(7, 'C-25851', 'TNT', 'gulshan, Dhaka 1212', 'gulshan, Dhaka 1212', '0178886344', 'sascafs@outlook.com', '', 'http://www.sascafs.com', '19490.00', '20000.00', '0.00', 0, 0, 1, '2015-08-27', '2015-09-20'),
(10, 'C-4846', 'Babu Bhai', 'Lalbag', 'Lalbag', '21441111', '', '', '', '500000.00', '200000.00', '0.00', 0, 0, 1, '2015-08-30', '2015-09-13'),
(11, 'C-1229', 'Dhaka Battery Comilla', 'Comilla', 'Comilla', '21412414', '', '', '', '100000.00', '50000.00', '145000.00', 1, 0, 1, '2015-09-03', '2015-11-26'),
(12, 'C-26156', 'sasa', 'asas', 'asas', 'saas', 'sascafs@outlook.com', '', '', '30.20', '4.00', '0.00', 0, 0, 1, '2015-09-07', '2015-09-13'),
(13, 'C-5059', 'Joy', '', '', '', '', '', '', '1000.00', '5000.00', '0.00', 0, 0, 0, '2015-09-07', '2015-09-07'),
(14, 'C-32523', 'SAM IT', 'Dhaka', 'Dhaka', '0178554444', '', '', '', '48500.00', '250000.00', '0.00', 0, 0, 1, '2015-09-07', '2015-09-13'),
(15, 'C-17504', 'ymm', 'Dhaka', 'Dhaka', '0178886344', '', '', '', '2500.00', '50000.00', '0.00', 0, 0, 1, '2015-09-07', '2015-09-07'),
(16, 'C-22328', 'ss', 'dd', 'dd', '0123564+645+6', '', '', '', '50000.00', '250000.00', '0.00', 0, 0, 1, '2015-09-07', '2015-09-07'),
(18, 'C-13430', 'test', '', '', '', '', '', '', '50000.00', '10000.00', '0.00', 0, 0, 0, '2015-09-08', '2015-09-08'),
(19, 'C-12815', 'qqq', '', '', '', '', '', '', '2.30', '5.10', '0.00', 0, 0, 0, '2015-09-09', '2015-09-09'),
(20, 'C-12134', 'last122', '', '', '', '', '', '', '1111.00', '222.00', '0.00', 0, 0, 0, '2015-09-09', '2015-09-09'),
(21, 'C-27081', 'aa', '', '', '', '', '', '', '6.00', '8.00', '0.00', 0, 0, 0, '2015-09-09', '2015-09-09'),
(22, 'C-10311', 'Sumon', '', '', '', '', '', '', '100000.00', '1000.00', '0.00', 0, 0, 0, '2015-09-15', '2015-09-15'),
(23, 'C-10311', 'Sumon', '', '', '', '', '', '', '100000.00', '1000.00', '0.00', 0, 0, 0, '2015-09-15', '2015-09-15'),
(24, 'C-4259', 'Ireen', '', '', '', '', '', '', '18000.80', '8000.00', '0.00', 0, 0, 0, '2015-09-15', '2015-09-15'),
(25, 'C-16212', 'jijtf', '', '', '', '', '', '', '10000.99', '1000.80', '0.00', 0, 0, 0, '2015-09-15', '2015-09-15'),
(26, 'C-7966', 'Saidul', 'df', '', '1111-111-1111', '', '', '', '-22676023.00', '5000.00', '0.00', 0, 1, 1, '2015-09-15', '2015-10-14'),
(27, 'C-30527', 'Subrata Sarker', 'Sutrapur', 'Sutrapur', '1111-111-1111', '', '', '', '24500.00', '50000.00', '0.00', 0, 0, 1, '2015-09-20', '2015-09-20'),
(28, 'C-13330', 'MR ABC', 'sss', 'sss', '1111-111-1111', '', '', '', '270000.00', '250000.00', '340000.00', 1, 0, 1, '2015-10-14', '2015-11-05'),
(29, 'C-1630', 'Mr. ABCD', 'Dhaka', 'Dhaka', '1111-111-1111', '', '', '', '60000.00', '120000.00', '115000.00', 0, 1, 1, '2015-10-15', '2015-10-15'),
(30, 'C-29143', 'Mr. ABCDE', '', '', '', '', '', '', '100000.00', '180000.00', '-95790.00', 0, 1, 0, '2015-10-15', '2015-11-04'),
(31, 'C-22747', 'MR.L', '121212', '454545', '1234-123-1234', 'sa_sarker10@yahoo.com', 'ssss', '', '50000.00', '150000.00', '0.00', 0, 1, 1, '2015-09-01', '2015-10-15'),
(32, 'C-32456', 'MR.w', '111', '111', '1234-123-1234', 'sa_sarker10@yahoo.com', '12345', '', '20000.00', '120000.00', '0.00', 0, 1, 1, '2015-09-15', '2015-10-15'),
(33, 'C-24522', 'Customer A', 'address', 'aaaa', '1111-111-1111', '', '', '', '20000.00', '150000.00', '135000.00', 1, 1, 1, '2015-10-15', '2015-11-04'),
(34, 'C-1339', 'Customer B', 'address', '', '1111-111-1111', 'as@gmail.com', '', '', '15000.00', '100000.00', '65000.00', 1, 1, 1, '2015-10-15', '2015-11-05'),
(35, 'C-23659', 'SAS201', 'Dhaka', 'Dhaka', '01793532035', 'sascafs@gmail.com', '', '', '0.00', '0.00', '0.00', 0, 0, 1, '2015-10-25', '2015-10-25'),
(36, 'C-26355', '', '', '', '', '', '', '', '6.00', '5.00', '0.00', 0, 0, 0, '2015-10-28', '2015-10-28'),
(37, 'C-10625', 'MR. T', 'Tanti Bazar', 'Tanti Bazar', '1111-111-1111', '', '', '', '20000.00', '0.00', '49998.00', 0, 0, 1, '2015-10-29', '2015-10-29'),
(38, 'C-6692', 'MR. W', 'Tanti Bazar', 'Tanti Bazar', '1111-111-1111', 'sa_sarker10@yahoo.com', '', '', '15000.00', '0.00', '80000.00', 1, 1, 1, '2015-10-29', '2015-10-29'),
(39, 'C-4087', 'Mr. D', 'Gulshan', '', '', '', '', '', '5400.00', '0.00', '0.00', 0, 0, 0, '2015-10-29', '2015-10-29'),
(40, 'C-27662', 'R', 'uu', '', '', '', '', '', '0.00', '0.00', '0.00', 0, 0, 0, '2015-10-29', '2015-10-29'),
(41, 'C-17078', 'Info', 'Dhaka,', '', '', '', '', '', '7500.00', '0.00', '0.00', 1, 1, 0, '2015-10-29', '2015-10-29'),
(42, 'C-17902', 'asd', 'Dhaka', '', '', '', '', '', '2000.00', '0.00', '0.00', 0, 0, 0, '2015-11-01', '2015-11-01'),
(43, 'C-8160', 'gh', '546546', '', '5464', 'q@g.com', '', 'http://htrh', '2000.00', '4000.00', '0.00', 0, 0, 1, '2015-12-31', '2015-12-31'),
(44, 'C-13414', 'Bangla com', 'Damra, Daka', '', '', '', '', '', '50000.00', '0.00', '57300.00', 1, 1, 0, '2015-11-04', '2015-11-04'),
(45, 'C-17696', 'NMNM', 'Dhaka', '', '', '', '', '', '0.00', '0.00', '12000.00', 1, 1, 0, '2015-11-08', '2015-11-08'),
(46, 'C-5409', 'Customer Subrata', 'Dhaka', 'dhaka', '111-111-11111', '', '', '', '5000.00', '0.00', '0.00', 0, 0, 1, '2015-11-09', '2015-11-09'),
(47, 'C-26128', 'MR. Mohsin', 'Dhaka', '', '', '', '', '', '0.00', '0.00', '42000.00', 1, 0, 0, '2015-11-11', '2015-11-12'),
(48, 'C-22552', 'Mohsin ', 'COX', '', '0987654', '', '', '', '5000.00', '0.00', '0.00', 0, 0, 0, '2015-11-23', '2015-11-23'),
(49, 'C-21571', '', '', '', '', '', '', '', '0.00', '0.00', '0.00', 0, 0, 0, '2015-12-06', '2015-12-06'),
(50, 'C-30948', 'Mr. Shahin', 'Gulistan', '', '01711112050', '', '', '', '0.00', '0.00', '24000.00', 1, 0, 0, '2015-12-06', '2015-12-06');

-- --------------------------------------------------------

--
-- Table structure for table `customersledger`
--

CREATE TABLE IF NOT EXISTS `customersledger` (
`id` int(11) NOT NULL,
  `rv` int(11) NOT NULL,
  `sv` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `dc` int(11) NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Dumping data for table `customersledger`
--

INSERT INTO `customersledger` (`id`, `rv`, `sv`, `cid`, `amount`, `dc`, `created_at`, `updated_at`) VALUES
(1, 0, 3, 47, '15000.00', 0, '2015-11-11', '2015-11-11'),
(2, 3, 0, 47, '10000.00', 0, '2015-11-11', '2015-11-11'),
(3, 0, 4, 47, '30000.00', 0, '2015-11-11', '2015-11-11'),
(4, 4, 0, 47, '10000.00', 0, '2015-11-11', '2015-11-11'),
(5, 5, 0, 47, '8000.00', 0, '2015-11-11', '2015-11-11'),
(6, 0, 5, 47, '25000.00', 0, '2015-11-12', '2015-11-12'),
(7, 0, 1, 1, '15000.00', 0, '2015-11-11', '2015-11-11'),
(8, 0, 2, 2, '18000.00', 0, '2015-11-11', '2015-11-11'),
(9, 0, 1, 3, '30000.00', 0, '2015-11-11', '2015-11-11'),
(10, 0, 2, 6, '7000.00', 0, '2015-11-11', '2015-11-11'),
(11, 0, 3, 3, '24000.00', 0, '2015-11-11', '2015-11-11'),
(12, 0, 4, 1, '40000.00', 0, '2015-11-11', '2015-11-11'),
(13, 0, 5, 1, '4500.00', 0, '2015-11-11', '2015-11-11'),
(14, 0, 6, 1, '5000.00', 0, '2015-11-11', '2015-11-11'),
(15, 0, 7, 2, '50000.00', 0, '2015-11-11', '2015-11-11'),
(16, 0, 8, 1, '15000.00', 0, '2015-11-11', '2015-11-11'),
(17, 0, 9, 5, '5000.00', 0, '2015-11-11', '2015-11-11'),
(18, 10, 0, 2, '555.00', 0, '2015-11-11', '2015-11-11'),
(19, 11, 0, 2, '300.00', 0, '2015-11-11', '2015-11-11'),
(20, 0, 10, 2, '40000.00', 0, '2015-11-12', '2015-11-12'),
(21, 0, 11, 2, '5400.00', 0, '2015-11-12', '2015-11-12'),
(22, 0, 12, 4, '70000.00', 0, '2015-11-12', '2015-11-12'),
(23, 0, 13, 4, '40000.00', 0, '2015-11-12', '2015-11-12'),
(24, 0, 1, 1, '13000.00', 0, '2015-11-12', '2015-11-12'),
(25, 0, 1, 1, '8000.00', 0, '2015-11-12', '2015-11-12'),
(26, 0, 2, 1, '5000.00', 0, '2015-11-12', '2015-11-12'),
(27, 0, 3, 2, '5000.00', 0, '2015-11-12', '2015-11-12'),
(28, 0, 4, 2, '6000.00', 0, '2015-11-12', '2015-11-12'),
(29, 0, 1, 1, '3000.00', 0, '2015-11-12', '2015-11-12'),
(30, 0, 2, 1, '30000.00', 0, '2015-11-12', '2015-11-12'),
(31, 0, 3, 3, '3000.00', 0, '2015-11-12', '2015-11-12'),
(32, 0, 4, 3, '1500.00', 0, '2015-11-12', '2015-11-12'),
(33, 0, 5, 4, '15000.00', 0, '2015-11-12', '2015-11-12'),
(34, 0, 6, 4, '3000.00', 0, '2015-11-12', '2015-11-12'),
(35, 0, 7, 2, '9000.00', 0, '2015-11-12', '2015-11-12'),
(36, 17, 0, 2, '12000.00', 0, '2015-11-17', '2015-11-17'),
(37, 18, 0, 3, '6757.00', 0, '2015-11-17', '2015-11-17'),
(38, 19, 0, 2, '349000.00', 0, '2015-11-17', '2015-11-17'),
(39, 20, 0, 2, '10000.00', 1, '2015-11-17', '2015-11-17'),
(40, 21, 0, 2, '453453.00', 0, '2015-11-18', '2015-11-18'),
(41, 23, 0, 4, '9000.00', 0, '2015-11-18', '2015-11-18'),
(42, 0, 8, 1, '15000.00', 0, '2015-11-19', '2015-11-19'),
(43, 0, 9, 2, '30000.00', 0, '2015-11-19', '2015-11-19'),
(44, 1, 0, 2, '5000.00', 0, '2015-11-19', '2015-11-19'),
(45, 1, 0, 2, '5000.00', 1, '2015-11-19', '2015-11-19'),
(46, 2, 0, 2, '10000.00', 0, '2015-11-19', '2015-11-19'),
(47, 5, 0, 2, '10000.00', 0, '2015-11-24', '2015-11-24'),
(48, 6, 0, 2, '3000.00', 1, '2015-11-24', '2015-11-24'),
(49, 9, 0, 2, '3200.00', 0, '2015-11-24', '2015-11-24'),
(50, 13, 0, 4, '56000.00', 0, '2015-11-25', '2015-11-25'),
(51, 14, 0, 3, '0.00', 0, '2015-11-25', '2015-11-25'),
(52, 0, 10, 1, '500000.00', 0, '2015-11-25', '2015-11-25'),
(53, 0, 11, 2, '30000.00', 0, '2015-11-25', '2015-11-25'),
(54, 0, 12, 1, '10000.00', 0, '2015-11-26', '2015-11-26'),
(55, 0, 13, 11, '45000.00', 0, '2015-11-26', '2015-11-26'),
(56, 0, 14, 6, '6900.00', 0, '2015-11-26', '2015-11-26'),
(57, 0, 15, 6, '29996.00', 0, '2015-11-26', '2015-11-26'),
(58, 0, 16, 6, '5000.00', 0, '2015-11-26', '2015-11-26'),
(59, 0, 17, 2, '3020.00', 0, '2015-11-29', '2015-11-29'),
(60, 15, 0, 2, '5000.00', 0, '2015-12-01', '2015-12-01'),
(61, 16, 0, 2, '8000.00', 0, '2015-12-01', '2015-12-01'),
(62, 17, 0, 2, '6000.00', 0, '2015-12-01', '2015-12-01'),
(63, 0, 17, 1, '3000.00', 0, '2015-12-01', '2015-12-01'),
(64, 18, 0, 3, '10000.00', 0, '2015-12-01', '2015-12-01'),
(65, 2, 0, 3, '4000.00', 0, '2015-12-01', '2015-12-01'),
(66, 3, 0, 6, '3000.00', 0, '2015-12-01', '2015-12-01'),
(67, 4, 0, 7, '2000.00', 0, '2015-12-01', '2015-12-01'),
(68, 5, 0, 4, '8000.00', 0, '2015-12-01', '2015-12-01'),
(69, 6, 0, 2, '1000.00', 0, '2015-12-01', '2015-12-01'),
(70, 7, 0, 2, '8000.00', 1, '2015-12-01', '2015-12-01'),
(71, 8, 0, 4, '4999.00', 0, '2015-12-01', '2015-12-01'),
(72, 12, 0, 2, '5000.00', 0, '2015-12-01', '2015-12-01'),
(73, 0, 1, 1, '105000.00', 0, '2015-12-02', '2015-12-02'),
(74, 0, 2, 1, '40000.00', 0, '2015-12-03', '2015-12-03'),
(75, 13, 0, 3, '12000.00', 0, '2015-12-03', '2015-12-03'),
(76, 14, 0, 3, '12000.00', 0, '2015-12-03', '2015-12-03'),
(77, 0, 1, 2, '40000.00', 0, '2015-12-03', '2015-12-03'),
(78, 15, 0, 2, '349000.00', 1, '2015-12-03', '2015-12-03'),
(79, 0, 2, 2, '40000.00', 0, '2015-12-03', '2015-12-03'),
(80, 0, 3, 2, '1500.28', 0, '2015-12-02', '2015-12-02'),
(81, 0, 1, 1, '50000.00', 0, '2015-12-02', '2015-12-02'),
(82, 0, 2, 2, '40000.00', 0, '2015-12-02', '2015-12-02'),
(83, 0, 3, 2, '40000.00', 0, '2015-12-02', '2015-12-02'),
(84, 0, 4, 1, '100000.00', 0, '2015-12-03', '2015-12-03'),
(85, 0, 5, 2, '29992.00', 0, '2015-12-03', '2015-12-03'),
(86, 0, 6, 1, '30000.00', 0, '2015-12-05', '2015-12-05'),
(87, 17, 0, 2, '5000.00', 1, '2015-12-05', '2015-12-05'),
(88, 19, 0, 3, '5000.00', 1, '2015-12-06', '2015-12-06'),
(89, 20, 0, 2, '5000.00', 0, '2015-12-06', '2015-12-06'),
(90, 0, 1, 1, '22000.00', 0, '2015-12-06', '2015-12-06'),
(91, 0, 2, 50, '94000.00', 0, '2015-12-06', '2015-12-06'),
(92, 21, 0, 50, '10000.00', 1, '2015-12-06', '2015-12-06'),
(93, 22, 0, 50, '20000.00', 0, '2015-12-06', '2015-12-06'),
(94, 23, 0, 50, '10000.00', 0, '2015-12-06', '2015-12-06'),
(95, 24, 0, 50, '10000.00', 0, '2015-12-06', '2015-12-06'),
(96, 25, 0, 50, '20000.00', 0, '2015-12-06', '2015-12-06');

-- --------------------------------------------------------

--
-- Table structure for table `employeeinfo`
--

CREATE TABLE IF NOT EXISTS `employeeinfo` (
`id` int(11) NOT NULL,
  `name` text COLLATE utf32_bin NOT NULL,
  `designation` text COLLATE utf32_bin NOT NULL,
  `joindate` date NOT NULL,
  `peraddress` varchar(60) COLLATE utf32_bin NOT NULL,
  `preaddress` varchar(60) COLLATE utf32_bin NOT NULL,
  `basic_salary` decimal(10,2) NOT NULL,
  `house_rent` decimal(10,2) NOT NULL,
  `medical_expense` decimal(10,2) NOT NULL,
  `food_expense` decimal(10,2) NOT NULL,
  `conveyance` decimal(10,2) NOT NULL,
  `entertain_allowance` decimal(10,2) NOT NULL,
  `total_salary` decimal(10,2) NOT NULL,
  `qualification` varchar(60) COLLATE utf32_bin NOT NULL,
  `file` text COLLATE utf32_bin NOT NULL,
  `uid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `experience` text COLLATE utf32_bin NOT NULL,
  `contactno` text COLLATE utf32_bin NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Dumping data for table `employeeinfo`
--

INSERT INTO `employeeinfo` (`id`, `name`, `designation`, `joindate`, `peraddress`, `preaddress`, `basic_salary`, `house_rent`, `medical_expense`, `food_expense`, `conveyance`, `entertain_allowance`, `total_salary`, `qualification`, `file`, `uid`, `userid`, `experience`, `contactno`, `created_at`, `updated_at`) VALUES
(2, 'Employee_1', 'Sales Executive', '2015-09-02', 'Rajshahi', 'Dhaka', '5555.00', '0.00', '0.00', '0.00', '0.00', '0.00', '5555.00', '6', '93277.jpg', 17, 1, '', '0', '2015-09-14 03:13:31', '2015-09-06 19:13:24'),
(4, 'Employee_2', 'Senior Executive', '2015-09-02', 'Comilla', 'Comilla', '1213.00', '0.00', '0.00', '0.00', '0.00', '0.00', '1213.00', '3', '34372.png', 17, 1, '', '0', '2015-09-14 03:13:40', '2015-09-06 19:13:51'),
(9, 'Employee_3', 'Executive', '2015-09-02', 'Dhaka', 'Dhaka', '10000.00', '0.00', '0.00', '0.00', '0.00', '0.00', '10000.00', '3', '39122.gif', 17, 1, '', '0', '2015-09-14 03:14:01', '2015-09-06 19:13:04'),
(10, 'Employee_4', 'Executive', '2015-09-07', 'Dhaka', 'Comilla', '12345.00', '0.00', '0.00', '0.00', '0.00', '0.00', '12345.00', '3', '72140.jpg', 2, 1, '', '0', '2015-09-14 03:14:11', '2015-09-06 20:26:15'),
(11, 'Amran', 'PHP Programmer', '2015-05-02', 'Nakhal para', 'Nakhal para', '10000.00', '4000.00', '2000.00', '2000.00', '1000.00', '1000.00', '20000.00', 'Fresher', '45629.jpg', 17, 1, '0', '0', '2015-11-25 00:09:38', '2015-11-24 18:09:38'),
(12, 'Mohsin', 'PHP Programmer', '2015-04-01', 'Middle Badda', 'Middle Badda', '9000.00', '3000.00', '1500.00', '1500.00', '2000.00', '1000.00', '18000.00', 'Executive', '26733.jpg', 1, 1, '0', '0', '2015-11-25 00:09:08', '2015-11-24 18:09:08'),
(13, 'Timon', 'PHP Programmer', '2015-09-14', 'Rajshahi', 'Dhaka', '15000.00', '4000.00', '1000.00', '3000.00', '1000.00', '1000.00', '25250.00', 'Fresher', '94533.jpg', 0, 1, '', '0', '2015-11-17 02:13:45', '2015-11-16 20:13:45'),
(14, 'Anil Chandra Baroi', 'Senior Tecchnician', '2015-11-17', 'Keranigonj', 'Keranigonj', '2000.00', '1000.00', '1000.00', '100.00', '1000.00', '100.00', '5200.00', '1', '98478.jpg', 0, 1, 'ee', '0', '2015-11-17 02:50:49', '2015-11-16 20:50:49'),
(15, 'em_moheee', 'uyikueeee', '2015-11-17', 'jhheee', 'juyeee', '56564.00', '0.00', '0.00', '0.00', '0.00', '0.00', '5684.00', 'hgjeeee', '14027.jpg', 0, 1, 'hgjgj', '654565', '2015-11-17 02:12:36', '2015-11-16 20:12:36'),
(16, 'Madhu Chandra Sarker', 'Senior Tecchnician', '2015-11-17', 'Dhaka', 'Dhaka', '1500.00', '5.00', '3.00', '3.00', '46.00', '3.00', '1560.00', 'SSC', '39439.jpg', 0, 1, 'yutu', '2154124', '2015-11-17 02:49:11', '2015-11-16 20:49:11'),
(17, 'Mahir', 'PHP Programmer', '2015-12-05', 'gulshan2', 'Cox''s Bazar', '20000.00', '0.00', '0.00', '0.00', '0.00', '0.00', '20000.00', 'B Sc', '90719.jpg', 0, 1, 'fgh', '43564', '2015-12-04 22:50:06', '2015-12-04 22:50:06'),
(18, 'Santu Chandra Ghose', 'Senior Technician', '2015-12-06', 'Dhaka', 'Dhaka', '2500.00', '0.00', '0.00', '0.00', '0.00', '0.00', '2500.00', 'SSC', '57481.jpg', 0, 1, '6', '768676565', '2015-12-06 06:25:54', '2015-12-06 06:25:54'),
(19, 'Karthik Chandra Sarker', 'Senior Technician', '1980-12-06', 'Keranigonj', 'Keranigonj', '2250.00', '0.00', '0.00', '0.00', '0.00', '0.00', '2250.00', 'NA', '15727.jpg', 0, 1, '0', '01711112050', '2015-12-06 07:18:52', '2015-12-06 07:18:52');

-- --------------------------------------------------------

--
-- Table structure for table `employeesal`
--

CREATE TABLE IF NOT EXISTS `employeesal` (
`id` int(11) NOT NULL,
  `eid` int(11) NOT NULL,
  `basic` decimal(10,2) NOT NULL,
  `present` int(11) NOT NULL,
  `absent` int(11) NOT NULL,
  `conveyance` decimal(10,2) NOT NULL,
  `bonus` decimal(10,2) NOT NULL,
  `loanbalance` decimal(10,2) NOT NULL,
  `loandeduct` decimal(10,2) NOT NULL,
  `adsentdetuct` decimal(10,2) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `pid` int(11) NOT NULL,
  `vdate` date NOT NULL,
  `description` varchar(60) COLLATE utf32_bin NOT NULL,
  `userid` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `updated_at` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Dumping data for table `employeesal`
--

INSERT INTO `employeesal` (`id`, `eid`, `basic`, `present`, `absent`, `conveyance`, `bonus`, `loanbalance`, `loandeduct`, `adsentdetuct`, `amount`, `pid`, `vdate`, `description`, `userid`, `created_at`, `updated_at`) VALUES
(1, 4, '200.00', 0, 0, '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', 2, '2015-09-09', '114444', 1, '2015-09-09', '2015-09-09'),
(4, 2, '2000.00', 0, 0, '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', 4, '2015-09-09', 'we', 1, '2015-09-09', '2015-11-17'),
(5, 9, '5000.00', 0, 0, '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', 3, '2015-09-09', '441111', 1, '2015-09-09', '2015-09-09'),
(6, 4, '3.00', 0, 0, '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', 3, '2015-09-09', '222sss', 1, '2015-09-09', '2015-09-09'),
(7, 2, '2000.00', 0, 0, '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', 1, '2015-09-14', 'ssss', 1, '2015-09-14', '2015-09-14'),
(8, 2, '3000.00', 0, 0, '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', 3, '2015-09-14', 'fff', 1, '2015-09-14', '2015-09-14'),
(9, 2, '3000.00', 0, 0, '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', 3, '2015-09-14', 'fff', 1, '2015-09-14', '2015-09-14'),
(10, 11, '20000.00', 0, 0, '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', 1, '2015-09-14', 'Monthly Salary', 1, '2015-09-14', '2015-09-14'),
(11, 13, '7500.00', 0, 0, '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', 2, '2015-09-14', 'Bonus', 1, '2015-09-14', '2015-09-14'),
(12, 11, '20000.00', 0, 0, '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', 1, '2015-09-15', 'Monthly Salary', 1, '2015-09-15', '2015-09-15'),
(13, 10, '12345.00', 0, 0, '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', 1, '2015-09-15', 'www', 1, '2015-09-15', '2015-09-15'),
(14, 2, '500.00', 0, 0, '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', 2, '2015-09-15', 'bonus', 1, '2015-09-15', '2015-09-15'),
(15, 2, '2000.00', 0, 0, '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', 3, '2015-09-17', 'Overtime Exps A/C', 1, '2015-09-17', '2015-09-17'),
(16, 10, '2000.00', 0, 0, '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', 5, '2015-10-19', 'na', 1, '2015-10-19', '2015-10-19'),
(17, 2, '10000.00', 0, 0, '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', 1, '2015-10-19', '11111', 1, '2015-10-19', '2015-10-19'),
(18, 14, '2000.00', 6, 1, '1000.00', '500.00', '1200.00', '1200.50', '1500.00', '5000.00', 0, '2015-11-17', '4444', 1, '2015-11-17', '2015-11-17'),
(19, 14, '2000.00', 6, 1, '1200.00', '1500.00', '500.00', '200.00', '3000.00', '2500.00', 0, '2015-11-17', '11', 1, '2015-11-17', '2015-11-17'),
(20, 16, '1500.00', 6, 4, '300.00', '200.00', '600.00', '600.00', '411.00', '111.00', 0, '2015-11-17', 'llllll', 1, '2015-11-17', '2015-11-17'),
(21, 2, '5555.00', 3, 3, '3.00', '3.00', '3.00', '3.00', '3.00', '3.00', 0, '2015-11-24', '3', 1, '2015-11-24', '2015-11-24'),
(22, 2, '5555.00', 2, 2, '2.00', '2.00', '2.00', '2.00', '2.00', '2.00', 0, '2015-11-25', '2', 1, '2015-11-25', '2015-11-25'),
(23, 17, '20000.00', 7, 3, '8.00', '2.00', '6.00', '5.00', '8.00', '3.00', 0, '2015-12-05', 'tytt', 1, '2015-12-05', '2015-12-05'),
(24, 18, '2500.00', 5, 0, '0.00', '0.00', '5000.00', '500.00', '2000.00', '2000.00', 0, '2015-12-06', '', 1, '2015-12-06', '2015-12-06'),
(25, 18, '2500.00', 5, 1, '0.00', '0.00', '4500.00', '500.00', '0.00', '2000.00', 0, '2015-12-06', '', 1, '2015-12-06', '2015-12-06'),
(26, 18, '2500.00', 4, 2, '200.00', '300.00', '4000.00', '0.00', '800.00', '2200.00', 0, '2015-12-06', '', 1, '2015-12-06', '2015-12-06'),
(27, 19, '2250.00', 4, 2, '0.00', '0.00', '10000.00', '1000.00', '500.00', '1750.00', 0, '2015-12-06', '', 1, '2015-12-06', '2015-12-06');

-- --------------------------------------------------------

--
-- Table structure for table `factioyitems`
--

CREATE TABLE IF NOT EXISTS `factioyitems` (
`id` int(11) NOT NULL,
  `itemsid` int(11) NOT NULL,
  `slno` text COLLATE utf32_bin NOT NULL,
  `salesid` int(11) DEFAULT NULL,
  `rstatus` int(11) NOT NULL DEFAULT '0',
  `randno` int(11) NOT NULL,
  `same_status` int(11) NOT NULL,
  `no` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `dstatus` int(11) NOT NULL DEFAULT '0',
  `feedback` text COLLATE utf32_bin NOT NULL,
  `sale_product` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Dumping data for table `factioyitems`
--

INSERT INTO `factioyitems` (`id`, `itemsid`, `slno`, `salesid`, `rstatus`, `randno`, `same_status`, `no`, `status`, `dstatus`, `feedback`, `sale_product`, `userid`, `created_at`, `updated_at`) VALUES
(1, 1, 'TAEM0600001', 1, 0, 0, 0, 1, 1, 0, '', 1, 1, '2015-12-06', '2015-12-06'),
(2, 1, 'TAEM0600002', 2, 1, 0, 1, 2, 1, 0, '', 1, 1, '2015-12-06', '2015-12-06'),
(3, 1, 'TAEM0600003', 2, 0, 0, 0, 3, 1, 0, '', 1, 1, '2015-12-06', '2015-12-06'),
(4, 1, 'TAEM0600004', 2, 0, 0, 0, 4, 1, 0, '', 1, 1, '2015-12-06', '2015-12-06'),
(5, 1, 'TAEM0600005', 2, 0, 0, 0, 5, 1, 0, '', 1, 1, '2015-12-06', '2015-12-06'),
(6, 1, 'TAEM0600006', NULL, 0, 0, 0, 6, 1, 0, '', 0, 1, '2015-12-06', '2015-12-06'),
(7, 1, 'TAEM0600007', NULL, 0, 0, 0, 7, 1, 0, '', 0, 1, '2015-12-06', '2015-12-06'),
(8, 1, 'TAEM0600008', NULL, 0, 0, 0, 8, 1, 0, '', 0, 1, '2015-12-06', '2015-12-06'),
(9, 1, 'TAEM0600009', NULL, 0, 0, 0, 9, 1, 0, '', 0, 1, '2015-12-06', '2015-12-06'),
(10, 1, 'TAEM0600010', NULL, 0, 0, 0, 10, 1, 0, '', 0, 1, '2015-12-06', '2015-12-06'),
(11, 1, 'TAEM0600011', NULL, 0, 0, 0, 11, 1, 0, '', 0, 1, '2015-12-06', '2015-12-06'),
(12, 1, 'TAEM0600012', NULL, 0, 0, 0, 12, 1, 0, '', 0, 1, '2015-12-06', '2015-12-06'),
(13, 1, 'TAEM0600013', NULL, 0, 0, 0, 13, 1, 0, '', 0, 1, '2015-12-06', '2015-12-06'),
(14, 1, 'TAEM0600014', NULL, 0, 0, 0, 14, 1, 0, '', 0, 1, '2015-12-06', '2015-12-06'),
(15, 1, 'TAEM0600015', NULL, 0, 0, 0, 15, 1, 0, '', 0, 1, '2015-12-06', '2015-12-06'),
(16, 7, 'TAEM0600016', NULL, 0, 0, 0, 16, 1, 0, '', 0, 1, '2015-12-06', '2015-12-06'),
(17, 7, 'TAEM0600017', NULL, 0, 0, 0, 17, 1, 0, '', 0, 1, '2015-12-06', '2015-12-06'),
(18, 7, 'TAEM0600018', NULL, 0, 0, 0, 18, 1, 0, '', 0, 1, '2015-12-06', '2015-12-06'),
(19, 7, 'TAEM0600019', NULL, 0, 0, 0, 19, 1, 0, '', 0, 1, '2015-12-06', '2015-12-06'),
(20, 7, 'TAEM0600020', NULL, 0, 0, 0, 20, 1, 0, '', 0, 1, '2015-12-06', '2015-12-06'),
(21, 7, 'TAEM0600021', NULL, 0, 0, 0, 21, 1, 0, '', 0, 1, '2015-12-06', '2015-12-06'),
(22, 7, 'TAEM0600022', NULL, 0, 0, 0, 22, 1, 0, '', 0, 1, '2015-12-06', '2015-12-06'),
(23, 7, 'TAEM0600023', NULL, 0, 0, 0, 23, 1, 0, '', 0, 1, '2015-12-06', '2015-12-06'),
(24, 7, 'TAEM0600024', NULL, 0, 0, 0, 24, 1, 0, '', 0, 1, '2015-12-06', '2015-12-06'),
(25, 7, 'TAEM0600025', NULL, 0, 0, 0, 25, 1, 0, '', 0, 1, '2015-12-06', '2015-12-06'),
(26, 7, 'TAEM0600026', NULL, 0, 0, 0, 26, 1, 0, '', 0, 1, '2015-12-06', '2015-12-06'),
(27, 7, 'TAEM0600027', NULL, 0, 0, 0, 27, 1, 0, '', 0, 1, '2015-12-06', '2015-12-06'),
(28, 7, 'TAEM0600028', NULL, 0, 0, 0, 28, 1, 0, '', 0, 1, '2015-12-06', '2015-12-06'),
(29, 7, 'TAEM0600029', NULL, 0, 0, 0, 29, 1, 0, '', 0, 1, '2015-12-06', '2015-12-06'),
(30, 7, 'TAEM0600030', NULL, 0, 0, 0, 30, 1, 0, '', 0, 1, '2015-12-06', '2015-12-06'),
(31, 7, 'TAEM0600031', NULL, 0, 0, 0, 31, 1, 0, '', 0, 1, '2015-12-06', '2015-12-06'),
(32, 7, 'TAEM0600032', NULL, 0, 0, 0, 32, 1, 0, '', 0, 1, '2015-12-06', '2015-12-06'),
(33, 7, 'TAEM0600033', NULL, 0, 0, 0, 33, 1, 0, '', 0, 1, '2015-12-06', '2015-12-06'),
(34, 7, 'TAEM0600034', NULL, 0, 0, 0, 34, 1, 0, '', 0, 1, '2015-12-06', '2015-12-06'),
(35, 7, 'TAEM0600035', NULL, 0, 0, 0, 35, 1, 0, '', 0, 1, '2015-12-06', '2015-12-06'),
(36, 132, 'TAEM0600036', 1, 1, 0, 1, 36, 1, 0, '', 1, 1, '2015-12-06', '2015-12-06'),
(37, 132, 'TAEM0600037', 1, 0, 4477, 0, 37, 1, 1, '', 1, 1, '2015-12-06', '2015-12-06'),
(38, 132, 'TAEM0600038', 1, 1, 4477, 0, 38, 1, 0, '', 1, 1, '2015-12-06', '2015-12-06'),
(39, 132, 'TAEM0600039', 2, 0, 0, 0, 39, 1, 0, '', 1, 1, '2015-12-06', '2015-12-06'),
(40, 132, 'TAEM0600040', 2, 0, 0, 0, 40, 1, 0, '', 1, 1, '2015-12-06', '2015-12-06'),
(41, 132, 'TAEM0600041', 2, 1, 29393, 0, 41, 1, 0, '', 1, 1, '2015-12-06', '2015-12-06'),
(42, 132, 'TAEM0600042', NULL, 0, 0, 0, 42, 1, 0, '', 0, 1, '2015-12-06', '2015-12-06'),
(43, 132, 'TAEM0600043', NULL, 0, 0, 0, 43, 1, 0, '', 0, 1, '2015-12-06', '2015-12-06'),
(44, 132, 'TAEM0600044', 2, 0, 29393, 0, 44, 1, 1, '', 1, 1, '2015-12-06', '2015-12-06'),
(45, 132, 'TAEM0600045', 2, 0, 0, 0, 45, 1, 0, '', 1, 1, '2015-12-06', '2015-12-06'),
(46, 132, 'TAEM0600046', 2, 0, 0, 0, 46, 1, 0, '', 1, 1, '2015-12-06', '2015-12-06'),
(47, 132, 'TAEM0600047', 2, 0, 0, 0, 47, 1, 0, '', 1, 1, '2015-12-06', '2015-12-06'),
(48, 132, 'TAEM0600048', 2, 0, 0, 0, 48, 1, 0, '', 1, 1, '2015-12-06', '2015-12-06'),
(49, 132, 'TAEM0600049', NULL, 0, 0, 0, 49, 1, 0, '', 0, 1, '2015-12-06', '2015-12-06'),
(50, 132, 'TAEM0600050', NULL, 0, 0, 0, 50, 1, 0, '', 0, 1, '2015-12-06', '2015-12-06'),
(51, 132, 'TAEM0600051', NULL, 0, 0, 0, 51, 1, 0, '', 0, 1, '2015-12-06', '2015-12-06'),
(52, 132, 'TAEM0600052', NULL, 0, 0, 0, 52, 1, 0, '', 0, 1, '2015-12-06', '2015-12-06'),
(53, 132, 'TAEM0600053', NULL, 0, 0, 0, 53, 1, 0, '', 0, 1, '2015-12-06', '2015-12-06'),
(54, 132, 'TAEM0600054', NULL, 0, 0, 0, 54, 1, 0, '', 0, 1, '2015-12-06', '2015-12-06'),
(55, 132, 'TAEM0600055', NULL, 0, 0, 0, 55, 1, 0, '', 0, 1, '2015-12-06', '2015-12-06');

-- --------------------------------------------------------

--
-- Table structure for table `increasetype`
--

CREATE TABLE IF NOT EXISTS `increasetype` (
`id` int(11) NOT NULL,
  `name` text COLLATE utf32_bin NOT NULL,
  `userid` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Dumping data for table `increasetype`
--

INSERT INTO `increasetype` (`id`, `name`, `userid`, `created_at`, `updated_at`) VALUES
(1, 'Debit', 1, '2015-08-12 05:06:47', '0000-00-00 00:00:00'),
(2, 'Credit', 1, '2015-08-12 05:07:04', '0000-00-00 00:00:00'),
(3, 'Debit/Credit', 1, '2015-08-13 04:22:25', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE IF NOT EXISTS `items` (
`id` int(11) NOT NULL,
  `itemssubgroupid` int(11) NOT NULL,
  `code` text COLLATE utf32_bin NOT NULL,
  `name` text COLLATE utf32_bin NOT NULL,
  `quantity` int(11) NOT NULL,
  `salesqnt` int(11) NOT NULL,
  `mesid` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `sstatus` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=133 DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `itemssubgroupid`, `code`, `name`, `quantity`, `salesqnt`, `mesid`, `price`, `sstatus`, `userid`, `created_at`, `updated_at`) VALUES
(1, 1, 'I-19937', '6 JBT 50A-20AH', 100, 0, 3, '0.00', 1, 1, '2015-08-13', '2015-10-28'),
(2, 1, 'I-6606', '6 JBT 50A-30AH', 200, 0, 3, '0.00', 1, 1, '2015-08-13', '2015-10-28'),
(3, 1, 'I-9638', '6 BBT 100A-60AH', 200, 0, 3, '0.00', 1, 0, '2015-08-13', '2015-08-17'),
(4, 1, 'I-14026', '6 BBT 120A-80AH', 10, 0, 3, '0.00', 1, 0, '2015-08-13', '2015-08-17'),
(5, 1, 'I-4155', '6 JBT 150A-100AH', 50, 0, 3, '0.00', 1, 1, '2015-08-13', '2015-08-13'),
(6, 1, 'I-18110', '6 JBT N200A-100AH', 25, 0, 3, '0.00', 1, 0, '2015-08-13', '2015-08-17'),
(7, 2, 'I-25492', '6 BBT 100A-60AH', 50, 0, 3, '0.00', 1, 1, '2015-08-13', '2015-08-13'),
(8, 2, 'I-11837', '6 JBT 120A-90AH', 15, 0, 3, '0.00', 1, 0, '2015-08-13', '2015-08-17'),
(9, 2, 'I-30254', '6 JBT 150A-120AH', 50, 0, 3, '0.00', 1, 1, '2015-08-13', '2015-08-13'),
(10, 2, 'I-1487', '6 JBT 200A-140AH', 50, 0, 3, '0.00', 1, 1, '2015-08-13', '2015-08-13'),
(11, 2, 'I-15196', '6 JBT 200A-160AH', 50, 0, 3, '0.00', 1, 1, '2015-08-13', '2015-08-13'),
(12, 2, 'I-32357', '6 JBT N-200AH', 50, 0, 3, '0.00', 1, 1, '2015-08-13', '2015-08-13'),
(13, 3, 'I-18234', 'NS 40ZL', 50, 0, 3, '0.00', 1, 1, '2015-08-13', '2015-08-13'),
(14, 3, 'I-12267', 'NS 60/L/S', 50, 0, 3, '0.00', 1, 1, '2015-08-13', '2015-08-13'),
(15, 3, 'I-16259', 'N50Z/ZL', 50, 0, 3, '0.00', 1, 1, '2015-08-13', '2015-08-13'),
(16, 2, 'I-9472', 'NS 70/L', 50, 0, 3, '0.00', 1, 1, '2015-08-13', '2015-08-13'),
(17, 2, 'I-13087', 'N70', 50, 0, 3, '0.00', 1, 1, '2015-08-13', '2015-08-13'),
(18, 2, 'I-12616', 'NX 120-7/L', 50, 0, 3, '0.00', 1, 1, '2015-08-13', '2015-08-13'),
(19, 4, 'I-7137', 'J.CO 70-15', 50, 0, 3, '0.00', 1, 1, '2015-08-13', '2015-08-13'),
(20, 4, 'I-26220', 'J.CO 100-17', 50, 0, 3, '0.00', 1, 1, '2015-08-13', '2015-08-13'),
(21, 4, 'I-13365', 'J.CO 120-21', 50, 0, 3, '0.00', 1, 1, '2015-08-13', '2015-08-13'),
(22, 4, 'I-4298', 'J.CO 200-27', 50, 0, 3, '0.00', 1, 1, '2015-08-13', '2015-08-13'),
(23, 4, 'I-25147', 'J.CO 200Z-29', 50, 0, 3, '0.00', 1, 1, '2015-08-13', '2015-08-13'),
(24, 5, 'I-32088', 'J.CO EB120', 50, 0, 3, '0.00', 1, 1, '2015-08-13', '2015-08-13'),
(25, 5, 'I-24241', 'J.CO EB140', 50, 0, 3, '0.00', 1, 1, '2015-08-13', '2015-08-13'),
(26, 6, 'I-26391', 'J.CO Power 50', 50, 0, 3, '0.00', 1, 1, '2015-08-13', '2015-08-13'),
(27, 6, 'I-23419', 'J.Co Power 65', 50, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(28, 6, 'I-20107', 'J.Co Power 75', 50, 0, 3, '0.00', 1, 0, '2015-08-16', '2015-08-16'),
(29, 6, 'I-7576', 'J.Co Power 85', 100, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(30, 7, 'I-6641', '90 Positive Plate', 0, 1250, 3, '0.00', 0, 1, '2015-08-16', '2015-11-05'),
(31, 7, 'I-19242', '90 Negative Plate', 235, 140, 3, '0.00', 0, 1, '2015-08-16', '2015-11-05'),
(32, 7, 'I-32027', '80 Positive Plate', 65, 0, 3, '0.00', 0, 1, '2015-08-16', '2015-10-29'),
(33, 7, 'I-31592', '80 Negative Plate', 100, 0, 3, '0.00', 0, 1, '2015-08-16', '2015-08-16'),
(34, 7, 'I-16216', '70 Positive Plate', 1100, 0, 3, '0.00', 0, 1, '2015-08-16', '2015-08-16'),
(35, 7, 'I-26187', '70 Negative Plate', 100, 0, 3, '0.00', 0, 1, '2015-08-16', '2015-08-16'),
(36, 7, 'I-32054', 'Faruka Positive Plate', 100, 0, 3, '0.00', 0, 1, '2015-08-16', '2015-08-16'),
(37, 7, 'I-6184', 'Faruka Negative Plate', 100, 0, 3, '0.00', 0, 1, '2015-08-16', '2015-08-16'),
(38, 7, 'I-30897', 'Auto Positive Plate', 100, 0, 3, '0.00', 0, 1, '2015-08-16', '2015-08-16'),
(39, 7, 'I-406', 'Auto Negative Plate', 134, 0, 3, '0.00', 0, 1, '2015-08-16', '2015-08-16'),
(40, 7, 'I-4458', 'Tabular Positive Plate(N-120)', 100, 0, 3, '0.00', 0, 1, '2015-08-16', '2015-08-16'),
(41, 7, 'I-10561', 'Tabular Negative Plate(N-3.5)', 100, 0, 3, '0.00', 0, 1, '2015-08-16', '2015-08-16'),
(42, 7, 'I-26203', 'Tabular Positive Plate(N-1.7)', 100, 0, 3, '0.00', 0, 1, '2015-08-16', '2015-08-16'),
(43, 7, 'I-11960', 'Tabular Negative Plate(N-1.5)', 200, 25000, 3, '0.00', 0, 1, '2015-08-16', '2015-11-25'),
(44, 8, 'I-32504', 'China Separator', 100, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(45, 8, 'I-20433', 'Glas Separator', 100, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(46, 8, 'I-23094', 'P.E Separator', 100, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(47, 8, 'I-4375', 'Auto Separator', 100, 0, 3, '0.00', 1, 0, '2015-08-16', '2015-08-16'),
(48, 9, 'I-31571', 'Bitumen', 100, 0, 7, '0.00', 1, 1, '2015-08-16', '2015-10-27'),
(49, 10, 'I-8084', 'N-200 Container', 100, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(50, 10, 'I-14909', 'N-150 Container', 100, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(51, 10, 'I-7379', 'N-120 Container', 100, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(52, 10, 'I-10163', 'N-70 Container', 100, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(53, 10, 'I-16400', 'N-50 Container', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(54, 19, 'I-22281', 'Solarland 10wp Panel', 10, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(55, 19, 'I-10710', 'Solarland 20wp Panel', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(56, 19, 'I-28897', 'Solarland 30wp Panel', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(57, 19, 'I-32014', 'Solarland 40wp Panel', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(58, 19, 'I-8560', 'Solarland 50wp Panel', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(59, 19, 'I-29598', 'Solarland 100wp Panel', 0, 0, 3, '0.00', 1, 0, '2015-08-16', '2015-08-16'),
(60, 19, 'I-13103', 'Solarland 110wp Panel', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(61, 19, 'I-3711', 'Solarland 120wp Panel', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(62, 19, 'I-19772', 'Solarland 120wp Panel', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(63, 19, 'I-3305', 'Solarland 130wp Panel', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(64, 19, 'I-11630', 'Solarland 200wp Panel', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(65, 19, 'I-3087', 'Kyocera 40wp panel', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(66, 19, 'I-3749', 'Kyocera 50wp panel', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(67, 19, 'I-12922', 'Kyocera 65wp panel', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(68, 19, 'I-3660', 'GSPV 20wp panel', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(69, 19, 'I-28309', 'GSPV 40wp panel', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(70, 19, 'I-19974', 'GSPV 50wp panel', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(71, 19, 'I-11178', 'GSPV 85wp panel', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(72, 19, 'I-5019', 'GSPV 100wp panel', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(73, 19, 'I-17208', 'GSPV 130wp panel', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(74, 19, 'I-24337', 'Greenfinity 20wp Panel ', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(75, 19, 'I-22646', 'Greenfinity 40wp Panel ', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(76, 19, 'I-15559', 'Greenfinity 50wp Panel ', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(77, 12, 'I-13044', '400 VA Frendy', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(78, 12, 'I-27521', '700 VA Shark', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(79, 12, 'I-20087', '900 VA Shark', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(80, 12, 'I-31967', '1500 VA Shark', 0, 0, 3, '0.00', 1, 0, '2015-08-16', '2015-08-16'),
(81, 12, 'I-23083', '1000 VA Torque', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(82, 12, 'I-16543', '600 VA Falcon', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(83, 12, 'I-9708', '800 VA Falcon', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(84, 12, 'I-15797', '1400 VA Falcon', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(85, 13, 'I-19756', '5W Charge Controller', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(86, 13, 'I-29685', '10W Charge Controller', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(87, 13, 'I-7242', '20W Charge Controller', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(88, 14, 'I-13528', 'Battery Charger - 60V', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(89, 14, 'I-23373', 'Battery Charger-72V', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(90, 16, 'I-13399', 'Lead', 0, 0, 1, '0.00', 1, 0, '2015-08-16', '2015-08-18'),
(91, 16, 'I-1538', 'Antimony', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(92, 16, 'I-17446', 'Antimonial Lead', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(93, 16, 'I-3796', 'Grey Oxide', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(94, 16, 'I-6269', 'Red Oxide', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(95, 16, 'I-16720', 'Tin', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(96, 16, 'I-13170', 'Arsenic', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(97, 16, 'I-24393', 'Fiber Flock', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(98, 16, 'I-78', 'Pipe Bottom', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(99, 16, 'I-5487', 'Pure Lead', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(100, 16, 'I-8828', 'Parafin Oil', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(101, 16, 'I-9989', 'Hydrocloric Acid', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(102, 16, 'I-23237', 'Cork Powder', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(103, 18, 'I-21338', 'Su-Kam', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(104, 18, 'I-11912', '400 VA Frendy', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(105, 18, 'I-18535', '700 VA Shark', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(106, 18, 'I-27240', '1400 VA Falcon', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(107, 18, 'I-11905', '1500 VA Shark', 100, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(108, 18, 'I-19238', '1000 VA Torque', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(109, 18, 'I-28705', '900 VA Shark', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(110, 17, 'I-9361', 'N-200 Upper Packing', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(111, 17, 'I-13646', 'N-150 Upper Packing', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(112, 17, 'I-31814', 'N-120 Upper Packing', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(113, 17, 'I-28662', 'N-50Upper Packing', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(114, 17, 'I-9839', '12 mm Side Packing', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(115, 17, 'I-28167', '10 mm Side Packing', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(116, 17, 'I-31556', '5 mm Side Packing', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(117, 17, 'I-11060', '20 Ah Carton', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(118, 17, 'I-27997', '100 Ah Carton', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(119, 17, 'I-14877', '60 AH carton', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(120, 17, 'I-24444', '130 AH Carton', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(121, 17, 'I-5842', 'N-200 Cork Sheet', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(122, 17, 'I-14138', 'N-50 Cork Sheet', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(123, 17, 'I-20471', 'N-70 Cork Sheet', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(124, 17, 'I-32356', 'N-150 Cork Sheet', 0, 0, 3, '0.00', 1, 1, '2015-08-16', '2015-08-16'),
(125, 20, 'I-1957', 'Keyboard', 2, 0, 3, '1000.00', 1, 1, '2015-08-27', '2015-08-27'),
(126, 1, 'I-19953', '6 JBT Solar 100', 40, 0, 3, '0.00', 1, 1, '2015-09-13', '2015-09-13'),
(127, 23, 'I-29358', 'fghyft', 2, 0, 7, '700.00', 1, 1, '2015-10-28', '2015-10-28'),
(128, 23, 'I-46', 'iiii55', 3, 0, 7, '200.00', 1, 1, '2015-10-28', '2015-10-28'),
(129, 6, 'I-6894', 'test5', 10, 0, 7, '120.00', 1, 1, '2015-10-28', '2015-10-28'),
(130, 13, 'I-17290', 'gslno', 5, 0, 7, '100.00', 1, 1, '2015-10-28', '2015-10-28'),
(131, 9, 'I-18623', 'Demo Product', 1000, 0, 7, '250.00', 0, 1, '2015-10-28', '2015-10-28'),
(132, 5, 'I-19889', 'JCO. EB 160', 0, 0, 3, '0.00', 1, 1, '2015-12-06', '2015-12-06');

-- --------------------------------------------------------

--
-- Table structure for table `itemsgroup`
--

CREATE TABLE IF NOT EXISTS `itemsgroup` (
`id` int(11) NOT NULL,
  `name` text COLLATE utf32_bin NOT NULL,
  `userid` int(11) NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Dumping data for table `itemsgroup`
--

INSERT INTO `itemsgroup` (`id`, `name`, `userid`, `created_at`, `updated_at`) VALUES
(1, 'Sales', 1, '2015-08-13', '2015-08-30'),
(2, 'Purchase', 1, '2015-08-13', '2015-08-13'),
(3, 'Ohthes Meterials', 1, '2015-08-27', '2015-08-27'),
(4, 'Machinary Product', 1, '2015-08-27', '2015-08-27'),
(7, 'Misc', 1, '2015-09-13', '2015-09-13');

-- --------------------------------------------------------

--
-- Table structure for table `itemssubgroup`
--

CREATE TABLE IF NOT EXISTS `itemssubgroup` (
`id` int(11) NOT NULL,
  `itemgroupid` int(11) NOT NULL,
  `name` text COLLATE utf32_bin NOT NULL,
  `userid` int(11) NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Dumping data for table `itemssubgroup`
--

INSERT INTO `itemssubgroup` (`id`, `itemgroupid`, `name`, `userid`, `created_at`, `updated_at`) VALUES
(1, 1, 'Solar Battery', 0, '2015-08-13', '2015-08-30'),
(2, 1, 'IPS Battery', 1, '2015-08-13', '2015-08-13'),
(3, 1, 'PC Battery', 1, '2015-08-13', '2015-08-13'),
(4, 1, 'CV Battery', 1, '2015-08-13', '2015-08-13'),
(5, 1, 'EV Battery', 1, '2015-08-13', '2015-08-13'),
(6, 1, 'Rickshaw Battery', 1, '2015-08-13', '2015-08-13'),
(7, 1, 'Plate', 1, '2015-08-13', '2015-08-13'),
(8, 1, 'Seperator', 1, '2015-08-13', '2015-08-13'),
(9, 1, 'Bitumin', 1, '2015-08-13', '2015-08-13'),
(10, 1, 'Container', 0, '2015-08-13', '2015-08-30'),
(11, 1, 'Solar Panel', 1, '2015-08-13', '2015-08-13'),
(12, 1, 'IPS', 1, '2015-08-13', '2015-08-13'),
(13, 1, 'Charge Controller', 1, '2015-08-13', '2015-08-13'),
(14, 1, 'Battery Charger', 1, '2015-08-13', '2015-08-13'),
(16, 2, 'Battery Raw Materials', 0, '2015-08-13', '2015-09-08'),
(17, 2, 'Packing Materials', 1, '2015-08-13', '2015-08-13'),
(18, 2, 'I.P.s', 1, '2015-08-13', '2015-08-13'),
(19, 2, 'Solar Panel', 1, '2015-08-13', '2015-08-13'),
(20, 3, 'Computer Equpments', 1, '2015-08-27', '2015-08-27'),
(22, 2, 'jjj', 1, '2015-08-30', '2015-08-30'),
(23, 2, 'test5', 1, '2015-08-30', '2015-08-30');

-- --------------------------------------------------------

--
-- Table structure for table `measurementgroup`
--

CREATE TABLE IF NOT EXISTS `measurementgroup` (
`id` int(11) NOT NULL,
  `name` text COLLATE utf32_bin NOT NULL,
  `userid` int(11) NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Dumping data for table `measurementgroup`
--

INSERT INTO `measurementgroup` (`id`, `name`, `userid`, `created_at`, `updated_at`) VALUES
(1, 'GroupA', 1, '2015-08-02', '2015-08-09'),
(2, 'GroupB', 1, '2015-08-02', '2015-08-09'),
(3, 'GroupC', 1, '2015-08-30', '2015-08-30');

-- --------------------------------------------------------

--
-- Table structure for table `measurementunit`
--

CREATE TABLE IF NOT EXISTS `measurementunit` (
`id` int(11) NOT NULL,
  `mgid` int(11) NOT NULL,
  `name` text COLLATE utf32_bin NOT NULL,
  `userid` int(11) NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Dumping data for table `measurementunit`
--

INSERT INTO `measurementunit` (`id`, `mgid`, `name`, `userid`, `created_at`, `updated_at`) VALUES
(1, 1, 'Kilogram', 1, '2015-08-03', '2015-08-03'),
(2, 1, 'Liter', 1, '2015-08-03', '2015-08-13'),
(3, 1, 'PCS', 1, '2015-08-03', '2015-08-09'),
(4, 2, 'ounce', 1, '2015-08-27', '2015-08-27'),
(6, 3, 'feet', 1, '2015-08-30', '2015-08-30'),
(7, 3, 'Ton', 1, '2015-10-27', '2015-10-27');

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE IF NOT EXISTS `menus` (
`id` int(11) NOT NULL,
  `name` text COLLATE utf32_bin NOT NULL,
  `link` text COLLATE utf32_bin NOT NULL,
  `status` int(10) NOT NULL,
  `userid` int(11) NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`id`, `name`, `link`, `status`, `userid`, `created_at`, `updated_at`) VALUES
(1, 'Setup', 'setup', 1, 1, '2015-07-08', NULL),
(2, 'Inventory', 'inventory', 1, 1, '2015-07-20', NULL),
(3, 'Sales & Commercial', 'sales', 1, 1, '2015-07-22', NULL),
(4, 'Acccounting', 'inventory', 1, 1, '2015-07-22', NULL),
(5, 'POS', 'pos', 1, 1, '2015-07-08', NULL),
(6, 'Factory Inventory', 'factory', 1, 1, '2015-07-14', NULL),
(7, 'HR And Payroll', 'hr', 1, 1, '2015-07-14', NULL),
(8, 'Ledger Accounting', 'ledgeraccounting', 1, 1, '2015-09-18', NULL),
(9, 'Voucher Information', 'voucher', 1, 1, '2015-09-17', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2015_09_01_102309_entrust_setup_tables', 1);

-- --------------------------------------------------------

--
-- Table structure for table `particulars`
--

CREATE TABLE IF NOT EXISTS `particulars` (
`id` int(11) NOT NULL,
  `name` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `particulars`
--

INSERT INTO `particulars` (`id`, `name`) VALUES
(1, 'Monthly Salary'),
(2, 'Bonus'),
(3, 'Overtime'),
(4, 'Festival Bonus'),
(5, 'Others');

-- --------------------------------------------------------

--
-- Table structure for table `pettycash`
--

CREATE TABLE IF NOT EXISTS `pettycash` (
`id` int(11) NOT NULL,
  `particular` int(255) NOT NULL,
  `increasetype` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `description` varchar(255) NOT NULL,
  `edate` date NOT NULL,
  `instatus` int(11) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `updated_at` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pettycash`
--

INSERT INTO `pettycash` (`id`, `particular`, `increasetype`, `amount`, `description`, `edate`, `instatus`, `userid`, `created_at`, `updated_at`) VALUES
(1, 17, 0, '3000.00', 'p', '0000-00-00', 0, 1, '2015-12-01', '2015-12-01'),
(2, 18, 0, '4000.00', '2514', '0000-00-00', 0, 1, '2015-12-01', '2015-12-01'),
(3, 19, 0, '1000.00', '1000', '0000-00-00', 0, 1, '2015-12-01', '2015-12-01'),
(4, 16, 0, '20000.00', 'na', '0000-00-00', 0, 1, '2015-12-05', '2015-12-05'),
(5, 16, 0, '5000.00', '5000', '0000-00-00', 0, 1, '2015-12-05', '2015-12-05'),
(6, 17, 0, '20000.00', 'na', '0000-00-00', 0, 1, '2015-12-05', '2015-12-05'),
(7, 22, 0, '3000.00', '44', '0000-00-00', 0, 1, '2015-12-05', '2015-12-05'),
(8, 23, 0, '1500.00', '4744', '0000-00-00', 0, 1, '2015-12-05', '2015-12-05'),
(9, 22, 0, '10000.00', 'NA', '0000-00-00', 0, 1, '2015-12-06', '2015-12-06');

-- --------------------------------------------------------

--
-- Table structure for table `purchase`
--

CREATE TABLE IF NOT EXISTS `purchase` (
`id` int(11) NOT NULL,
  `name` text COLLATE utf32_bin NOT NULL,
  `purchasedate` date DEFAULT NULL,
  `suppliersid` int(11) NOT NULL,
  `suppliersbillno` text COLLATE utf32_bin NOT NULL,
  `suppliersbilldate` date DEFAULT NULL,
  `challanno` text COLLATE utf32_bin NOT NULL,
  `sub_total` decimal(10,2) NOT NULL,
  `discount` decimal(10,2) NOT NULL,
  `gross_total` decimal(10,2) NOT NULL,
  `others_exp` decimal(10,2) NOT NULL,
  `old_sub_total` decimal(10,2) NOT NULL,
  `old_discount` decimal(10,2) NOT NULL,
  `old_gross_total` decimal(10,2) NOT NULL,
  `old_others_exp` decimal(10,2) NOT NULL,
  `status` int(10) DEFAULT '0',
  `cstatus` int(11) NOT NULL DEFAULT '0',
  `slno` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Dumping data for table `purchase`
--

INSERT INTO `purchase` (`id`, `name`, `purchasedate`, `suppliersid`, `suppliersbillno`, `suppliersbilldate`, `challanno`, `sub_total`, `discount`, `gross_total`, `others_exp`, `old_sub_total`, `old_discount`, `old_gross_total`, `old_others_exp`, `status`, `cstatus`, `slno`, `userid`, `created_at`, `updated_at`) VALUES
(1, 'P-0000001', '2015-11-25', 2, '111', '2015-11-17', '444', '300000.00', '0.00', '300000.00', '0.00', '300000.00', '0.00', '300000.00', '0.00', 1, 0, 1, 1, '2015-11-25', '2015-11-25'),
(2, 'P-0000002', '2015-11-25', 2, '154144', '2015-11-17', '15401414', '560000.00', '0.00', '560000.00', '0.00', '900000.00', '0.00', '900000.00', '0.00', 1, 0, 2, 1, '2015-11-25', '2015-11-25'),
(3, 'P-0000003', '2015-11-25', 2, '4111', '2015-11-25', '111', '150000.00', '0.00', '150000.00', '0.00', '150000.00', '0.00', '150000.00', '0.00', 1, 0, 3, 1, '2015-11-25', '2015-11-25'),
(4, 'P-0000004', '2015-11-26', 4, '15474', '2015-11-26', '451', '625000.00', '5000.00', '625000.00', '5000.00', '625000.00', '5000.00', '625000.00', '5000.00', 1, 0, 4, 1, '2015-11-26', '2015-11-26'),
(5, 'P-0000005', '2015-11-26', 6, '15444', '2015-11-26', '1544', '475000.00', '0.00', '475000.00', '0.00', '475000.00', '0.00', '475000.00', '0.00', 1, 0, 5, 1, '2015-11-26', '2015-11-26'),
(6, 'P-0000006', '2015-12-05', 2, '1544', '2015-12-05', '111', '157650.00', '0.00', '157650.00', '0.00', '157650.00', '0.00', '157650.00', '0.00', 1, 0, 6, 1, '2015-12-05', '2015-12-05'),
(7, 'P-0000007', '2015-12-06', 40, '1', '2015-12-06', '1', '668952.90', '0.90', '669960.00', '1008.00', '735000.00', '0.00', '735000.00', '0.00', 1, 0, 7, 1, '2015-12-06', '2015-12-06');

-- --------------------------------------------------------

--
-- Table structure for table `purchasedetails`
--

CREATE TABLE IF NOT EXISTS `purchasedetails` (
`id` int(11) NOT NULL,
  `purchaseid` int(11) NOT NULL,
  `itemid` int(11) NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `old_quantity` decimal(10,2) NOT NULL,
  `mesid` int(11) NOT NULL,
  `rate` decimal(10,2) NOT NULL,
  `old_rate` decimal(10,2) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `old_amount` decimal(10,2) NOT NULL,
  `userid` int(11) NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Dumping data for table `purchasedetails`
--

INSERT INTO `purchasedetails` (`id`, `purchaseid`, `itemid`, `quantity`, `old_quantity`, `mesid`, `rate`, `old_rate`, `amount`, `old_amount`, `userid`, `created_at`, `updated_at`) VALUES
(1, 1, 90, '1500.00', '1500.00', 1, '200.00', '200.00', '300000.00', '300000.00', 1, '2015-11-25', '2015-11-25'),
(2, 2, 90, '4000.00', '6000.00', 1, '140.00', '150.00', '560000.00', '900000.00', 1, '2015-11-25', '2015-11-25'),
(3, 3, 90, '1000.00', '1000.00', 1, '150.00', '150.00', '150000.00', '150000.00', 1, '2015-11-25', '2015-11-25'),
(4, 4, 90, '5000.00', '5000.00', 1, '125.00', '125.00', '625000.00', '625000.00', 1, '2015-11-26', '2015-11-26'),
(5, 5, 90, '2000.00', '2000.00', 1, '125.00', '125.00', '250000.00', '250000.00', 1, '2015-11-26', '2015-11-26'),
(6, 5, 91, '1500.00', '1500.00', 3, '150.00', '150.00', '225000.00', '225000.00', 1, '2015-11-26', '2015-11-26'),
(7, 6, 90, '1051.00', '1051.00', 1, '150.00', '150.00', '157650.00', '157650.00', 1, '2015-12-05', '2015-12-05'),
(8, 7, 90, '4550.70', '5000.00', 1, '147.00', '147.00', '668952.90', '735000.00', 1, '2015-12-06', '2015-12-06');

-- --------------------------------------------------------

--
-- Table structure for table `purchaseinventory`
--

CREATE TABLE IF NOT EXISTS `purchaseinventory` (
`id` int(11) NOT NULL,
  `itemsid` int(11) NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `userid` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `updated_at` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchaseinventory`
--

INSERT INTO `purchaseinventory` (`id`, `itemsid`, `quantity`, `userid`, `created_at`, `updated_at`) VALUES
(1, 90, '500.00', 1, '2015-11-25', '2015-11-25'),
(2, 90, '5000.00', 1, '2015-11-25', '2015-11-25'),
(3, 90, '300.00', 1, '2015-11-25', '2015-11-25'),
(4, 91, '500.00', 1, '2015-11-26', '2015-11-26'),
(5, 91, '200.00', 1, '2015-11-26', '2015-11-26'),
(6, 90, '1500.00', 1, '2015-11-26', '2015-11-26'),
(7, 90, '600.00', 1, '2015-11-26', '2015-11-26');

-- --------------------------------------------------------

--
-- Table structure for table `replacechallan`
--

CREATE TABLE IF NOT EXISTS `replacechallan` (
`id` int(11) NOT NULL,
  `name` text NOT NULL,
  `cid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `updated_at` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `replacechallan`
--

INSERT INTO `replacechallan` (`id`, `name`, `cid`, `userid`, `created_at`, `updated_at`) VALUES
(1, '25440', 2, 1, '2015-12-05', '0000-00-00'),
(2, '15626', 1, 1, '2015-12-06', '0000-00-00'),
(3, '29372', 1, 1, '2015-12-07', '0000-00-00'),
(4, '16592', 50, 1, '2015-12-06', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `replace_factory`
--

CREATE TABLE IF NOT EXISTS `replace_factory` (
  `repalcechallanid` int(11) NOT NULL,
  `factoryitemsid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `replace_factory`
--

INSERT INTO `replace_factory` (`repalcechallanid`, `factoryitemsid`) VALUES
(0, 16),
(0, 16),
(2, 36),
(2, 38),
(3, 36),
(4, 2),
(4, 41);

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE IF NOT EXISTS `sales` (
`id` int(11) NOT NULL,
  `name` text COLLATE utf32_bin NOT NULL,
  `salesdate` date DEFAULT NULL,
  `customerid` int(11) NOT NULL,
  `discount` decimal(10,2) NOT NULL,
  `gamount` decimal(10,2) NOT NULL,
  `previousdue` decimal(10,2) NOT NULL DEFAULT '0.00',
  `presentbalance` decimal(10,2) NOT NULL DEFAULT '0.00',
  `status` int(11) NOT NULL DEFAULT '0',
  `slno` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `name`, `salesdate`, `customerid`, `discount`, `gamount`, `previousdue`, `presentbalance`, `status`, `slno`, `userid`, `created_at`, `updated_at`) VALUES
(1, 'I-0000001', '2015-12-06', 1, '400.00', '22000.00', '505500.00', '527500.00', 1, 1, 1, '2015-12-06', '2015-12-06'),
(2, 'I-0000002', '2015-12-06', 50, '0.00', '94000.00', '-70000.00', '24000.00', 1, 2, 1, '2015-12-06', '2015-12-06');

-- --------------------------------------------------------

--
-- Table structure for table `salesdetails`
--

CREATE TABLE IF NOT EXISTS `salesdetails` (
`id` int(11) NOT NULL,
  `salesid` int(11) NOT NULL,
  `itemid` int(11) NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `mesid` int(11) NOT NULL,
  `rate` decimal(10,2) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `userid` int(11) NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Dumping data for table `salesdetails`
--

INSERT INTO `salesdetails` (`id`, `salesid`, `itemid`, `quantity`, `mesid`, `rate`, `amount`, `userid`, `created_at`, `updated_at`) VALUES
(1, 1, 132, '2.00', 3, '10000.00', '20000.00', 1, '2015-12-06', '2015-12-06'),
(2, 1, 1, '1.00', 3, '2400.00', '2400.00', 1, '2015-12-06', '2015-12-06'),
(3, 2, 1, '4.00', 3, '2500.00', '10000.00', 1, '2015-12-06', '2015-12-06'),
(4, 2, 132, '7.00', 3, '12000.00', '84000.00', 1, '2015-12-06', '2015-12-06');

-- --------------------------------------------------------

--
-- Table structure for table `submenus`
--

CREATE TABLE IF NOT EXISTS `submenus` (
`id` int(11) NOT NULL,
  `name` text COLLATE utf32_bin NOT NULL,
  `link` text COLLATE utf32_bin NOT NULL,
  `status` int(10) NOT NULL,
  `menuid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Dumping data for table `submenus`
--

INSERT INTO `submenus` (`id`, `name`, `link`, `status`, `menuid`, `userid`, `created_at`, `updated_at`) VALUES
(1, 'Users Group', 'usersgroup', 1, 1, 1, '2015-07-02', NULL),
(2, 'Users', 'users', 1, 1, 1, '2015-07-15', NULL),
(3, 'Users Permission', 'userspermission', 1, 1, 1, '2015-07-15', NULL),
(4, 'Item Group', 'itemgroup', 1, 2, 1, '2015-07-01', NULL),
(5, 'Item Category', 'itemsubgroup', 1, 2, 1, '2015-07-15', NULL),
(6, 'Item Model', 'itemmaster', 1, 2, 1, '2015-07-08', NULL),
(7, 'Measurement Group', 'measurementgroup', 1, 2, 1, '2015-07-16', NULL),
(8, 'Measurement Unit', 'measurementunit', 1, 2, 1, '2015-07-15', NULL),
(9, 'Vendor/Supplier', 'suppliers', 1, 1, 1, '2015-07-09', NULL),
(10, 'Customer/Client', 'customers', 1, 1, 1, '2015-07-15', NULL),
(11, 'Purchase Order', 'purchase', 1, 3, 1, '2015-07-15', NULL),
(12, 'Bills Pay', 'billspay', 1, 0, 1, '2015-07-22', NULL),
(13, 'Physical Sales', 'physicalsales', 1, 3, 1, '2015-07-16', NULL),
(14, 'Bills Receives', 'billsreceives', 1, 0, 1, '2015-07-22', NULL),
(15, 'Reports on Ledger', 'generalledger', 1, 8, 1, '2015-07-15', NULL),
(16, 'Report On Purchases', 'reportpurchases', 1, 3, 1, '2015-07-14', NULL),
(17, 'Reports on Sales', 'reportssale', 1, 3, 1, '2015-07-15', NULL),
(18, 'Stock In Analyst', 'stockin', 1, 0, 1, '2015-07-15', NULL),
(19, 'Stock Out Analyst', 'stockout', 1, 0, 1, '2015-07-15', NULL),
(20, 'Accounts Payable', 'accountspayable', 1, 0, 1, '2015-07-15', NULL),
(21, 'Accounts Receivels', 'accountreceives', 1, 0, 1, '2015-07-15', NULL),
(22, 'Loss & profit Analys', 'reportlossprofit', 1, 5, 1, '2015-07-15', NULL),
(23, 'Stock In Out Analys', 'stokrinout', 1, 0, 1, '2015-07-14', NULL),
(24, 'Bank Book', 'bankbook', 1, 4, 1, '2015-07-15', NULL),
(25, 'Trial Balance', 'trialbalance', 1, 4, 1, '2015-07-15', NULL),
(26, 'Factory Item Master', 'factoryitem', 1, 6, 1, '2015-07-02', NULL),
(27, 'Stock In Out Analyst', 'fstokin', 1, 6, 1, '2015-07-15', NULL),
(28, 'Stock out analyst', 'stockout', 1, 0, 1, '2015-07-14', NULL),
(29, 'Employee Info', 'employee', 1, 7, 1, '2015-07-15', NULL),
(30, 'Employee Salary', 'employeesal', 1, 7, 1, '2015-07-20', NULL),
(31, 'Performance appraisal', 'performance', 1, 0, 1, '2015-07-22', NULL),
(32, 'Benefits administration', 'benefit', 1, 0, 1, '2015-07-22', NULL),
(33, 'Absence management', 'absense', 1, 0, 1, '2015-07-08', NULL),
(34, 'Reports Analyst', 'reports', 1, 7, 1, '2015-07-14', NULL),
(35, 'Bank Information', 'bankinfo', 0, 1, 1, '2015-08-11', NULL),
(36, 'Bank Account', 'bankaccount', 0, 1, 1, '2015-08-11', NULL),
(37, 'PL Account', 'placcount', 1, 4, 1, '2015-09-14', NULL),
(38, 'Balance Sheet', 'balancesheet', 0, 4, 1, '2015-09-14', NULL),
(39, 'Contra Voucher Entry', 'contravoucher', 1, 9, 1, '2015-09-30', NULL),
(40, 'Journal Entry', 'ledgerentry', 1, 8, 1, '2015-09-03', NULL),
(41, 'Create Ledger ', 'coa', 0, 8, 1, '2015-08-11', NULL),
(42, 'Voucher Entry', 'voucher', 1, 9, 1, '2015-08-04', NULL),
(43, 'Cash Book', 'cashbook', 1, 4, 1, '2015-10-20', NULL),
(44, 'Reports on Replace Return', 'replacereturn', 1, 3, 1, '2015-11-10', NULL),
(45, 'Purchase Inventory', 'purchaseinventory', 1, 6, 1, '2015-11-24', NULL),
(46, 'Reports on Purchase Inventory', 'purchaseinventoryreport', 1, 6, 1, '2015-11-25', NULL),
(47, 'ISO Report', 'isoreport', 1, 1, 1, '2015-11-26', NULL),
(48, 'Database Backup', 'database_backup', 1, 0, 1, '2015-11-29', NULL),
(49, 'Reprots On Collection', 'collectionreport', 1, 3, 1, '2015-12-01', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE IF NOT EXISTS `suppliers` (
`id` int(11) NOT NULL,
  `code` text COLLATE utf32_bin NOT NULL,
  `name` text COLLATE utf32_bin NOT NULL,
  `openbalance` decimal(10,2) NOT NULL,
  `preaddress` text COLLATE utf32_bin NOT NULL,
  `peraddress` text COLLATE utf32_bin NOT NULL,
  `phone` text COLLATE utf32_bin NOT NULL,
  `email` text COLLATE utf32_bin NOT NULL,
  `fax` text COLLATE utf32_bin NOT NULL,
  `url` text COLLATE utf32_bin NOT NULL,
  `coastatus` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `updated_at` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`id`, `code`, `name`, `openbalance`, `preaddress`, `peraddress`, `phone`, `email`, `fax`, `url`, `coastatus`, `userid`, `created_at`, `updated_at`) VALUES
(2, 's-102', 'Asha Trading', '100000.00', 'Gulshan', 'Cox''s Bazar', '654321', 'iqbal@gmail.com', 'kkkk', 'http://iqbal', 1, 1, '2015-08-01', '2015-09-21'),
(4, 's-0244744', 'S A Corporation', '0.00', 'address', 'sdsdsd', '0760-284-3360', 'sa_sarker11@yahoo.com', 'ss', '', 1, 1, '2015-08-13', '2015-10-21'),
(6, 'S-22618', 'Jharna Chemical Supply', '0.00', 'er', 'etr', '34', 'a@yahoo.com', 'tyu', 'http://co', 0, 1, '2015-08-16', '2015-08-27'),
(7, 'S-10176', 'ABC Enterprise', '0.00', 'Dhaka', 'Dhaka', '3245631313', '', '', '', 0, 1, '2015-08-19', '2015-08-27'),
(8, 'S-18808', 'Babul & Sons', '0.00', 'Dhaka', 'Gajipur', '0760-284-3360', 'sascafs@outlook.com', 'aaa', '', 0, 1, '2015-08-20', '2015-08-27'),
(9, 'S-12029', 'Nasir Block', '150000.00', 'Dhaka', 'Dhaka', '154444444', 'sascafs@outlook.com', '', '', 0, 1, '2015-08-27', '2015-08-30'),
(11, 'S-22856', 'Barisal Battery', '100000.00', 'Barisal', 'comilla', '1111-111-1111', 'sascafs@outlook.com', '', 'http://www.sascafs.com', 1, 1, '2015-08-30', '2015-09-21'),
(12, 'S-1286', 'LIC bangladseh', '150000.00', 'Basabo', 'Basabo', '1111-111-1111', '', '', '', 0, 1, '2015-08-30', '2015-08-31'),
(13, 'S-1788', 'kkk', '777.00', 'kkkk', 'jjjj', '888', 'kkkk@gmail.com', '', '', 0, 1, '2015-08-30', '2015-08-30'),
(14, 'S-20897', 'Bangla Solar', '500000.00', 'Gulistan', 'Gulistan', '0760-284-3360', 'sascafs@outlook.com', 'hghghg', 'http://www.sascafs.com', 0, 1, '2015-08-30', '2015-09-12'),
(16, 'S-29342', 'Tumon', '0.00', '', '', '', '', '', '', 0, 0, '2015-09-07', '2015-09-07'),
(18, 'S-3207', 'FS', '0.00', '', '', '', '', '', '', 0, 0, '2015-09-07', '2015-09-13'),
(20, 'S-5117', 'Roman', '0.00', '', '', '', '', '', '', 0, 0, '2015-09-07', '2015-09-07'),
(21, 'S-574', 'WOW', '0.00', '', '', '', '', '', '', 0, 0, '2015-09-07', '2015-09-07'),
(22, 'S-7984', 'subrata', '0.00', '', '', '', '', '', '', 0, 0, '2015-09-07', '2015-09-07'),
(23, 'S-32539', 'ioo', '0.00', '', '', '', '', '', '', 0, 0, '2015-09-07', '2015-09-07'),
(24, 'S-26445', '', '0.00', '', '', '', '', '', '', 0, 0, '2015-09-08', '2015-09-08'),
(25, 'S-18195', 'ttttttt', '0.00', '', '', '', '', '', '', 0, 0, '2015-09-08', '2015-09-08'),
(26, 'S-16454', 'FS CO', '58500.00', 'Dhaka, BD', 'Dhaka,BD', '0178454545', 'sascafs@outlook.com', '', '', 0, 1, '2015-09-08', '2015-09-08'),
(27, 'S-25945', 'Binimoy Battery', '125000.00', 'Dhaka', 'Dhaka', '0760-284-3360', '', '', '', 0, 1, '2015-09-08', '2015-09-08'),
(28, 'S-30272', 'yyy', '0.00', '', '', '', '', '', '', 0, 0, '2015-09-09', '2015-09-09'),
(29, 'S-19305', '', '0.00', '', '', '', '', '', '', 0, 0, '2015-09-09', '2015-09-09'),
(30, 'S-1359', 'kk', '0.00', '', '', '', '', '', '', 0, 0, '2015-09-09', '2015-09-09'),
(31, 'S-30321', 'test7', '0.00', '', '', '', '', '', '', 0, 0, '2015-09-09', '2015-09-09'),
(32, 'S-16411', 'Emon', '0.00', '', '', '', '', '', '', 0, 0, '2015-09-09', '2015-09-09'),
(33, 'S-19586', 'ASDF', '25000.00', 'Banani', 'Banani', '01711-285246', 'asdf@gmail.com', '', '', 0, 1, '2015-09-12', '2015-09-12'),
(34, 'S-7096', 'SAA', '12500.00', 'Dhaka', 'Badda Link road', '01971000200', '', '', '', 0, 1, '2015-09-13', '2015-09-13'),
(35, 'S-3809', 'ty', '243432.00', 'dr', '', '34324234', '', '', '', 0, 1, '2015-09-13', '2015-09-13'),
(36, 'S-17726', 'asd', '0.00', 'Dhanmondi', '', '', '', '', '', 1, 0, '2015-11-01', '2015-11-08'),
(37, 'S-16428', 'SAS201Subrata', '1000.00', 'Dhaka', '1111', '567', '', '', '', 0, 1, '2015-11-09', '2015-11-23'),
(38, 'S-15337', 'Mr.Subrata', '0.00', 'Dhaka', '', '', '', '', '', 0, 0, '2015-11-11', '2015-11-11'),
(39, 'S-20131', 'Mohsin', '0.00', 'Cox''s Bazar', '', '0123456789', '', '', '', 0, 0, '2015-11-23', '2015-11-23'),
(40, 'S-9076', 'Lalu Mia & Sons', '0.00', 'Kamrangirchar', '', '01913457777', '', '', '', 0, 0, '2015-12-06', '2015-12-06');

-- --------------------------------------------------------

--
-- Table structure for table `suppliersledger`
--

CREATE TABLE IF NOT EXISTS `suppliersledger` (
`id` int(11) NOT NULL,
  `pav` int(11) NOT NULL,
  `puv` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `suppliersledger`
--

INSERT INTO `suppliersledger` (`id`, `pav`, `puv`, `sid`, `amount`, `created_at`, `updated_at`) VALUES
(1, 0, 1, 38, '300105.00', '2015-11-11', '2015-11-11'),
(2, 6, 0, 38, '200000.00', '2015-11-11', '2015-11-11'),
(3, 0, 2, 38, '560000.00', '2015-11-11', '2015-11-11'),
(4, 7, 0, 38, '30000.00', '2015-11-11', '2015-11-11'),
(5, 0, 3, 4, '17155384.00', '2015-11-11', '2015-11-11'),
(6, 0, 4, 8, '126984.00', '2015-11-11', '2015-11-11'),
(7, 0, 5, 2, '1221.00', '2015-11-11', '2015-11-11'),
(8, 8, 0, 6, '30000.00', '2015-11-11', '2015-11-11'),
(9, 9, 0, 7, '111.00', '2015-11-11', '2015-11-11'),
(10, 0, 6, 2, '1000.00', '2015-11-19', '2015-11-19'),
(11, 7, 0, 6, '6000.00', '2015-11-24', '2015-11-24'),
(12, 8, 0, 7, '3500.00', '2015-11-24', '2015-11-24'),
(13, 10, 0, 7, '7777.00', '2015-11-24', '2015-11-24'),
(14, 12, 0, 13, '45454.00', '2015-11-25', '2015-11-25'),
(15, 0, 1, 2, '300000.00', '2015-11-25', '2015-11-25'),
(16, 0, 2, 2, '560000.00', '2015-11-25', '2015-11-25'),
(17, 0, 3, 2, '150000.00', '2015-11-25', '2015-11-25'),
(18, 0, 4, 4, '625000.00', '2015-11-26', '2015-11-26'),
(19, 0, 5, 6, '475000.00', '2015-11-26', '2015-11-26'),
(20, 1, 0, 7, '349000.00', '2015-12-01', '2015-12-01'),
(21, 9, 0, 6, '6000.00', '2015-12-01', '2015-12-01'),
(22, 0, 6, 2, '157650.00', '2015-12-05', '2015-12-05'),
(23, 18, 0, 7, '100000.00', '2015-12-05', '2015-12-05'),
(24, 0, 7, 40, '669960.00', '2015-12-06', '2015-12-06'),
(25, 26, 0, 40, '100000.00', '2015-12-06', '2015-12-06'),
(26, 27, 0, 40, '200000.00', '2015-12-06', '2015-12-06');

-- --------------------------------------------------------

--
-- Table structure for table `taxrate`
--

CREATE TABLE IF NOT EXISTS `taxrate` (
`id` int(11) NOT NULL,
  `name` text NOT NULL,
  `percentage` float NOT NULL,
  `userid` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `taxrate`
--

INSERT INTO `taxrate` (`id`, `name`, `percentage`, `userid`, `created_at`, `updated_at`) VALUES
(1, 'Tax Rate1', 10, 1, '2015-08-12 08:08:45', '0000-00-00 00:00:00'),
(2, 'Tax Rate2', 20, 1, '2015-08-12 08:09:20', '0000-00-00 00:00:00'),
(3, 'Tax Rate3', 30, 1, '2015-08-12 08:09:39', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `usergroups`
--

CREATE TABLE IF NOT EXISTS `usergroups` (
`id` int(11) NOT NULL,
  `name` text COLLATE utf32_bin NOT NULL,
  `userid` int(11) NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Dumping data for table `usergroups`
--

INSERT INTO `usergroups` (`id`, `name`, `userid`, `created_at`, `updated_at`) VALUES
(1, 'Super Admin', 1, '2015-09-22', '2015-09-22'),
(2, 'Admin', 2, '2015-09-22', '2015-09-22'),
(3, 'Basic Users', 1, '2015-09-22', '2015-09-22'),
(4, 'Branch Users', 1, '2015-09-22', '2015-09-22'),
(5, 'Warehouse   Users', 1, '2015-09-22', '2015-09-22'),
(6, 'aaa', 1, '2015-10-17', '2015-10-17'),
(7, 'aaa', 1, '2015-10-17', '2015-10-17'),
(8, 'aaa', 1, '2015-10-17', '2015-10-17'),
(9, 'bb', 1, '2015-10-17', '2015-10-17'),
(10, 'bb', 1, '2015-10-17', '2015-10-17'),
(11, 'bb', 1, '2015-10-17', '2015-10-17'),
(12, 'bb', 1, '2015-10-17', '2015-10-17'),
(13, 'bb', 1, '2015-10-17', '2015-10-17'),
(14, 'bb', 1, '2015-10-17', '2015-10-17');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`id` int(11) NOT NULL,
  `name` text COLLATE utf32_bin NOT NULL,
  `email` text COLLATE utf32_bin NOT NULL,
  `password` text COLLATE utf32_bin NOT NULL,
  `remember_token` text COLLATE utf32_bin NOT NULL,
  `usergroupid` int(11) NOT NULL DEFAULT '0',
  `file` text COLLATE utf32_bin NOT NULL,
  `created_at` date NOT NULL,
  `updated_at` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `usergroupid`, `file`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'info@jcobattery.com', '$2y$10$JtnR9r/0/C9BNjL6zYHUaOG3Y.iW5R7FrPzYsXabfVS7/0HKBmBci', 'IUUvgiJArUIWwJInSEa65eMqBWuWyOC81jrxjvnhX0HK6tfTRUtzNhwwwUVs', 1, '50070.jpg', '2015-09-02', '2015-12-06'),
(2, 'Bscic', 'bscic@jcobattery.com', '$2y$10$D7cscRHZ9kwaR0C8z1957OENeOgvf7mcsfFsQsDPMRnxnXorzWZI2', 'tK4C3TRXUiXzlPiSKWJOiKjNEGR58oHCD8ltljpRhbvt0vsqPmSGOAZevIg0', 5, '', '2015-12-31', '2015-11-08'),
(3, 'Tatibazaar', 'tatibazaar@jcobattery.com', '$2y$10$uPNMCRzstUX89Sx60iTJq.Qn8hNjr53fXOy4dFRULuGf68pQnK1Ju', 'q4sEwN3338IQzwLHIPmhZMwBzlQbLA7ZO25KjmqEcjug3Etx6NNd62Ln1M36', 5, '', '2015-12-31', '2015-11-25'),
(4, 'Mohsin', 'mohsin@gmail.com', '$2y$10$GIUcNzf0sCy3Ea/E.BKOGu0MOg9nmNycQaccM0mxCUSK8h0/0NPyi', 'YXkTzjWs98awBgY7DSTYAnhylIL4VQL5ZLfnzOT3XB5LtXYae5ymtDpNg7oQ', 2, '50070.jpg', '2015-11-24', '2015-11-24'),
(5, 'subrata', 'sa_sarker@yahoo.com', '$2y$10$qdy3MRVvkjRdRNcHCeYdReEF4OwZWw9xlNKIHkt8bqqNDxGvEeQDG', 'OK5c30v94d70AnD30ey0nVoVcemWjgrxhwca35y5Rd61NcC4QIvWYZTNgfwF', 2, '89995.jpg', '2015-11-24', '2015-11-25'),
(6, 'Battery', '', '$2y$10$TN4lb2IavmG7Pv3wK74gVO4llGETqJUtKXCS3Oabl7Uewg7gIdrGy', '', 3, '25637.jpg', '2015-11-25', '2015-11-25'),
(7, 'Battery', 'battery@gmail.com', '$2y$10$pNan.1BFX3T9x.qf7nbvnuGr/8tSZQvaLw5X4mYbEccfjOnOC3xfe', '', 0, '76757.jpg', '2015-11-25', '2015-11-25'),
(8, 'jhuty', 'a@gmail.com', '$2y$10$ikcMsqhx7tEFLZ61o0alsOSKA1BNWwmWINS3.m1gGtBPBSbAe1jy6', '', 4, '52834.jpg', '2015-11-25', '2015-11-25');

-- --------------------------------------------------------

--
-- Table structure for table `userspermission`
--

CREATE TABLE IF NOT EXISTS `userspermission` (
`id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `submenuid` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `updated_at` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=1322 DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Dumping data for table `userspermission`
--

INSERT INTO `userspermission` (`id`, `userid`, `submenuid`, `status`, `created_at`, `updated_at`) VALUES
(615, 14, 1, 1, '2015-09-02', '2015-09-02'),
(616, 14, 2, 1, '2015-09-02', '2015-09-02'),
(617, 14, 3, 1, '2015-09-02', '2015-09-02'),
(618, 14, 4, 1, '2015-09-02', '2015-09-02'),
(619, 14, 5, 1, '2015-09-02', '2015-09-02'),
(620, 14, 6, 1, '2015-09-02', '2015-09-02'),
(621, 14, 7, 1, '2015-09-02', '2015-09-02'),
(622, 14, 8, 1, '2015-09-02', '2015-09-02'),
(623, 14, 9, 1, '2015-09-02', '2015-09-02'),
(624, 14, 10, 1, '2015-09-02', '2015-09-02'),
(625, 14, 11, 1, '2015-09-02', '2015-09-02'),
(626, 14, 13, 1, '2015-09-02', '2015-09-02'),
(627, 14, 15, 1, '2015-09-02', '2015-09-02'),
(628, 14, 16, 1, '2015-09-02', '2015-09-02'),
(629, 14, 17, 1, '2015-09-02', '2015-09-02'),
(630, 14, 22, 1, '2015-09-02', '2015-09-02'),
(631, 14, 23, 1, '2015-09-02', '2015-09-02'),
(632, 14, 24, 1, '2015-09-02', '2015-09-02'),
(633, 14, 25, 1, '2015-09-02', '2015-09-02'),
(634, 14, 26, 1, '2015-09-02', '2015-09-02'),
(635, 14, 27, 1, '2015-09-02', '2015-09-02'),
(636, 14, 29, 1, '2015-09-02', '2015-09-02'),
(637, 14, 30, 1, '2015-09-02', '2015-09-02'),
(638, 14, 31, 1, '2015-09-02', '2015-09-02'),
(639, 14, 32, 1, '2015-09-02', '2015-09-02'),
(640, 14, 33, 1, '2015-09-02', '2015-09-02'),
(641, 14, 34, 1, '2015-09-02', '2015-09-02'),
(642, 14, 35, 1, '2015-09-02', '2015-09-02'),
(643, 14, 36, 1, '2015-09-02', '2015-09-02'),
(644, 14, 37, 1, '2015-09-02', '2015-09-02'),
(645, 14, 38, 1, '2015-09-02', '2015-09-02'),
(646, 14, 39, 1, '2015-09-02', '2015-09-02'),
(872, 16, 1, 0, '2015-09-02', '2015-09-02'),
(873, 16, 2, 0, '2015-09-02', '2015-09-02'),
(874, 16, 3, 1, '2015-09-02', '2015-09-02'),
(875, 16, 4, 1, '2015-09-02', '2015-09-02'),
(876, 16, 5, 1, '2015-09-02', '2015-09-02'),
(877, 16, 6, 1, '2015-09-02', '2015-09-02'),
(878, 16, 7, 1, '2015-09-02', '2015-09-02'),
(879, 16, 8, 1, '2015-09-02', '2015-09-02'),
(880, 16, 9, 1, '2015-09-02', '2015-09-02'),
(881, 16, 10, 1, '2015-09-02', '2015-09-02'),
(882, 16, 11, 1, '2015-09-02', '2015-09-02'),
(883, 16, 13, 1, '2015-09-02', '2015-09-02'),
(884, 16, 15, 1, '2015-09-02', '2015-09-02'),
(885, 16, 16, 1, '2015-09-02', '2015-09-02'),
(886, 16, 17, 1, '2015-09-02', '2015-09-02'),
(887, 16, 22, 1, '2015-09-02', '2015-09-02'),
(888, 16, 23, 1, '2015-09-02', '2015-09-02'),
(889, 16, 24, 1, '2015-09-02', '2015-09-02'),
(890, 16, 25, 1, '2015-09-02', '2015-09-02'),
(891, 16, 26, 1, '2015-09-02', '2015-09-02'),
(892, 16, 27, 1, '2015-09-02', '2015-09-02'),
(893, 16, 29, 1, '2015-09-02', '2015-09-02'),
(894, 16, 30, 1, '2015-09-02', '2015-09-02'),
(895, 16, 31, 1, '2015-09-02', '2015-09-02'),
(896, 16, 32, 1, '2015-09-02', '2015-09-02'),
(897, 16, 33, 1, '2015-09-02', '2015-09-02'),
(898, 16, 34, 1, '2015-09-02', '2015-09-02'),
(899, 16, 35, 1, '2015-09-02', '2015-09-02'),
(900, 16, 36, 1, '2015-09-02', '2015-09-02'),
(901, 16, 37, 1, '2015-09-02', '2015-09-02'),
(902, 16, 38, 1, '2015-09-02', '2015-09-02'),
(903, 16, 39, 1, '2015-09-02', '2015-09-02'),
(905, 2, 1, 1, '2015-09-02', '2015-12-31'),
(906, 2, 2, 1, '2015-09-02', '2015-12-31'),
(907, 2, 3, 1, '2015-09-02', '2015-12-31'),
(908, 2, 4, 1, '2015-09-02', '2015-12-31'),
(909, 2, 5, 1, '2015-09-02', '2015-12-31'),
(910, 2, 6, 1, '2015-09-02', '2015-12-31'),
(911, 2, 7, 1, '2015-09-02', '2015-12-31'),
(912, 2, 8, 1, '2015-09-02', '2015-12-31'),
(913, 2, 9, 1, '2015-09-02', '2015-12-31'),
(914, 2, 10, 1, '2015-09-02', '2015-12-31'),
(915, 2, 11, 1, '2015-09-02', '2015-12-31'),
(916, 2, 13, 1, '2015-09-02', '2015-12-31'),
(917, 2, 15, 1, '2015-09-02', '2015-12-31'),
(918, 2, 16, 1, '2015-09-02', '2015-12-31'),
(919, 2, 17, 1, '2015-09-02', '2015-12-31'),
(920, 2, 22, 1, '2015-09-02', '2015-12-31'),
(921, 2, 23, 1, '2015-09-02', '2015-12-31'),
(922, 2, 24, 1, '2015-09-02', '2015-12-31'),
(923, 2, 25, 1, '2015-09-02', '2015-12-31'),
(924, 2, 26, 1, '2015-09-02', '2015-12-31'),
(925, 2, 27, 1, '2015-09-02', '2015-12-31'),
(926, 2, 29, 1, '2015-09-02', '2015-12-31'),
(927, 2, 30, 1, '2015-09-02', '2015-12-31'),
(928, 2, 31, 1, '2015-09-02', '2015-09-02'),
(929, 2, 32, 1, '2015-09-02', '2015-12-31'),
(930, 2, 33, 1, '2015-09-02', '2015-09-02'),
(931, 2, 34, 1, '2015-09-02', '2015-12-31'),
(932, 2, 35, 1, '2015-09-02', '2015-12-31'),
(933, 2, 36, 1, '2015-09-02', '2015-12-31'),
(934, 2, 37, 1, '2015-09-02', '2015-12-31'),
(935, 2, 38, 1, '2015-09-02', '2015-12-31'),
(936, 2, 39, 1, '2015-09-02', '2015-12-31'),
(937, 1, 1, 1, '2015-09-03', '2015-12-01'),
(938, 1, 2, 1, '2015-09-03', '2015-12-01'),
(939, 1, 3, 1, '2015-09-03', '2015-12-01'),
(940, 1, 4, 1, '2015-09-03', '2015-12-01'),
(941, 1, 5, 1, '2015-09-03', '2015-12-01'),
(942, 1, 6, 1, '2015-09-03', '2015-12-01'),
(943, 1, 7, 1, '2015-09-03', '2015-12-01'),
(944, 1, 8, 1, '2015-09-03', '2015-12-01'),
(945, 1, 9, 1, '2015-09-03', '2015-12-01'),
(946, 1, 10, 1, '2015-09-03', '2015-12-01'),
(947, 1, 11, 1, '2015-09-03', '2015-12-01'),
(948, 1, 13, 1, '2015-09-03', '2015-12-01'),
(949, 1, 15, 1, '2015-09-03', '2015-12-01'),
(950, 1, 16, 1, '2015-09-03', '2015-12-01'),
(951, 1, 17, 1, '2015-09-03', '2015-12-01'),
(952, 1, 22, 1, '2015-09-03', '2015-12-01'),
(953, 1, 23, 1, '2015-09-03', '2015-12-01'),
(954, 1, 24, 1, '2015-09-03', '2015-12-01'),
(955, 1, 25, 1, '2015-09-03', '2015-12-01'),
(956, 1, 26, 1, '2015-09-03', '2015-12-01'),
(957, 1, 27, 1, '2015-09-03', '2015-12-01'),
(958, 1, 29, 1, '2015-09-03', '2015-12-01'),
(959, 1, 30, 1, '2015-09-03', '2015-12-01'),
(960, 1, 31, 1, '2015-09-03', '2015-09-03'),
(961, 1, 32, 1, '2015-09-03', '2015-12-01'),
(962, 1, 33, 1, '2015-09-03', '2015-09-03'),
(963, 1, 34, 1, '2015-09-03', '2015-12-01'),
(964, 1, 35, 1, '2015-09-03', '2015-12-01'),
(965, 1, 36, 1, '2015-09-03', '2015-12-01'),
(966, 1, 37, 1, '2015-09-03', '2015-12-01'),
(967, 1, 38, 1, '2015-09-03', '2015-12-01'),
(968, 1, 39, 1, '2015-09-03', '2015-12-01'),
(969, 17, 1, 1, '2015-09-07', '2015-09-07'),
(970, 17, 2, 1, '2015-09-07', '2015-09-07'),
(971, 17, 3, 1, '2015-09-07', '2015-09-07'),
(972, 17, 4, 1, '2015-09-07', '2015-09-07'),
(973, 17, 5, 1, '2015-09-07', '2015-09-07'),
(974, 17, 6, 1, '2015-09-07', '2015-09-07'),
(975, 17, 7, 1, '2015-09-07', '2015-09-07'),
(976, 17, 8, 1, '2015-09-07', '2015-09-07'),
(977, 17, 9, 1, '2015-09-07', '2015-09-07'),
(978, 17, 10, 1, '2015-09-07', '2015-09-07'),
(979, 17, 11, 1, '2015-09-07', '2015-09-07'),
(980, 17, 13, 1, '2015-09-07', '2015-09-07'),
(981, 17, 15, 1, '2015-09-07', '2015-09-07'),
(982, 17, 16, 1, '2015-09-07', '2015-09-07'),
(983, 17, 17, 1, '2015-09-07', '2015-09-07'),
(984, 17, 22, 1, '2015-09-07', '2015-09-07'),
(985, 17, 23, 1, '2015-09-07', '2015-09-07'),
(986, 17, 24, 1, '2015-09-07', '2015-09-07'),
(987, 17, 25, 1, '2015-09-07', '2015-09-07'),
(988, 17, 26, 1, '2015-09-07', '2015-09-07'),
(989, 17, 27, 1, '2015-09-07', '2015-09-07'),
(990, 17, 29, 1, '2015-09-07', '2015-09-07'),
(991, 17, 30, 1, '2015-09-07', '2015-09-07'),
(992, 17, 31, 1, '2015-09-07', '2015-09-07'),
(993, 17, 32, 1, '2015-09-07', '2015-09-07'),
(994, 17, 33, 1, '2015-09-07', '2015-09-07'),
(995, 17, 34, 1, '2015-09-07', '2015-09-07'),
(996, 17, 35, 1, '2015-09-07', '2015-09-07'),
(997, 17, 36, 1, '2015-09-07', '2015-09-07'),
(998, 17, 37, 1, '2015-09-07', '2015-09-07'),
(999, 17, 38, 1, '2015-09-07', '2015-09-07'),
(1000, 17, 39, 1, '2015-09-07', '2015-09-07'),
(1001, 1, 40, 1, '2015-09-08', '2015-12-01'),
(1002, 1, 41, 1, '2015-09-14', '2015-12-01'),
(1003, 1, 42, 1, '2015-09-14', '2015-12-01'),
(1004, 2, 40, 1, '2015-09-14', '2015-12-31'),
(1005, 2, 41, 1, '2015-09-14', '2015-12-31'),
(1006, 2, 42, 1, '2015-09-14', '2015-12-31'),
(1007, 18, 1, 0, '2015-09-22', '2015-09-22'),
(1008, 18, 2, 0, '2015-09-22', '2015-09-22'),
(1009, 18, 3, 0, '2015-09-22', '2015-09-22'),
(1010, 18, 4, 0, '2015-09-22', '2015-09-22'),
(1011, 18, 5, 0, '2015-09-22', '2015-09-22'),
(1012, 18, 6, 0, '2015-09-22', '2015-09-22'),
(1013, 18, 7, 0, '2015-09-22', '2015-09-22'),
(1014, 18, 8, 0, '2015-09-22', '2015-09-22'),
(1015, 18, 9, 0, '2015-09-22', '2015-09-22'),
(1016, 18, 10, 0, '2015-09-22', '2015-09-22'),
(1017, 18, 11, 1, '2015-09-22', '2015-09-22'),
(1018, 18, 13, 1, '2015-09-22', '2015-09-22'),
(1019, 18, 15, 1, '2015-09-22', '2015-09-22'),
(1020, 18, 16, 1, '2015-09-22', '2015-09-22'),
(1021, 18, 17, 1, '2015-09-22', '2015-09-22'),
(1022, 18, 22, 0, '2015-09-22', '2015-09-22'),
(1023, 18, 23, 0, '2015-09-22', '2015-09-22'),
(1024, 18, 24, 0, '2015-09-22', '2015-09-22'),
(1025, 18, 25, 0, '2015-09-22', '2015-09-22'),
(1026, 18, 26, 0, '2015-09-22', '2015-09-22'),
(1027, 18, 27, 0, '2015-09-22', '2015-09-22'),
(1028, 18, 29, 0, '2015-09-22', '2015-09-22'),
(1029, 18, 30, 0, '2015-09-22', '2015-09-22'),
(1030, 18, 32, 0, '2015-09-22', '2015-09-22'),
(1031, 18, 34, 0, '2015-09-22', '2015-09-22'),
(1032, 18, 35, 0, '2015-09-22', '2015-09-22'),
(1033, 18, 36, 0, '2015-09-22', '2015-09-22'),
(1034, 18, 37, 0, '2015-09-22', '2015-09-22'),
(1035, 18, 38, 0, '2015-09-22', '2015-09-22'),
(1036, 18, 39, 0, '2015-09-22', '2015-09-22'),
(1037, 18, 40, 0, '2015-09-22', '2015-09-22'),
(1038, 18, 41, 0, '2015-09-22', '2015-09-22'),
(1039, 18, 42, 0, '2015-09-22', '2015-09-22'),
(1040, 19, 1, 0, '2015-09-22', '2015-09-22'),
(1041, 19, 2, 0, '2015-09-22', '2015-09-22'),
(1042, 19, 3, 0, '2015-09-22', '2015-09-22'),
(1043, 19, 4, 0, '2015-09-22', '2015-09-22'),
(1044, 19, 5, 0, '2015-09-22', '2015-09-22'),
(1045, 19, 6, 0, '2015-09-22', '2015-09-22'),
(1046, 19, 7, 0, '2015-09-22', '2015-09-22'),
(1047, 19, 8, 0, '2015-09-22', '2015-09-22'),
(1048, 19, 9, 0, '2015-09-22', '2015-09-22'),
(1049, 19, 10, 0, '2015-09-22', '2015-09-22'),
(1050, 19, 11, 0, '2015-09-22', '2015-09-22'),
(1051, 19, 13, 0, '2015-09-22', '2015-09-22'),
(1052, 19, 15, 0, '2015-09-22', '2015-09-22'),
(1053, 19, 16, 0, '2015-09-22', '2015-09-22'),
(1054, 19, 17, 0, '2015-09-22', '2015-09-22'),
(1055, 19, 22, 0, '2015-09-22', '2015-09-22'),
(1056, 19, 23, 0, '2015-09-22', '2015-09-22'),
(1057, 19, 24, 0, '2015-09-22', '2015-09-22'),
(1058, 19, 25, 0, '2015-09-22', '2015-09-22'),
(1059, 19, 26, 1, '2015-09-22', '2015-09-22'),
(1060, 19, 27, 1, '2015-09-22', '2015-09-22'),
(1061, 19, 29, 0, '2015-09-22', '2015-09-22'),
(1062, 19, 30, 0, '2015-09-22', '2015-09-22'),
(1063, 19, 32, 0, '2015-09-22', '2015-09-22'),
(1064, 19, 34, 0, '2015-09-22', '2015-09-22'),
(1065, 19, 35, 0, '2015-09-22', '2015-09-22'),
(1066, 19, 36, 0, '2015-09-22', '2015-09-22'),
(1067, 19, 37, 0, '2015-09-22', '2015-09-22'),
(1068, 19, 38, 0, '2015-09-22', '2015-09-22'),
(1069, 19, 39, 0, '2015-09-22', '2015-09-22'),
(1070, 19, 40, 0, '2015-09-22', '2015-09-22'),
(1071, 19, 41, 0, '2015-09-22', '2015-09-22'),
(1072, 19, 42, 0, '2015-09-22', '2015-09-22'),
(1073, 20, 1, 0, '2015-09-22', '2015-09-22'),
(1074, 20, 2, 0, '2015-09-22', '2015-09-22'),
(1075, 20, 3, 0, '2015-09-22', '2015-09-22'),
(1076, 20, 4, 0, '2015-09-22', '2015-09-22'),
(1077, 20, 5, 0, '2015-09-22', '2015-09-22'),
(1078, 20, 6, 0, '2015-09-22', '2015-09-22'),
(1079, 20, 7, 0, '2015-09-22', '2015-09-22'),
(1080, 20, 8, 0, '2015-09-22', '2015-09-22'),
(1081, 20, 9, 0, '2015-09-22', '2015-09-22'),
(1082, 20, 10, 0, '2015-09-22', '2015-09-22'),
(1083, 20, 11, 0, '2015-09-22', '2015-09-22'),
(1084, 20, 13, 0, '2015-09-22', '2015-09-22'),
(1085, 20, 15, 0, '2015-09-22', '2015-09-22'),
(1086, 20, 16, 0, '2015-09-22', '2015-09-22'),
(1087, 20, 17, 0, '2015-09-22', '2015-09-22'),
(1088, 20, 22, 0, '2015-09-22', '2015-09-22'),
(1089, 20, 23, 0, '2015-09-22', '2015-09-22'),
(1090, 20, 24, 0, '2015-09-22', '2015-09-22'),
(1091, 20, 25, 0, '2015-09-22', '2015-09-22'),
(1092, 20, 26, 1, '2015-09-22', '2015-09-22'),
(1093, 20, 27, 1, '2015-09-22', '2015-09-22'),
(1094, 20, 29, 0, '2015-09-22', '2015-09-22'),
(1095, 20, 30, 0, '2015-09-22', '2015-09-22'),
(1096, 20, 32, 0, '2015-09-22', '2015-09-22'),
(1097, 20, 34, 0, '2015-09-22', '2015-09-22'),
(1098, 20, 35, 0, '2015-09-22', '2015-09-22'),
(1099, 20, 36, 0, '2015-09-22', '2015-09-22'),
(1100, 20, 37, 0, '2015-09-22', '2015-09-22'),
(1101, 20, 38, 0, '2015-09-22', '2015-09-22'),
(1102, 20, 39, 0, '2015-09-22', '2015-09-22'),
(1103, 20, 40, 0, '2015-09-22', '2015-09-22'),
(1104, 20, 41, 0, '2015-09-22', '2015-09-22'),
(1105, 20, 42, 0, '2015-09-22', '2015-09-22'),
(1106, 21, 1, 0, '2015-09-30', '2015-09-30'),
(1107, 21, 2, 0, '2015-09-30', '2015-09-30'),
(1108, 21, 3, 0, '2015-09-30', '2015-09-30'),
(1109, 21, 4, 0, '2015-09-30', '2015-09-30'),
(1110, 21, 5, 0, '2015-09-30', '2015-09-30'),
(1111, 21, 6, 0, '2015-09-30', '2015-09-30'),
(1112, 21, 7, 0, '2015-09-30', '2015-09-30'),
(1113, 21, 8, 0, '2015-09-30', '2015-09-30'),
(1114, 21, 9, 0, '2015-09-30', '2015-09-30'),
(1115, 21, 10, 0, '2015-09-30', '2015-09-30'),
(1116, 21, 11, 1, '2015-09-30', '2015-09-30'),
(1117, 21, 13, 1, '2015-09-30', '2015-09-30'),
(1118, 21, 15, 1, '2015-09-30', '2015-09-30'),
(1119, 21, 16, 1, '2015-09-30', '2015-09-30'),
(1120, 21, 17, 1, '2015-09-30', '2015-09-30'),
(1121, 21, 22, 0, '2015-09-30', '2015-09-30'),
(1122, 21, 23, 0, '2015-09-30', '2015-09-30'),
(1123, 21, 24, 0, '2015-09-30', '2015-09-30'),
(1124, 21, 25, 0, '2015-09-30', '2015-09-30'),
(1125, 21, 26, 0, '2015-09-30', '2015-09-30'),
(1126, 21, 27, 0, '2015-09-30', '2015-09-30'),
(1127, 21, 29, 0, '2015-09-30', '2015-09-30'),
(1128, 21, 30, 0, '2015-09-30', '2015-09-30'),
(1129, 21, 32, 0, '2015-09-30', '2015-09-30'),
(1130, 21, 34, 0, '2015-09-30', '2015-09-30'),
(1131, 21, 35, 0, '2015-09-30', '2015-09-30'),
(1132, 21, 36, 0, '2015-09-30', '2015-09-30'),
(1133, 21, 37, 0, '2015-09-30', '2015-09-30'),
(1134, 21, 38, 0, '2015-09-30', '2015-09-30'),
(1135, 21, 39, 0, '2015-09-30', '2015-09-30'),
(1136, 21, 40, 0, '2015-09-30', '2015-09-30'),
(1137, 21, 41, 0, '2015-09-30', '2015-09-30'),
(1138, 21, 42, 0, '2015-09-30', '2015-09-30'),
(1139, 22, 1, 0, '2015-09-30', '2015-09-30'),
(1140, 22, 2, 0, '2015-09-30', '2015-09-30'),
(1141, 22, 3, 0, '2015-09-30', '2015-09-30'),
(1142, 22, 4, 0, '2015-09-30', '2015-09-30'),
(1143, 22, 5, 0, '2015-09-30', '2015-09-30'),
(1144, 22, 6, 0, '2015-09-30', '2015-09-30'),
(1145, 22, 7, 0, '2015-09-30', '2015-09-30'),
(1146, 22, 8, 0, '2015-09-30', '2015-09-30'),
(1147, 22, 9, 0, '2015-09-30', '2015-09-30'),
(1148, 22, 10, 0, '2015-09-30', '2015-09-30'),
(1149, 22, 11, 0, '2015-09-30', '2015-09-30'),
(1150, 22, 13, 0, '2015-09-30', '2015-09-30'),
(1151, 22, 15, 0, '2015-09-30', '2015-09-30'),
(1152, 22, 16, 0, '2015-09-30', '2015-09-30'),
(1153, 22, 17, 0, '2015-09-30', '2015-09-30'),
(1154, 22, 22, 0, '2015-09-30', '2015-09-30'),
(1155, 22, 23, 0, '2015-09-30', '2015-09-30'),
(1156, 22, 24, 0, '2015-09-30', '2015-09-30'),
(1157, 22, 25, 0, '2015-09-30', '2015-09-30'),
(1158, 22, 26, 1, '2015-09-30', '2015-09-30'),
(1159, 22, 27, 1, '2015-09-30', '2015-09-30'),
(1160, 22, 29, 0, '2015-09-30', '2015-09-30'),
(1161, 22, 30, 0, '2015-09-30', '2015-09-30'),
(1162, 22, 32, 0, '2015-09-30', '2015-09-30'),
(1163, 22, 34, 0, '2015-09-30', '2015-09-30'),
(1164, 22, 35, 0, '2015-09-30', '2015-09-30'),
(1165, 22, 36, 0, '2015-09-30', '2015-09-30'),
(1166, 22, 37, 0, '2015-09-30', '2015-09-30'),
(1167, 22, 38, 0, '2015-09-30', '2015-09-30'),
(1168, 22, 39, 0, '2015-09-30', '2015-09-30'),
(1169, 22, 40, 0, '2015-09-30', '2015-09-30'),
(1170, 22, 41, 0, '2015-09-30', '2015-09-30'),
(1171, 22, 42, 0, '2015-09-30', '2015-09-30'),
(1172, 1, 43, 1, '2015-10-21', '2015-12-01'),
(1173, 23, 1, 1, '2015-10-27', '2015-10-27'),
(1174, 23, 2, 1, '2015-10-27', '2015-10-27'),
(1175, 23, 3, 1, '2015-10-27', '2015-10-27'),
(1176, 23, 4, 1, '2015-10-27', '2015-10-27'),
(1177, 23, 5, 1, '2015-10-27', '2015-10-27'),
(1178, 23, 6, 1, '2015-10-27', '2015-10-27'),
(1179, 23, 7, 1, '2015-10-27', '2015-10-27'),
(1180, 23, 8, 1, '2015-10-27', '2015-10-27'),
(1181, 23, 9, 1, '2015-10-27', '2015-10-27'),
(1182, 23, 10, 1, '2015-10-27', '2015-10-27'),
(1183, 23, 11, 1, '2015-10-27', '2015-10-27'),
(1184, 23, 13, 1, '2015-10-27', '2015-10-27'),
(1185, 23, 15, 1, '2015-10-27', '2015-10-27'),
(1186, 23, 16, 1, '2015-10-27', '2015-10-27'),
(1187, 23, 17, 1, '2015-10-27', '2015-10-27'),
(1188, 23, 22, 1, '2015-10-27', '2015-10-27'),
(1189, 23, 23, 1, '2015-10-27', '2015-10-27'),
(1190, 23, 24, 1, '2015-10-27', '2015-10-27'),
(1191, 23, 25, 1, '2015-10-27', '2015-10-27'),
(1192, 23, 26, 1, '2015-10-27', '2015-10-27'),
(1193, 23, 27, 1, '2015-10-27', '2015-10-27'),
(1194, 23, 29, 1, '2015-10-27', '2015-10-27'),
(1195, 23, 30, 1, '2015-10-27', '2015-10-27'),
(1196, 23, 32, 1, '2015-10-27', '2015-10-27'),
(1197, 23, 34, 1, '2015-10-27', '2015-10-27'),
(1198, 23, 35, 1, '2015-10-27', '2015-10-27'),
(1199, 23, 36, 1, '2015-10-27', '2015-10-27'),
(1200, 23, 37, 1, '2015-10-27', '2015-10-27'),
(1201, 23, 38, 1, '2015-10-27', '2015-10-27'),
(1202, 23, 39, 1, '2015-10-27', '2015-10-27'),
(1203, 23, 40, 1, '2015-10-27', '2015-10-27'),
(1204, 23, 41, 1, '2015-10-27', '2015-10-27'),
(1205, 23, 42, 1, '2015-10-27', '2015-10-27'),
(1206, 23, 43, 1, '2015-10-27', '2015-10-27'),
(1207, 2, 43, 1, '2015-12-31', '2015-12-31'),
(1208, 3, 1, 1, '2015-12-31', '2015-12-31'),
(1209, 3, 2, 1, '2015-12-31', '2015-12-31'),
(1210, 3, 3, 1, '2015-12-31', '2015-12-31'),
(1211, 3, 4, 1, '2015-12-31', '2015-12-31'),
(1212, 3, 5, 1, '2015-12-31', '2015-12-31'),
(1213, 3, 6, 1, '2015-12-31', '2015-12-31'),
(1214, 3, 7, 1, '2015-12-31', '2015-12-31'),
(1215, 3, 8, 1, '2015-12-31', '2015-12-31'),
(1216, 3, 9, 1, '2015-12-31', '2015-12-31'),
(1217, 3, 10, 1, '2015-12-31', '2015-12-31'),
(1218, 3, 11, 1, '2015-12-31', '2015-12-31'),
(1219, 3, 13, 1, '2015-12-31', '2015-12-31'),
(1220, 3, 15, 1, '2015-12-31', '2015-12-31'),
(1221, 3, 16, 1, '2015-12-31', '2015-12-31'),
(1222, 3, 17, 1, '2015-12-31', '2015-12-31'),
(1223, 3, 22, 1, '2015-12-31', '2015-12-31'),
(1224, 3, 23, 1, '2015-12-31', '2015-12-31'),
(1225, 3, 24, 1, '2015-12-31', '2015-12-31'),
(1226, 3, 25, 1, '2015-12-31', '2015-12-31'),
(1227, 3, 26, 1, '2015-12-31', '2015-12-31'),
(1228, 3, 27, 1, '2015-12-31', '2015-12-31'),
(1229, 3, 29, 1, '2015-12-31', '2015-12-31'),
(1230, 3, 30, 1, '2015-12-31', '2015-12-31'),
(1231, 3, 32, 1, '2015-12-31', '2015-12-31'),
(1232, 3, 34, 1, '2015-12-31', '2015-12-31'),
(1233, 3, 35, 1, '2015-12-31', '2015-12-31'),
(1234, 3, 36, 1, '2015-12-31', '2015-12-31'),
(1235, 3, 37, 1, '2015-12-31', '2015-12-31'),
(1236, 3, 38, 1, '2015-12-31', '2015-12-31'),
(1237, 3, 39, 1, '2015-12-31', '2015-12-31'),
(1238, 3, 40, 1, '2015-12-31', '2015-12-31'),
(1239, 3, 41, 1, '2015-12-31', '2015-12-31'),
(1240, 3, 42, 1, '2015-12-31', '2015-12-31'),
(1241, 3, 43, 1, '2015-12-31', '2015-12-31'),
(1242, 1, 44, 1, '2015-11-18', '2015-12-01'),
(1243, 1, 45, 1, '2015-11-24', '2015-12-01'),
(1244, 5, 1, 1, '2015-11-24', '2015-11-24'),
(1245, 5, 2, 1, '2015-11-24', '2015-11-24'),
(1246, 5, 3, 1, '2015-11-24', '2015-11-24'),
(1247, 5, 4, 1, '2015-11-24', '2015-11-24'),
(1248, 5, 5, 1, '2015-11-24', '2015-11-24'),
(1249, 5, 6, 1, '2015-11-24', '2015-11-24'),
(1250, 5, 7, 1, '2015-11-24', '2015-11-24'),
(1251, 5, 8, 1, '2015-11-24', '2015-11-24'),
(1252, 5, 9, 1, '2015-11-24', '2015-11-24'),
(1253, 5, 10, 1, '2015-11-24', '2015-11-24'),
(1254, 5, 11, 1, '2015-11-24', '2015-11-24'),
(1255, 5, 13, 1, '2015-11-24', '2015-11-24'),
(1256, 5, 15, 1, '2015-11-24', '2015-11-24'),
(1257, 5, 16, 1, '2015-11-24', '2015-11-24'),
(1258, 5, 17, 1, '2015-11-24', '2015-11-24'),
(1259, 5, 22, 1, '2015-11-24', '2015-11-24'),
(1260, 5, 23, 1, '2015-11-24', '2015-11-24'),
(1261, 5, 24, 1, '2015-11-24', '2015-11-24'),
(1262, 5, 25, 1, '2015-11-24', '2015-11-24'),
(1263, 5, 26, 1, '2015-11-24', '2015-11-24'),
(1264, 5, 27, 1, '2015-11-24', '2015-11-24'),
(1265, 5, 29, 1, '2015-11-24', '2015-11-24'),
(1266, 5, 30, 1, '2015-11-24', '2015-11-24'),
(1267, 5, 32, 1, '2015-11-24', '2015-11-24'),
(1268, 5, 34, 1, '2015-11-24', '2015-11-24'),
(1269, 5, 35, 1, '2015-11-24', '2015-11-24'),
(1270, 5, 36, 1, '2015-11-24', '2015-11-24'),
(1271, 5, 37, 1, '2015-11-24', '2015-11-24'),
(1272, 5, 38, 1, '2015-11-24', '2015-11-24'),
(1273, 5, 39, 1, '2015-11-24', '2015-11-24'),
(1274, 5, 40, 1, '2015-11-24', '2015-11-24'),
(1275, 5, 41, 1, '2015-11-24', '2015-11-24'),
(1276, 5, 42, 1, '2015-11-24', '2015-11-24'),
(1277, 5, 43, 1, '2015-11-24', '2015-11-24'),
(1278, 5, 44, 1, '2015-11-24', '2015-11-24'),
(1279, 5, 45, 1, '2015-11-24', '2015-11-24'),
(1280, 1, 46, 1, '2015-11-25', '2015-12-01'),
(1281, 1, 47, 1, '2015-11-26', '2015-12-01'),
(1282, 4, 1, 1, '2015-11-26', '2015-11-26'),
(1283, 4, 2, 1, '2015-11-26', '2015-11-26'),
(1284, 4, 3, 1, '2015-11-26', '2015-11-26'),
(1285, 4, 4, 1, '2015-11-26', '2015-11-26'),
(1286, 4, 5, 1, '2015-11-26', '2015-11-26'),
(1287, 4, 6, 1, '2015-11-26', '2015-11-26'),
(1288, 4, 7, 1, '2015-11-26', '2015-11-26'),
(1289, 4, 8, 1, '2015-11-26', '2015-11-26'),
(1290, 4, 9, 1, '2015-11-26', '2015-11-26'),
(1291, 4, 10, 1, '2015-11-26', '2015-11-26'),
(1292, 4, 11, 1, '2015-11-26', '2015-11-26'),
(1293, 4, 13, 1, '2015-11-26', '2015-11-26'),
(1294, 4, 15, 1, '2015-11-26', '2015-11-26'),
(1295, 4, 16, 1, '2015-11-26', '2015-11-26'),
(1296, 4, 17, 1, '2015-11-26', '2015-11-26'),
(1297, 4, 22, 1, '2015-11-26', '2015-11-26'),
(1298, 4, 23, 1, '2015-11-26', '2015-11-26'),
(1299, 4, 24, 1, '2015-11-26', '2015-11-26'),
(1300, 4, 25, 1, '2015-11-26', '2015-11-26'),
(1301, 4, 26, 1, '2015-11-26', '2015-11-26'),
(1302, 4, 27, 1, '2015-11-26', '2015-11-26'),
(1303, 4, 29, 1, '2015-11-26', '2015-11-26'),
(1304, 4, 30, 1, '2015-11-26', '2015-11-26'),
(1305, 4, 32, 1, '2015-11-26', '2015-11-26'),
(1306, 4, 34, 1, '2015-11-26', '2015-11-26'),
(1307, 4, 35, 1, '2015-11-26', '2015-11-26'),
(1308, 4, 36, 1, '2015-11-26', '2015-11-26'),
(1309, 4, 37, 1, '2015-11-26', '2015-11-26'),
(1310, 4, 38, 1, '2015-11-26', '2015-11-26'),
(1311, 4, 39, 1, '2015-11-26', '2015-11-26'),
(1312, 4, 40, 1, '2015-11-26', '2015-11-26'),
(1313, 4, 41, 1, '2015-11-26', '2015-11-26'),
(1314, 4, 42, 1, '2015-11-26', '2015-11-26'),
(1315, 4, 43, 1, '2015-11-26', '2015-11-26'),
(1316, 4, 44, 1, '2015-11-26', '2015-11-26'),
(1317, 4, 45, 1, '2015-11-26', '2015-11-26'),
(1318, 4, 46, 1, '2015-11-26', '2015-11-26'),
(1319, 4, 47, 1, '2015-11-26', '2015-11-26'),
(1320, 1, 48, 1, '2015-11-29', '2015-12-01'),
(1321, 1, 49, 1, '2015-12-01', '2015-12-01');

-- --------------------------------------------------------

--
-- Table structure for table `voucher`
--

CREATE TABLE IF NOT EXISTS `voucher` (
`id` int(11) NOT NULL,
  `vnno` text COLLATE utf32_bin NOT NULL,
  `vdate` date DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `status` int(10) NOT NULL,
  `type` int(11) NOT NULL,
  `sid` int(11) DEFAULT NULL,
  `cid` int(11) DEFAULT NULL,
  `vstatus` int(11) NOT NULL DEFAULT '0',
  `slno` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Dumping data for table `voucher`
--

INSERT INTO `voucher` (`id`, `vnno`, `vdate`, `amount`, `status`, `type`, `sid`, `cid`, `vstatus`, `slno`, `userid`, `created_at`, `updated_at`) VALUES
(1, 'V-0000001', '2015-12-01', '349000.00', 2, 1, 7, NULL, 1, 1, 1, '2015-12-01', '2015-12-01'),
(2, 'V-0000002', '2015-12-01', '4000.00', 1, 9, NULL, 3, 1, 2, 1, '2015-12-01', '2015-12-01'),
(3, 'V-0000003', '2015-12-01', '3000.00', 1, 8, NULL, 6, 1, 3, 1, '2015-12-01', '2015-12-01'),
(5, 'V-0000005', '2015-12-01', '8000.00', 1, 6, NULL, 4, 1, 5, 1, '2015-12-01', '2015-12-01'),
(6, 'V-0000006', '2015-12-01', '1000.00', 1, 6, NULL, 2, 1, 6, 1, '2015-12-01', '2015-12-01'),
(7, 'V-0000007', '2015-12-01', '8000.00', 1, 4, NULL, 2, 1, 7, 1, '2015-12-01', '2015-12-01'),
(9, 'V-0000009', '2015-12-01', '6000.00', 2, 2, 6, NULL, 1, 9, 1, '2015-12-01', '2015-12-01'),
(10, 'V-0000010', '2015-12-01', '9000.00', 1, 5, NULL, NULL, 1, 10, 1, '2015-12-01', '2015-12-01'),
(11, 'V-0000011', '2015-12-01', '6000.00', 2, 5, NULL, NULL, 1, 11, 1, '2015-12-01', '2015-12-01'),
(12, 'V-0000012', '2015-12-01', '5000.00', 1, 3, NULL, 2, 1, 12, 1, '2015-12-01', '2015-12-01'),
(15, 'V-0000013', '2015-12-02', '349000.00', 1, 4, NULL, 2, 1, 13, 1, '2015-12-03', '2015-12-03'),
(16, 'V-0000014', '2015-12-02', '12000.00', 3, 5, NULL, NULL, 1, 14, 1, '2015-12-04', '2015-12-04'),
(17, 'V-0000015', '2015-12-05', '5000.00', 1, 4, NULL, 2, 1, 15, 1, '2015-12-05', '2015-12-05'),
(18, 'V-0000016', '2015-12-05', '100000.00', 2, 2, 7, NULL, 1, 16, 1, '2015-12-05', '2015-12-05'),
(19, 'V-0000017', '2015-12-06', '5000.00', 1, 4, NULL, 3, 0, 17, 1, '2015-12-06', '2015-12-06'),
(20, 'V-0000018', '2015-12-06', '5000.00', 1, 9, NULL, 2, 1, 18, 1, '2015-12-06', '2015-12-06'),
(21, 'V-0000019', '2015-12-06', '10000.00', 1, 4, NULL, 50, 1, 19, 1, '2015-12-06', '2015-12-06'),
(22, 'V-0000020', '2015-12-06', '20000.00', 1, 3, NULL, 50, 1, 20, 1, '2015-12-06', '2015-12-06'),
(23, 'V-0000021', '2015-12-06', '10000.00', 1, 6, NULL, 50, 1, 21, 1, '2015-12-06', '2015-12-06'),
(24, 'V-0000022', '2015-12-06', '10000.00', 1, 9, NULL, 50, 1, 22, 1, '2015-12-06', '2015-12-06'),
(25, 'V-0000023', '2015-12-06', '20000.00', 1, 7, NULL, 50, 1, 23, 1, '2015-12-06', '2015-12-06'),
(26, 'V-0000024', '2015-12-06', '100000.00', 2, 2, 40, NULL, 1, 24, 1, '2015-12-06', '2015-12-06'),
(27, 'V-0000025', '2015-12-06', '200000.00', 2, 1, 40, NULL, 1, 25, 1, '2015-12-06', '2015-12-06'),
(28, 'V-0000026', '2015-12-06', '20000.00', 1, 5, NULL, NULL, 1, 26, 1, '2015-12-06', '2015-12-06'),
(29, 'V-0000027', '2015-12-06', '15000.00', 1, 5, NULL, NULL, 1, 27, 1, '2015-12-06', '2015-12-06');

-- --------------------------------------------------------

--
-- Table structure for table `voucherbankpayment`
--

CREATE TABLE IF NOT EXISTS `voucherbankpayment` (
`id` int(11) NOT NULL,
  `vid` int(11) NOT NULL,
  `baccid` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `checkno` text COLLATE utf32_bin NOT NULL,
  `userid` int(11) NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Dumping data for table `voucherbankpayment`
--

INSERT INTO `voucherbankpayment` (`id`, `vid`, `baccid`, `sid`, `checkno`, `userid`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 7, '6666', 1, '2015-12-01', '2015-12-01'),
(2, 27, 1, 40, '123456', 1, '2015-12-06', '2015-12-06');

-- --------------------------------------------------------

--
-- Table structure for table `voucherbankreceive`
--

CREATE TABLE IF NOT EXISTS `voucherbankreceive` (
`id` int(11) NOT NULL,
  `vid` int(11) NOT NULL,
  `baccid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `checkno` text COLLATE utf32_bin NOT NULL,
  `userid` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Dumping data for table `voucherbankreceive`
--

INSERT INTO `voucherbankreceive` (`id`, `vid`, `baccid`, `cid`, `checkno`, `userid`, `created_at`, `updated_at`) VALUES
(1, 12, 1, 2, '111', 1, '2015-12-01 05:18:25', '2015-12-01 05:18:25'),
(2, 22, 1, 50, '', 1, '2015-12-06 04:38:12', '2015-12-06 04:38:12');

-- --------------------------------------------------------

--
-- Table structure for table `voucherbkash`
--

CREATE TABLE IF NOT EXISTS `voucherbkash` (
`id` int(11) NOT NULL,
  `vid` int(11) NOT NULL,
  `bkashno` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Dumping data for table `voucherbkash`
--

INSERT INTO `voucherbkash` (`id`, `vid`, `bkashno`, `cid`, `userid`, `created_at`, `updated_at`) VALUES
(1, 5, 67467575, 4, 1, '2015-12-01 04:04:32', '2015-12-01 04:04:32'),
(2, 6, 7878787, 2, 1, '2015-12-01 04:04:52', '2015-12-01 04:04:52'),
(3, 13, 54708989, 3, 1, '2015-12-03 01:31:33', '2015-12-03 01:31:33'),
(4, 14, 54708989, 3, 1, '2015-12-03 01:31:57', '2015-12-03 01:31:57'),
(5, 23, 1711112050, 50, 1, '2015-12-06 04:38:52', '2015-12-06 04:38:52');

-- --------------------------------------------------------

--
-- Table structure for table `vouchercontra`
--

CREATE TABLE IF NOT EXISTS `vouchercontra` (
`id` int(11) NOT NULL,
  `vid` int(11) NOT NULL,
  `baccid` int(11) NOT NULL,
  `cashid` int(11) NOT NULL,
  `checkno` text COLLATE utf32_bin NOT NULL,
  `userid` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Dumping data for table `vouchercontra`
--

INSERT INTO `vouchercontra` (`id`, `vid`, `baccid`, `cashid`, `checkno`, `userid`, `created_at`, `updated_at`) VALUES
(1, 10, 2, 1, '15474', 1, '2015-12-01 04:45:22', '2015-12-01 04:45:22'),
(2, 11, 2, 1, '157141', 1, '2015-12-01 04:46:06', '2015-12-01 04:46:06'),
(3, 16, 2, 3, '6666', 1, '2015-12-04 04:50:58', '2015-12-04 04:50:58'),
(4, 28, 1, 1, '234567', 1, '2015-12-06 04:49:38', '2015-12-06 04:49:38'),
(5, 29, 1, 1, '123459', 1, '2015-12-06 05:04:40', '2015-12-06 05:04:40');

-- --------------------------------------------------------

--
-- Table structure for table `voucherkcs`
--

CREATE TABLE IF NOT EXISTS `voucherkcs` (
`id` int(11) NOT NULL,
  `vid` int(11) NOT NULL,
  `kcsno` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `voucherkcs`
--

INSERT INTO `voucherkcs` (`id`, `vid`, `kcsno`, `cid`, `userid`, `created_at`, `updated_at`) VALUES
(1, 16, 43565, 2, 1, '2015-12-01 00:00:26', '2015-12-01 00:00:26'),
(2, 3, 75668, 6, 1, '2015-12-01 04:03:55', '2015-12-01 04:03:55');

-- --------------------------------------------------------

--
-- Table structure for table `vouchermbank`
--

CREATE TABLE IF NOT EXISTS `vouchermbank` (
`id` int(11) NOT NULL,
  `vid` int(11) NOT NULL,
  `mbankno` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vouchermbank`
--

INSERT INTO `vouchermbank` (`id`, `vid`, `mbankno`, `cid`, `userid`, `created_at`, `updated_at`) VALUES
(1, 2, 56665, 3, 1, '2015-12-01 04:03:37', '2015-12-01 04:03:37'),
(2, 20, 123212, 2, 1, '2015-12-06 02:08:54', '2015-12-06 02:08:54'),
(3, 24, 1711112054, 50, 1, '2015-12-06 04:39:26', '2015-12-06 04:39:26');

-- --------------------------------------------------------

--
-- Table structure for table `voucherpayment`
--

CREATE TABLE IF NOT EXISTS `voucherpayment` (
`id` int(11) NOT NULL,
  `vid` int(11) NOT NULL,
  `baccid` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Dumping data for table `voucherpayment`
--

INSERT INTO `voucherpayment` (`id`, `vid`, `baccid`, `sid`, `userid`, `created_at`, `updated_at`) VALUES
(1, 9, 1, 6, 1, '2015-12-01 04:06:21', '2015-12-01 04:06:21'),
(2, 18, 1, 7, 1, '2015-12-05 05:54:42', '2015-12-05 05:54:42'),
(3, 26, 1, 40, 1, '2015-12-06 04:45:32', '2015-12-06 04:45:32');

-- --------------------------------------------------------

--
-- Table structure for table `voucherreceive`
--

CREATE TABLE IF NOT EXISTS `voucherreceive` (
`id` int(11) NOT NULL,
  `vid` int(11) NOT NULL,
  `baccid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Dumping data for table `voucherreceive`
--

INSERT INTO `voucherreceive` (`id`, `vid`, `baccid`, `cid`, `userid`, `created_at`, `updated_at`) VALUES
(1, 7, 1, 2, 1, '2015-12-01 04:05:08', '2015-12-01 04:05:08'),
(2, 15, 1, 2, 1, '2015-12-03 01:32:25', '2015-12-03 01:32:25'),
(3, 17, 1, 2, 1, '2015-12-04 22:14:24', '2015-12-04 22:14:24'),
(4, 19, 1, 3, 1, '2015-12-06 02:08:07', '2015-12-06 02:08:07'),
(5, 21, 1, 50, 1, '2015-12-06 04:37:28', '2015-12-06 04:37:28');

-- --------------------------------------------------------

--
-- Table structure for table `vouchersap`
--

CREATE TABLE IF NOT EXISTS `vouchersap` (
`id` int(11) NOT NULL,
  `vid` int(11) NOT NULL,
  `sapno` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Dumping data for table `vouchersap`
--

INSERT INTO `vouchersap` (`id`, `vid`, `sapno`, `cid`, `userid`, `created_at`, `updated_at`) VALUES
(1, 4, 6756765, 7, 1, '2015-12-01 04:04:11', '2015-12-01 04:04:11'),
(2, 8, 4000, 4, 1, '2015-12-01 04:05:36', '2015-12-01 04:05:36'),
(3, 25, 1711112050, 50, 1, '2015-12-06 04:40:21', '2015-12-06 04:40:21');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bankaccount`
--
ALTER TABLE `bankaccount`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bankbook`
--
ALTER TABLE `bankbook`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bankinfo`
--
ALTER TABLE `bankinfo`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `banktitle`
--
ALTER TABLE `banktitle`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `billspay`
--
ALTER TABLE `billspay`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coa`
--
ALTER TABLE `coa`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coatype`
--
ALTER TABLE `coatype`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `companyprofile`
--
ALTER TABLE `companyprofile`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customersledger`
--
ALTER TABLE `customersledger`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employeeinfo`
--
ALTER TABLE `employeeinfo`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employeesal`
--
ALTER TABLE `employeesal`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `factioyitems`
--
ALTER TABLE `factioyitems`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `increasetype`
--
ALTER TABLE `increasetype`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `itemsgroup`
--
ALTER TABLE `itemsgroup`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `itemssubgroup`
--
ALTER TABLE `itemssubgroup`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `measurementgroup`
--
ALTER TABLE `measurementgroup`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `measurementunit`
--
ALTER TABLE `measurementunit`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menus`
--
ALTER TABLE `menus`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `particulars`
--
ALTER TABLE `particulars`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pettycash`
--
ALTER TABLE `pettycash`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purchase`
--
ALTER TABLE `purchase`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purchasedetails`
--
ALTER TABLE `purchasedetails`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purchaseinventory`
--
ALTER TABLE `purchaseinventory`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `replacechallan`
--
ALTER TABLE `replacechallan`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `salesdetails`
--
ALTER TABLE `salesdetails`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `submenus`
--
ALTER TABLE `submenus`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `suppliersledger`
--
ALTER TABLE `suppliersledger`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `taxrate`
--
ALTER TABLE `taxrate`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usergroups`
--
ALTER TABLE `usergroups`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userspermission`
--
ALTER TABLE `userspermission`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `voucher`
--
ALTER TABLE `voucher`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `voucherbankpayment`
--
ALTER TABLE `voucherbankpayment`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `voucherbankreceive`
--
ALTER TABLE `voucherbankreceive`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `voucherbkash`
--
ALTER TABLE `voucherbkash`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vouchercontra`
--
ALTER TABLE `vouchercontra`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `voucherkcs`
--
ALTER TABLE `voucherkcs`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vouchermbank`
--
ALTER TABLE `vouchermbank`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `voucherpayment`
--
ALTER TABLE `voucherpayment`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `voucherreceive`
--
ALTER TABLE `voucherreceive`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vouchersap`
--
ALTER TABLE `vouchersap`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bankaccount`
--
ALTER TABLE `bankaccount`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `bankbook`
--
ALTER TABLE `bankbook`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `bankinfo`
--
ALTER TABLE `bankinfo`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `banktitle`
--
ALTER TABLE `banktitle`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `billspay`
--
ALTER TABLE `billspay`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `coa`
--
ALTER TABLE `coa`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `coatype`
--
ALTER TABLE `coatype`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `companyprofile`
--
ALTER TABLE `companyprofile`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=51;
--
-- AUTO_INCREMENT for table `customersledger`
--
ALTER TABLE `customersledger`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=97;
--
-- AUTO_INCREMENT for table `employeeinfo`
--
ALTER TABLE `employeeinfo`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `employeesal`
--
ALTER TABLE `employeesal`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `factioyitems`
--
ALTER TABLE `factioyitems`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=56;
--
-- AUTO_INCREMENT for table `increasetype`
--
ALTER TABLE `increasetype`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=133;
--
-- AUTO_INCREMENT for table `itemsgroup`
--
ALTER TABLE `itemsgroup`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `itemssubgroup`
--
ALTER TABLE `itemssubgroup`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `measurementgroup`
--
ALTER TABLE `measurementgroup`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `measurementunit`
--
ALTER TABLE `measurementunit`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `menus`
--
ALTER TABLE `menus`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `particulars`
--
ALTER TABLE `particulars`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `pettycash`
--
ALTER TABLE `pettycash`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `purchase`
--
ALTER TABLE `purchase`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `purchasedetails`
--
ALTER TABLE `purchasedetails`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `purchaseinventory`
--
ALTER TABLE `purchaseinventory`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `replacechallan`
--
ALTER TABLE `replacechallan`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `salesdetails`
--
ALTER TABLE `salesdetails`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `submenus`
--
ALTER TABLE `submenus`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=50;
--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT for table `suppliersledger`
--
ALTER TABLE `suppliersledger`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `taxrate`
--
ALTER TABLE `taxrate`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `usergroups`
--
ALTER TABLE `usergroups`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `userspermission`
--
ALTER TABLE `userspermission`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1322;
--
-- AUTO_INCREMENT for table `voucher`
--
ALTER TABLE `voucher`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `voucherbankpayment`
--
ALTER TABLE `voucherbankpayment`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `voucherbankreceive`
--
ALTER TABLE `voucherbankreceive`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `voucherbkash`
--
ALTER TABLE `voucherbkash`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `vouchercontra`
--
ALTER TABLE `vouchercontra`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `voucherkcs`
--
ALTER TABLE `voucherkcs`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `vouchermbank`
--
ALTER TABLE `vouchermbank`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `voucherpayment`
--
ALTER TABLE `voucherpayment`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `voucherreceive`
--
ALTER TABLE `voucherreceive`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `vouchersap`
--
ALTER TABLE `vouchersap`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
